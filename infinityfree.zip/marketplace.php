<?php
include '../config/db.php';

$result = mysqli_query($conn,"SELECT * FROM products ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Marketplace</title>

<style>
body{
    margin:0;
    font-family:Poppins;
    background:#0f172a;
    color:white;
}

.container{
    padding:30px;
}

.grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:20px;
}

.card{
    background:rgba(255,255,255,0.08);
    padding:15px;
    border-radius:15px;
    transition:0.3s;
}

.card:hover{
    transform:translateY(-10px);
    box-shadow:0 10px 30px rgba(0,0,0,0.5);
}

.card img{
    width:100%;
    height:180px;
    object-fit:cover;
    border-radius:10px;
}

.price{
    color:#22c55e;
    font-weight:bold;
}

.badge{
    background:#6366f1;
    padding:5px 10px;
    border-radius:8px;
    font-size:12px;
}
</style>
</head>

<body>

<div class="container">
    <h1>🛒 Marketplace</h1>

    <div class="grid">
        <?php while($row = mysqli_fetch_assoc($result)){ ?>
        <div class="card">
            <img src="../uploads/<?php echo $row['image']; ?>">

            <h3><?php echo $row['title']; ?></h3>

            <p><?php echo $row['description']; ?></p>

            <p class="price">₹<?php echo $row['price']; ?></p>

            <span class="badge">
                <?php echo $row['condition']; ?>
                (<?php echo $row['age']; ?>)
            </span>
        </div>
        <?php } ?>
    </div>
</div>

</body>
</html>