<?php
session_start();

require_once '../config/db.php';

/*
|--------------------------------------------------------------------------
| EduTrade PRO - Save Skill API
|--------------------------------------------------------------------------
| Location:
| EduTrade/api/save_skills.php
|
| Purpose:
| - Receive skill form data
| - Validate logged-in student
| - Upload skill image
| - Insert skill into database
|--------------------------------------------------------------------------
*/


/* =========================================================
   CHECK LOGIN
========================================================= */

if (!isset($_SESSION['user_id'])) {
    header("Location: ../includes/login.php");
    exit();
}

$user_id = (int) $_SESSION['user_id'];


/* =========================================================
   ONLY POST REQUEST
========================================================= */

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../pages/add_skills.php");
    exit();
}


/* =========================================================
   GET FORM DATA
========================================================= */

$title = isset($_POST['title'])
    ? trim($_POST['title'])
    : '';

$category = isset($_POST['category'])
    ? trim($_POST['category'])
    : '';

$description = isset($_POST['description'])
    ? trim($_POST['description'])
    : '';

$experience = isset($_POST['experience'])
    ? trim($_POST['experience'])
    : '';

$availability = isset($_POST['availability'])
    ? trim($_POST['availability'])
    : 'Available';

$price = isset($_POST['price'])
    ? trim($_POST['price'])
    : '0';


/* =========================================================
   VALIDATION
========================================================= */

if ($title === '') {
    $_SESSION['skill_error'] = "Please enter your skill title.";
    header("Location: ../pages/add_skills.php");
    exit();
}

if ($category === '') {
    $_SESSION['skill_error'] = "Please select a skill category.";
    header("Location: ../pages/add_skills.php");
    exit();
}

if ($description === '') {
    $_SESSION['skill_error'] = "Please enter a description.";
    header("Location: ../pages/add_skills.php");
    exit();
}

if ($price === '' || !is_numeric($price) || $price < 0) {
    $_SESSION['skill_error'] = "Please enter a valid project price.";
    header("Location: ../pages/add_skills.php");
    exit();
}

$price = (float) $price;


/* =========================================================
   ALLOWED CATEGORIES
========================================================= */

$allowedCategories = [
    "Coding",
    "Graphic Design",
    "Web Development",
    "App Development",
    "Photography",
    "Video Editing",
    "Content Writing",
    "PPT / Presentation",
    "Other"
];

if (!in_array($category, $allowedCategories, true)) {
    $_SESSION['skill_error'] = "Invalid skill category.";
    header("Location: ../pages/add_skills.php");
    exit();
}


/* =========================================================
   ALLOWED AVAILABILITY
========================================================= */

$allowedAvailability = [
    "Available",
    "Busy",
    "Unavailable"
];

if (!in_array($availability, $allowedAvailability, true)) {
    $availability = "Available";
}


/* =========================================================
   IMAGE UPLOAD
========================================================= */

$imageName = "";


/*
|--------------------------------------------------------------------------
| Upload directory
|--------------------------------------------------------------------------
| EduTrade/
| ├── api/
| ├── config/
| ├── includes/
| ├── pages/
| └── uploads/
|     └── skills/
|
*/

$uploadDir = dirname(__DIR__) . "/uploads/skills/";


/* Create directory if it doesn't exist */

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}


/* Check whether image was uploaded */

if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {

    $file = $_FILES['image'];

    /* Check upload error */

    if ($file['error'] !== UPLOAD_ERR_OK) {

        $_SESSION['skill_error'] = "There was a problem uploading the image.";
        header("Location: ../pages/add_skills.php");
        exit();
    }


    /* Maximum size = 5 MB */

    $maxSize = 5 * 1024 * 1024;

    if ($file['size'] > $maxSize) {

        $_SESSION['skill_error'] = "Image must be smaller than 5 MB.";
        header("Location: ../pages/add_skills.php");
        exit();
    }


    /* Detect real MIME type */

    $finfo = finfo_open(FILEINFO_MIME_TYPE);

    $mimeType = finfo_file(
        $finfo,
        $file['tmp_name']
    );

    finfo_close($finfo);


    /* Allowed image types */

    $allowedMimeTypes = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp'
    ];


    if (!isset($allowedMimeTypes[$mimeType])) {

        $_SESSION['skill_error'] =
            "Only JPG, PNG and WEBP images are allowed.";

        header("Location: ../pages/add_skills.php");
        exit();
    }


    /* Generate unique filename */

    $extension = $allowedMimeTypes[$mimeType];

    $imageName =
        'skill_' .
        $user_id .
        '_' .
        time() .
        '_' .
        bin2hex(random_bytes(5)) .
        '.' .
        $extension;


    $destination = $uploadDir . $imageName;


    /* Move image */

    if (!move_uploaded_file(
        $file['tmp_name'],
        $destination
    )) {

        $_SESSION['skill_error'] =
            "Unable to save uploaded image.";

        header("Location: ../pages/add_skills.php");
        exit();
    }
}


/* =========================================================
   INSERT SKILL
========================================================= */

$sql = "
    INSERT INTO skills
    (
        user_id,
        title,
        category,
        description,
        experience,
        availability,
        image,
        price
    )
    VALUES
    (?, ?, ?, ?, ?, ?, ?, ?)
";


$stmt = mysqli_prepare($conn, $sql);


if (!$stmt) {

    /* Delete uploaded image if database preparation fails */

    if ($imageName !== '') {
        $uploadedFile = $uploadDir . $imageName;

        if (file_exists($uploadedFile)) {
            unlink($uploadedFile);
        }
    }

    $_SESSION['skill_error'] =
        "Database error. Please try again.";

    header("Location: ../pages/add_skills.php");
    exit();
}


/* Bind values */

mysqli_stmt_bind_param(
    $stmt,
    "issssssd",
    $user_id,
    $title,
    $category,
    $description,
    $experience,
    $availability,
    $imageName,
    $price
);


/* =========================================================
   EXECUTE
========================================================= */

if (mysqli_stmt_execute($stmt)) {

    $_SESSION['skill_success'] =
        "Your skill has been published successfully!";

    mysqli_stmt_close($stmt);

    header("Location: ../pages/skills.php");
    exit();

}


/* =========================================================
   INSERT FAILED
========================================================= */

if ($imageName !== '') {

    $uploadedFile = $uploadDir . $imageName;

    if (file_exists($uploadedFile)) {
        unlink($uploadedFile);
    }
}

mysqli_stmt_close($stmt);

$_SESSION['skill_error'] =
    "Unable to publish your skill. Please try again.";

header("Location: ../pages/add_skills.php");
exit();

?>