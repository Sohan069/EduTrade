<?php

session_start();

require_once "../config/db.php";

/* =========================================================
   AUTHENTICATION
========================================================= */

if (!isset($_SESSION['user_id'])) {
    header("Location: ../includes/login.php");
    exit();
}

$userId = (int)$_SESSION['user_id'];

/* =========================================================
   ONLY POST REQUEST
========================================================= */

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../pages/marketplace.php");
    exit();
}

/* =========================================================
   GET PRODUCT ID
========================================================= */

$productId = isset($_POST['product_id'])
    ? (int)$_POST['product_id']
    : 0;

if ($productId <= 0) {
    header("Location: ../pages/marketplace.php");
    exit();
}

/* =========================================================
   CHECK PRODUCT EXISTS
========================================================= */

$stmt = $conn->prepare("
    SELECT id
    FROM products
    WHERE id = ?
    LIMIT 1
");

if (!$stmt) {
    header("Location: ../pages/product_details.php?id=$productId&save=error");
    exit();
}

$stmt->bind_param("i", $productId);
$stmt->execute();

$result = $stmt->get_result();

$productExists = $result->fetch_assoc();

$stmt->close();

if (!$productExists) {
    header("Location: ../pages/marketplace.php");
    exit();
}

/* =========================================================
   CHECK IF ALREADY SAVED
========================================================= */

$stmt = $conn->prepare("
    SELECT id
    FROM saved_products
    WHERE user_id = ?
      AND product_id = ?
    LIMIT 1
");

if (!$stmt) {
    header("Location: ../pages/product_details.php?id=$productId&save=error");
    exit();
}

$stmt->bind_param("ii", $userId, $productId);
$stmt->execute();

$result = $stmt->get_result();

$existingSave = $result->fetch_assoc();

$stmt->close();

/* =========================================================
   TOGGLE SAVE / UNSAVE
========================================================= */

if ($existingSave) {

    /* REMOVE FROM WISHLIST */

    $stmt = $conn->prepare("
        DELETE FROM saved_products
        WHERE user_id = ?
          AND product_id = ?
    ");

    if ($stmt) {

        $stmt->bind_param(
            "ii",
            $userId,
            $productId
        );

        $stmt->execute();
        $stmt->close();
    }

    header(
        "Location: ../pages/product_details.php?id=$productId&save=removed"
    );

    exit();

} else {

    /* SAVE PRODUCT */

    $stmt = $conn->prepare("
        INSERT INTO saved_products
        (user_id, product_id)
        VALUES (?, ?)
    ");

    if ($stmt) {

        $stmt->bind_param(
            "ii",
            $userId,
            $productId
        );

        if ($stmt->execute()) {

            $stmt->close();

            header(
                "Location: ../pages/product_details.php?id=$productId&save=saved"
            );

            exit();

        }

        $stmt->close();
    }

    header(
        "Location: ../pages/product_details.php?id=$productId&save=error"
    );

    exit();
}