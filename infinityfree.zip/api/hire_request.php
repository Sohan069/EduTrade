<?php
session_start();

require_once "../config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../includes/login.php");
    exit;
}

$senderId = (int)$_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../pages/skills.php");
    exit;
}

$skillId      = (int)($_POST['skill_id'] ?? 0);
$receiverId   = (int)($_POST['receiver_id'] ?? 0);
$projectTitle = trim($_POST['project_title'] ?? '');
$message      = trim($_POST['message'] ?? '');
$budget       = (float)($_POST['budget'] ?? 0);

if ($skillId <= 0 || $projectTitle === '' || $message === '') {
    header("Location: ../pages/skill_profile.php?id=" . $skillId . "&hire=error");
    exit;
}

if ($budget < 0) {
    header("Location: ../pages/skill_profile.php?id=" . $skillId . "&hire=error");
    exit;
}

/*
|--------------------------------------------------------------------------
| Get the actual skill owner
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT id, user_id, title, availability
    FROM skills
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $skillId);
$stmt->execute();

$result = $stmt->get_result();
$skill = $result->fetch_assoc();

$stmt->close();

if (!$skill) {
    header("Location: ../pages/skills.php?hire=notfound");
    exit;
}

$actualProviderId = (int)$skill['user_id'];

/*
|--------------------------------------------------------------------------
| Don't allow student to hire themselves
|--------------------------------------------------------------------------
*/

if ($senderId === $actualProviderId) {
    header("Location: ../pages/skill_profile.php?id=" . $skillId . "&hire=self");
    exit;
}

/*
|--------------------------------------------------------------------------
| Check availability
|--------------------------------------------------------------------------
*/

if (
    isset($skill['availability']) &&
    strtolower(trim($skill['availability'])) === 'unavailable'
) {
    header("Location: ../pages/skill_profile.php?id=" . $skillId . "&hire=unavailable");
    exit;
}

/*
|--------------------------------------------------------------------------
| Check ACTIVE request only
|
| IMPORTANT:
| Completed / Rejected / Cancelled requests DO NOT block a new hire.
|--------------------------------------------------------------------------
*/

$activeStmt = $conn->prepare("
    SELECT id, status
    FROM hire_requests
    WHERE skill_id = ?
      AND (
            (sender_id = ? AND receiver_id = ?)
            OR
            (requester_id = ? AND provider_id = ?)
          )
      AND status IN ('Pending', 'Accepted', 'Started')
    ORDER BY id DESC
    LIMIT 1
");

$activeStmt->bind_param(
    "iiiii",
    $skillId,
    $senderId,
    $actualProviderId,
    $senderId,
    $actualProviderId
);

$activeStmt->execute();

$activeResult = $activeStmt->get_result();
$activeRequest = $activeResult->fetch_assoc();

$activeStmt->close();

if ($activeRequest) {
    header(
        "Location: ../pages/skill_profile.php?id=" .
        $skillId .
        "&hire=active"
    );
    exit;
}

/*
|--------------------------------------------------------------------------
| Store project title inside message
|
| Your current hire_requests table does NOT have project_title.
|--------------------------------------------------------------------------
*/

$finalMessage =
    "[Project: " . $projectTitle . "]\n\n" .
    $message;

/*
|--------------------------------------------------------------------------
| INSERT REQUEST
|
| We populate BOTH ID systems:
| sender_id / receiver_id
| requester_id / provider_id
|
| This makes the request visible regardless of which columns
| your pages are using.
|--------------------------------------------------------------------------
*/

$insert = $conn->prepare("
    INSERT INTO hire_requests
    (
        sender_id,
        receiver_id,
        skill_id,
        requester_id,
        provider_id,
        message,
        budget,
        status
    )
    VALUES
    (?, ?, ?, ?, ?, ?, ?, 'Pending')
");

if (!$insert) {
    die("Prepare Error: " . $conn->error);
}

$insert->bind_param(
    "iiiiisd",
    $senderId,
    $actualProviderId,
    $skillId,
    $senderId,
    $actualProviderId,
    $finalMessage,
    $budget
);

if ($insert->execute()) {

    $insert->close();

    header(
        "Location: ../pages/skill_profile.php?id=" .
        $skillId .
        "&hire=success"
    );
    exit;

} else {

    $insert->close();

    header(
        "Location: ../pages/skill_profile.php?id=" .
        $skillId .
        "&hire=error"
    );
    exit;
}
?>