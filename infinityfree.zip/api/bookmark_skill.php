<?php

session_start();

require_once "../config/db.php";

header("Content-Type: application/json; charset=UTF-8");

/* =========================================================
   LOGIN CHECK
   ========================================================= */

if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        "success" => false,
        "message" => "Please login first."
    ]);
    exit;
}

$user_id = (int)$_SESSION['user_id'];

/* =========================================================
   POST CHECK
   ========================================================= */

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "success" => false,
        "message" => "Invalid request."
    ]);
    exit;
}

$skill_id = isset($_POST['skill_id'])
    ? (int)$_POST['skill_id']
    : 0;

$action = isset($_POST['action'])
    ? trim($_POST['action'])
    : "save";

if ($skill_id <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid skill."
    ]);
    exit;
}

/* =========================================================
   CHECK SKILL
   ========================================================= */

$stmt = $conn->prepare("
    SELECT id
    FROM skills
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $skill_id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {

    $stmt->close();

    echo json_encode([
        "success" => false,
        "message" => "Skill not found."
    ]);

    exit;
}

$stmt->close();

/* =========================================================
   REMOVE
   ========================================================= */

if ($action === "remove") {

    $stmt = $conn->prepare("
        DELETE FROM saved_skills
        WHERE user_id = ?
        AND skill_id = ?
    ");

    $stmt->bind_param(
        "ii",
        $user_id,
        $skill_id
    );

    $stmt->execute();

    $stmt->close();

    echo json_encode([
        "success" => true,
        "saved" => false,
        "message" => "Skill removed from saved skills."
    ]);

    exit;
}

/* =========================================================
   CHECK EXISTING
   ========================================================= */

$stmt = $conn->prepare("
    SELECT id
    FROM saved_skills
    WHERE user_id = ?
    AND skill_id = ?
    LIMIT 1
");

$stmt->bind_param(
    "ii",
    $user_id,
    $skill_id
);

$stmt->execute();

$result = $stmt->get_result();

$already_saved = $result->num_rows > 0;

$stmt->close();

/* =========================================================
   UNSAVE
   ========================================================= */

if ($already_saved) {

    $stmt = $conn->prepare("
        DELETE FROM saved_skills
        WHERE user_id = ?
        AND skill_id = ?
    ");

    $stmt->bind_param(
        "ii",
        $user_id,
        $skill_id
    );

    $stmt->execute();

    $stmt->close();

    echo json_encode([
        "success" => true,
        "saved" => false,
        "message" => "Skill removed from saved skills."
    ]);

    exit;
}

/* =========================================================
   SAVE
   ========================================================= */

$stmt = $conn->prepare("
    INSERT INTO saved_skills
    (user_id, skill_id)
    VALUES (?, ?)
");

$stmt->bind_param(
    "ii",
    $user_id,
    $skill_id
);

if ($stmt->execute()) {

    echo json_encode([
        "success" => true,
        "saved" => true,
        "message" => "Skill saved successfully."
    ]);

} else {

    echo json_encode([
        "success" => false,
        "message" => "Unable to save skill."
    ]);
}

$stmt->close();