<?php

session_start();

require_once "../config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../includes/login.php");
    exit;
}

$user_id = (int)$_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT
        s.*,
        u.name AS student_name
    FROM saved_skills ss
    INNER JOIN skills s
        ON ss.skill_id = s.id
    LEFT JOIN users u
        ON s.user_id = u.id
    WHERE ss.user_id = ?
    ORDER BY ss.created_at DESC
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();

$skills = [];

while ($row = $result->fetch_assoc()) {
    $skills[] = $row;
}

$stmt->close();

function skillImage($filename)
{
    if (empty($filename)) {
        return '';
    }

    $filename = basename($filename);

    $path = "../uploads/skills/" . $filename;

    $physicalPath = dirname(__DIR__) .
        "/uploads/skills/" . $filename;

    if (file_exists($physicalPath)) {
        return $path;
    }

    return '';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Saved Skills | EduTrade</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    min-height: 100vh;
    color: white;

    background:
        radial-gradient(circle at 10% 10%, #172554, transparent 35%),
        radial-gradient(circle at 90% 90%, #3b0764, transparent 35%),
        #050816;
}

.navbar {
    height: 75px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 6%;

    background: rgba(5,8,22,.72);
    backdrop-filter: blur(18px);

    border-bottom: 1px solid rgba(255,255,255,.08);

    position: sticky;
    top: 0;
    z-index: 50;
}

.logo {
    color: white;
    text-decoration: none;
    font-size: 25px;
    font-weight: 800;
}

.logo span {
    color: #22c55e;
}

.nav-links {
    display: flex;
    gap: 24px;
}

.nav-links a {
    text-decoration: none;
    color: #cbd5e1;
    font-size: 14px;
}

.nav-links a:hover {
    color: #22c55e;
}

.container {
    width: min(1200px, 92%);
    margin: auto;
    padding: 55px 0;
}

.heading h1 {
    font-size: 42px;
    margin-bottom: 10px;
}

.heading p {
    color: #94a3b8;
    margin-bottom: 40px;
}

.grid {
    display: grid;
    grid-template-columns:
        repeat(3, 1fr);
    gap: 24px;
}

.card {
    border-radius: 22px;
    overflow: hidden;

    background: rgba(15,23,42,.75);

    border: 1px solid rgba(255,255,255,.08);

    transition: .3s;
}

.card:hover {
    transform: translateY(-7px);
    border-color: rgba(34,197,94,.4);
}

.image {
    height: 220px;
    background: #0f172a;
}

.image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.no-image {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 55px;
}

.content {
    padding: 22px;
}

.category {
    color: #a78bfa;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
}

.title {
    font-size: 21px;
    margin: 10px 0;
}

.description {
    color: #94a3b8;
    font-size: 14px;
    line-height: 1.6;
    min-height: 48px;
}

.student {
    margin: 17px 0;
    color: #cbd5e1;
    font-size: 14px;
}

.price {
    color: #4ade80;
    font-size: 21px;
    font-weight: 800;
    margin-bottom: 18px;
}

.actions {
    display: flex;
    gap: 10px;
}

.btn {
    flex: 1;
    padding: 12px;
    border-radius: 12px;
    border: 0;
    cursor: pointer;
    text-align: center;
    text-decoration: none;
    font-weight: 700;
}

.view {
    background: #22c55e;
    color: #04110a;
}

.remove {
    background: rgba(239,68,68,.12);
    color: #f87171;
}

.empty {
    text-align: center;
    padding: 90px 20px;
    color: #94a3b8;
}

.empty-icon {
    font-size: 65px;
    margin-bottom: 20px;
}

.empty h2 {
    color: white;
    margin-bottom: 10px;
}

.empty a {
    display: inline-block;
    margin-top: 25px;
    padding: 13px 22px;
    background: #22c55e;
    color: #04110a;
    border-radius: 12px;
    text-decoration: none;
    font-weight: 700;
}

@media(max-width:950px) {
    .grid {
        grid-template-columns: repeat(2,1fr);
    }
}

@media(max-width:650px) {

    .nav-links {
        display: none;
    }

    .grid {
        grid-template-columns: 1fr;
    }

    .heading h1 {
        font-size: 32px;
    }
}

</style>

</head>

<body>

<nav class="navbar">

    <a href="dashboard.php" class="logo">
        Edu<span>Trade</span>
    </a>

    <div class="nav-links">
        <a href="dashboard.php">Dashboard</a>
        <a href="marketplace.php">Marketplace</a>
        <a href="skills.php">Skill Hub</a>
        <a href="saved_products.php">Saved Products</a>
        <a href="hire_requests.php">Hire Requests</a>
    </div>

</nav>

<main class="container">

    <div class="heading">

        <h1>⭐ Saved Skills</h1>

        <p>
            Student skills you've saved for future projects.
        </p>

    </div>

    <?php if (count($skills) > 0): ?>

        <div class="grid">

        <?php foreach ($skills as $skill): ?>

            <?php
                $img = skillImage($skill['image'] ?? '');
            ?>

            <article class="card">

                <div class="image">

                    <?php if ($img): ?>

                        <img
                            src="<?php echo htmlspecialchars($img); ?>"
                            alt="<?php echo htmlspecialchars($skill['title']); ?>"
                        >

                    <?php else: ?>

                        <div class="no-image">
                            💼
                        </div>

                    <?php endif; ?>

                </div>

                <div class="content">

                    <div class="category">
                        <?php echo htmlspecialchars($skill['category']); ?>
                    </div>

                    <h2 class="title">
                        <?php echo htmlspecialchars($skill['title']); ?>
                    </h2>

                    <p class="description">
                        <?php
                        echo htmlspecialchars(
                            mb_strimwidth(
                                $skill['description'],
                                0,
                                110,
                                '...'
                            )
                        );
                        ?>
                    </p>

                    <div class="student">
                        👤 <?php
                        echo htmlspecialchars(
                            $skill['student_name'] ?? 'Student'
                        );
                        ?>
                    </div>

                    <div class="price">

                        <?php if ((float)$skill['price'] > 0): ?>

                            From ₹<?php
                            echo number_format(
                                (float)$skill['price'],
                                2
                            );
                            ?>

                        <?php else: ?>

                            Contact for pricing

                        <?php endif; ?>

                    </div>

                    <div class="actions">

                        <a
                            class="btn view"
                            href="skill_profile.php?id=<?php echo (int)$skill['id']; ?>"
                        >
                            View Skill
                        </a>

                        <button
                            class="btn remove"
                            onclick="removeSkill(<?php echo (int)$skill['id']; ?>, this)"
                        >
                            Remove
                        </button>

                    </div>

                </div>

            </article>

        <?php endforeach; ?>

        </div>

    <?php else: ?>

        <div class="empty">

            <div class="empty-icon">⭐</div>

            <h2>No Saved Skills Yet</h2>

            <p>
                Save talented students and easily find them later.
            </p>

            <a href="skills.php">
                Explore Skill Hub
            </a>

        </div>

    <?php endif; ?>

</main>

<script>

async function removeSkill(skillId, button) {

    button.disabled = true;
    button.innerText = "Removing...";

    try {

        const formData = new FormData();

        formData.append("skill_id", skillId);
        formData.append("action", "remove");

        const response = await fetch(
            "../api/bookmark_skill.php",
            {
                method: "POST",
                body: formData
            }
        );

        const data = await response.json();

        if (data.success) {

            location.reload();

        } else {

            alert(
                data.message ||
                "Unable to remove skill."
            );

            button.disabled = false;
            button.innerText = "Remove";
        }

    } catch (error) {

        alert("Something went wrong.");

        button.disabled = false;
        button.innerText = "Remove";
    }
}

</script>

</body>
</html>