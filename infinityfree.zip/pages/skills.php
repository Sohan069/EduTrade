<?php
session_start();
require_once '../config/db.php';

/*
|--------------------------------------------------------------------------
| EduTrade PRO - Skill Hub
|--------------------------------------------------------------------------
| Database:
| skills:
| id
| user_id
| title
| category
| description
| experience
| availability
| image
| price
| created_at
|--------------------------------------------------------------------------
*/

// Check login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../includes/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

/*
|--------------------------------------------------------------------------
| Search + Filter
|--------------------------------------------------------------------------
*/

$search   = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : '';
$status   = isset($_GET['availability']) ? trim($_GET['availability']) : '';

/*
|--------------------------------------------------------------------------
| Build query
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT 
        s.id,
        s.user_id,
        s.title,
        s.category,
        s.description,
        s.experience,
        s.availability,
        s.image,
        s.price,
        s.created_at,
        u.name AS student_name
    FROM skills s
    LEFT JOIN users u ON s.user_id = u.id
    WHERE 1=1
";

$params = [];
$types = "";

/* Search */
if ($search !== '') {
    $sql .= " AND (
        s.title LIKE ?
        OR s.description LIKE ?
        OR s.category LIKE ?
        OR u.name LIKE ?
    )";

    $searchTerm = "%" . $search . "%";

    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;

    $types .= "ssss";
}

/* Category */
if ($category !== '') {
    $sql .= " AND s.category = ?";
    $params[] = $category;
    $types .= "s";
}

/* Availability */
if ($status !== '') {
    $sql .= " AND s.availability = ?";
    $params[] = $status;
    $types .= "s";
}

$sql .= " ORDER BY s.created_at DESC";

/*
|--------------------------------------------------------------------------
| Execute
|--------------------------------------------------------------------------
*/

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("Database query error.");
}

if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

/*
|--------------------------------------------------------------------------
| Count skills
|--------------------------------------------------------------------------
*/

$totalSkills = mysqli_num_rows($result);

/*
|--------------------------------------------------------------------------
| Categories
|--------------------------------------------------------------------------
*/

$categories = [
    "Coding",
    "Graphic Design",
    "Web Development",
    "App Development",
    "Photography",
    "Video Editing",
    "Content Writing",
    "PPT / Presentation",
    "Other"
];

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Skill Hub | EduTrade PRO</title>

<link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>

/* =========================================================
   RESET
========================================================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

html{
    scroll-behavior:smooth;
}

body{
    font-family:'Poppins',sans-serif;
    background:
        radial-gradient(circle at 10% 10%,rgba(99,102,241,.18),transparent 30%),
        radial-gradient(circle at 90% 20%,rgba(14,165,233,.15),transparent 30%),
        radial-gradient(circle at 50% 90%,rgba(168,85,247,.12),transparent 35%),
        #020617;
    color:#f8fafc;
    min-height:100vh;
    overflow-x:hidden;
}

/* =========================================================
   BACKGROUND ORBS
========================================================= */

body::before{
    content:"";
    position:fixed;
    width:500px;
    height:500px;
    border-radius:50%;
    background:rgba(99,102,241,.08);
    filter:blur(100px);
    top:-180px;
    left:-150px;
    pointer-events:none;
    animation:orbMove 10s ease-in-out infinite alternate;
}

body::after{
    content:"";
    position:fixed;
    width:450px;
    height:450px;
    border-radius:50%;
    background:rgba(6,182,212,.07);
    filter:blur(100px);
    right:-150px;
    bottom:-150px;
    pointer-events:none;
    animation:orbMove2 12s ease-in-out infinite alternate;
}

@keyframes orbMove{
    from{
        transform:translate(0,0);
    }
    to{
        transform:translate(120px,80px);
    }
}

@keyframes orbMove2{
    from{
        transform:translate(0,0);
    }
    to{
        transform:translate(-100px,-70px);
    }
}

/* =========================================================
   LAYOUT
========================================================= */

.page{
    width:100%;
    min-height:100vh;
    position:relative;
    z-index:2;
}

/* =========================================================
   NAVBAR
========================================================= */

.navbar{
    width:100%;
    height:76px;

    display:flex;
    align-items:center;
    justify-content:space-between;

    padding:0 5%;

    background:rgba(2,6,23,.72);
    backdrop-filter:blur(20px);

    border-bottom:1px solid rgba(255,255,255,.07);

    position:sticky;
    top:0;
    z-index:1000;
}

.logo{
    display:flex;
    align-items:center;
    gap:11px;

    text-decoration:none;
    color:white;

    font-size:21px;
    font-weight:800;
}

.logo-icon{
    width:40px;
    height:40px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:13px;

    background:linear-gradient(135deg,#6366f1,#06b6d4);

    box-shadow:
        0 8px 25px rgba(99,102,241,.35);

    animation:logoPulse 3s ease-in-out infinite;
}

@keyframes logoPulse{
    0%,100%{
        transform:translateY(0);
    }
    50%{
        transform:translateY(-3px);
    }
}

.logo span{
    background:linear-gradient(
        90deg,
        #ffffff,
        #a5b4fc,
        #67e8f9
    );

    -webkit-background-clip:text;
    background-clip:text;
    color:transparent;
}

.nav-right{
    display:flex;
    align-items:center;
    gap:14px;
}

.nav-link{
    text-decoration:none;
    color:#94a3b8;

    padding:10px 14px;

    border-radius:10px;

    transition:.3s;
}

.nav-link:hover{
    color:white;
    background:rgba(255,255,255,.07);
}

.nav-profile{
    display:flex;
    align-items:center;
    gap:10px;

    padding:7px 12px 7px 7px;

    background:rgba(255,255,255,.06);

    border:1px solid rgba(255,255,255,.08);

    border-radius:30px;
}

.avatar{
    width:34px;
    height:34px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:50%;

    background:linear-gradient(135deg,#8b5cf6,#06b6d4);

    font-size:14px;
    font-weight:700;
}

/* =========================================================
   HERO
========================================================= */

.hero{
    max-width:1250px;
    margin:auto;

    padding:70px 5% 40px;

    text-align:center;
}

.badge{
    display:inline-flex;
    align-items:center;
    gap:8px;

    padding:8px 15px;

    border-radius:30px;

    background:rgba(99,102,241,.10);

    border:1px solid rgba(129,140,248,.25);

    color:#c4b5fd;

    font-size:13px;
    font-weight:600;

    animation:fadeDown .7s ease;
}

.badge-dot{
    width:7px;
    height:7px;

    border-radius:50%;

    background:#22c55e;

    box-shadow:0 0 12px #22c55e;
}

.hero h1{
    margin-top:22px;

    font-size:clamp(38px,6vw,68px);

    line-height:1.05;

    font-weight:800;

    letter-spacing:-2px;

    background:
        linear-gradient(
            100deg,
            #ffffff 0%,
            #a5b4fc 35%,
            #67e8f9 70%,
            #c084fc 100%
        );

    -webkit-background-clip:text;
    background-clip:text;
    color:transparent;

    animation:fadeUp .8s ease;
}

.hero p{
    max-width:650px;

    margin:20px auto 0;

    color:#94a3b8;

    font-size:16px;
    line-height:1.8;

    animation:fadeUp 1s ease;
}

.hero-actions{
    display:flex;
    justify-content:center;
    gap:14px;

    margin-top:30px;

    animation:fadeUp 1.2s ease;
}

/* =========================================================
   BUTTONS
========================================================= */

.btn{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:8px;

    padding:13px 20px;

    border-radius:13px;

    text-decoration:none;

    font-size:14px;
    font-weight:600;

    cursor:pointer;

    transition:.35s;

    border:1px solid transparent;
}

.btn-primary{
    color:white;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #8b5cf6,
            #06b6d4
        );

    box-shadow:
        0 10px 30px rgba(99,102,241,.25);
}

.btn-primary:hover{
    transform:translateY(-3px);

    box-shadow:
        0 15px 35px rgba(99,102,241,.42);
}

.btn-secondary{
    color:#cbd5e1;

    background:rgba(255,255,255,.05);

    border-color:rgba(255,255,255,.1);
}

.btn-secondary:hover{
    color:white;
    background:rgba(255,255,255,.1);
    transform:translateY(-3px);
}

/* =========================================================
   SEARCH PANEL
========================================================= */

.search-section{
    max-width:1150px;

    margin:25px auto 0;

    padding:0 5%;
}

.search-panel{
    padding:20px;

    border-radius:22px;

    background:
        linear-gradient(
            135deg,
            rgba(255,255,255,.075),
            rgba(255,255,255,.035)
        );

    border:1px solid rgba(255,255,255,.09);

    backdrop-filter:blur(25px);

    box-shadow:
        0 20px 70px rgba(0,0,0,.25);
}

.search-form{
    display:grid;

    grid-template-columns:1fr 190px 170px auto;

    gap:12px;
}

.search-box,
.select-box{
    width:100%;

    height:48px;

    padding:0 16px;

    border-radius:12px;

    border:1px solid rgba(255,255,255,.08);

    outline:none;

    background:rgba(2,6,23,.65);

    color:white;

    font-family:'Poppins',sans-serif;

    transition:.3s;
}

.search-box::placeholder{
    color:#64748b;
}

.search-box:focus,
.select-box:focus{
    border-color:#6366f1;

    box-shadow:
        0 0 0 3px rgba(99,102,241,.12);
}

.select-box option{
    background:#0f172a;
    color:white;
}

.search-btn{
    height:48px;

    padding:0 22px;

    border:none;

    border-radius:12px;

    color:white;

    font-family:'Poppins',sans-serif;
    font-weight:600;

    cursor:pointer;

    background:linear-gradient(
        135deg,
        #6366f1,
        #8b5cf6
    );

    transition:.3s;
}

.search-btn:hover{
    transform:translateY(-2px);

    box-shadow:
        0 10px 25px rgba(99,102,241,.35);
}

/* =========================================================
   CATEGORY BAR
========================================================= */

.category-section{
    max-width:1150px;

    margin:30px auto;

    padding:0 5%;
}

.category-scroll{
    display:flex;

    gap:10px;

    overflow-x:auto;

    padding-bottom:5px;

    scrollbar-width:none;
}

.category-scroll::-webkit-scrollbar{
    display:none;
}

.category{
    flex-shrink:0;

    padding:10px 16px;

    border-radius:30px;

    color:#94a3b8;

    background:rgba(255,255,255,.04);

    border:1px solid rgba(255,255,255,.07);

    text-decoration:none;

    font-size:13px;

    transition:.3s;
}

.category:hover,
.category.active{
    color:white;

    background:
        linear-gradient(
            135deg,
            rgba(99,102,241,.85),
            rgba(139,92,246,.85)
        );

    border-color:transparent;

    box-shadow:
        0 8px 25px rgba(99,102,241,.2);
}

/* =========================================================
   SECTION HEADER
========================================================= */

.content{
    max-width:1150px;

    margin:0 auto;

    padding:10px 5% 80px;
}

.section-header{
    display:flex;

    justify-content:space-between;
    align-items:end;

    margin-bottom:22px;
}

.section-header h2{
    font-size:24px;
    font-weight:700;
}

.section-header p{
    color:#64748b;
    font-size:13px;
    margin-top:5px;
}

.result-count{
    color:#94a3b8;
    font-size:13px;
}

/* =========================================================
   SKILL GRID
========================================================= */

.skills-grid{
    display:grid;

    grid-template-columns:
        repeat(3, minmax(0,1fr));

    gap:20px;
}

/* =========================================================
   SKILL CARD
========================================================= */

.skill-card{
    position:relative;

    overflow:hidden;

    border-radius:22px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.075),
            rgba(255,255,255,.025)
        );

    border:1px solid rgba(255,255,255,.09);

    backdrop-filter:blur(20px);

    transition:
        transform .4s,
        box-shadow .4s,
        border-color .4s;

    animation:cardIn .7s ease both;
}

.skill-card::before{
    content:"";

    position:absolute;

    width:180px;
    height:180px;

    top:-100px;
    right:-80px;

    background:#6366f1;

    border-radius:50%;

    filter:blur(80px);

    opacity:.10;

    transition:.4s;
}

.skill-card:hover{
    transform:translateY(-8px);

    border-color:rgba(129,140,248,.35);

    box-shadow:
        0 20px 50px rgba(0,0,0,.35),
        0 0 30px rgba(99,102,241,.08);
}

.skill-card:hover::before{
    opacity:.22;
}

/* =========================================================
   IMAGE
========================================================= */

.skill-image{
    height:190px;

    position:relative;

    overflow:hidden;

    background:
        linear-gradient(
            135deg,
            #111827,
            #1e1b4b
        );
}

.skill-image img{
    width:100%;
    height:100%;

    object-fit:cover;

    transition:.5s;
}

.skill-card:hover .skill-image img{
    transform:scale(1.07);
}

.image-placeholder{
    width:100%;
    height:100%;

    display:flex;
    align-items:center;
    justify-content:center;

    font-size:55px;

    background:
        radial-gradient(
            circle at 30% 30%,
            rgba(99,102,241,.3),
            transparent 40%
        ),
        radial-gradient(
            circle at 70% 70%,
            rgba(6,182,212,.22),
            transparent 40%
        ),
        #0f172a;
}

.featured{
    position:absolute;

    top:14px;
    left:14px;

    padding:6px 10px;

    border-radius:20px;

    background:rgba(2,6,23,.7);

    backdrop-filter:blur(10px);

    border:1px solid rgba(255,255,255,.1);

    color:#fde68a;

    font-size:11px;
    font-weight:600;
}

.status{
    position:absolute;

    top:14px;
    right:14px;

    padding:6px 10px;

    border-radius:20px;

    background:rgba(2,6,23,.72);

    backdrop-filter:blur(10px);

    font-size:11px;
    font-weight:600;
}

.status.available{
    color:#4ade80;
}

.status.busy{
    color:#fbbf24;
}

.status.unavailable{
    color:#f87171;
}

/* =========================================================
   CARD CONTENT
========================================================= */

.skill-content{
    padding:20px;
}

.skill-category{
    display:inline-block;

    color:#a5b4fc;

    font-size:11px;

    font-weight:600;

    padding:5px 9px;

    border-radius:8px;

    background:rgba(99,102,241,.10);

    margin-bottom:10px;
}

.skill-title{
    font-size:18px;

    font-weight:700;

    color:white;

    margin-bottom:8px;
}

.skill-description{
    color:#94a3b8;

    font-size:12px;

    line-height:1.7;

    min-height:42px;

    display:-webkit-box;
    -webkit-line-clamp:2;
    -webkit-box-orient:vertical;

    overflow:hidden;
}

/* =========================================================
   STUDENT
========================================================= */

.student{
    display:flex;

    align-items:center;

    gap:10px;

    margin-top:17px;

    padding-top:15px;

    border-top:1px solid rgba(255,255,255,.06);
}

.student-avatar{
    width:36px;
    height:36px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:50%;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #06b6d4
        );

    font-size:12px;

    font-weight:700;
}

.student-info{
    flex:1;
}

.student-name{
    color:#e2e8f0;

    font-size:12px;

    font-weight:600;
}

.experience{
    color:#64748b;

    font-size:10px;

    margin-top:2px;
}

/* =========================================================
   CARD FOOTER
========================================================= */

.skill-footer{
    display:flex;

    align-items:center;
    justify-content:space-between;

    margin-top:18px;
}

.price{
    color:#67e8f9;

    font-size:17px;

    font-weight:700;
}

.price small{
    color:#64748b;

    font-size:9px;

    font-weight:500;
}

.hire-btn{
    padding:9px 14px;

    border-radius:10px;

    color:white;

    text-decoration:none;

    font-size:11px;

    font-weight:600;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #8b5cf6
        );

    transition:.3s;
}

.hire-btn:hover{
    transform:translateY(-2px);

    box-shadow:
        0 8px 20px rgba(99,102,241,.35);
}

/* =========================================================
   EMPTY STATE
========================================================= */

.empty{
    grid-column:1/-1;

    padding:70px 20px;

    text-align:center;

    border-radius:22px;

    background:rgba(255,255,255,.035);

    border:1px dashed rgba(255,255,255,.12);
}

.empty-icon{
    font-size:50px;

    margin-bottom:15px;
}

.empty h3{
    font-size:20px;

    margin-bottom:8px;
}

.empty p{
    color:#64748b;

    font-size:13px;

    margin-bottom:20px;
}

/* =========================================================
   FOOTER
========================================================= */

.footer{
    padding:25px 5%;

    border-top:1px solid rgba(255,255,255,.06);

    text-align:center;

    color:#475569;

    font-size:12px;
}

/* =========================================================
   ANIMATIONS
========================================================= */

@keyframes fadeUp{
    from{
        opacity:0;
        transform:translateY(25px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

@keyframes fadeDown{
    from{
        opacity:0;
        transform:translateY(-15px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

@keyframes cardIn{
    from{
        opacity:0;
        transform:translateY(25px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:1000px){

    .skills-grid{
        grid-template-columns:
            repeat(2,minmax(0,1fr));
    }

    .search-form{
        grid-template-columns:
            1fr 1fr;
    }

    .search-btn{
        grid-column:span 2;
    }
}

@media(max-width:700px){

    .navbar{
        padding:0 20px;
    }

    .nav-link{
        display:none;
    }

    .hero{
        padding-top:50px;
    }

    .hero h1{
        letter-spacing:-1px;
    }

    .skills-grid{
        grid-template-columns:1fr;
    }

    .search-form{
        grid-template-columns:1fr;
    }

    .search-btn{
        grid-column:auto;
    }

    .hero-actions{
        flex-direction:column;
    }

    .hero-actions .btn{
        width:100%;
    }

    .section-header{
        align-items:flex-start;
        flex-direction:column;
        gap:8px;
    }
}

</style>

</head>

<body>

<div class="page">

<!-- =====================================================
     NAVBAR
===================================================== -->

<nav class="navbar">

    <a href="dashboard.php" class="logo">

        <div class="logo-icon">
            ⚡
        </div>

        <span>EduTrade PRO</span>

    </a>

    <div class="nav-right">

        <a href="dashboard.php" class="nav-link">
            Dashboard
        </a>

        <a href="marketplace.php" class="nav-link">
            Marketplace
        </a>

        <a href="skills.php" class="nav-link">
            Skill Hub
        </a>

        <div class="nav-profile">

            <div class="avatar">
                <?php
                echo strtoupper(
                    substr(
                        $_SESSION['name'] ?? 'S',
                        0,
                        1
                    )
                );
                ?>
            </div>

            <span>
                <?php
                echo htmlspecialchars(
                    $_SESSION['name'] ?? 'Student'
                );
                ?>
            </span>

        </div>

    </div>

</nav>


<!-- =====================================================
     HERO
===================================================== -->

<section class="hero">

    <div class="badge">
        <span class="badge-dot"></span>
        Campus Talent Network
    </div>

    <h1>
        Discover Student Talent.
        <br>
        Build Something Great.
    </h1>

    <p>
        Connect with talented students from your campus,
        showcase your expertise, and find people who can
        turn your ideas into reality.
    </p>

    <div class="hero-actions">

        <a href="add_skills.php" class="btn btn-primary">
            ✨ Add Your Skill
        </a>

        <a href="#skills" class="btn btn-secondary">
            Explore Skills ↓
        </a>

    </div>

</section>


<!-- =====================================================
     SEARCH
===================================================== -->

<section class="search-section">

    <div class="search-panel">

        <form method="GET" class="search-form">

            <input
                type="text"
                name="search"
                class="search-box"
                placeholder="🔍 Search skills, students or services..."
                value="<?php echo htmlspecialchars($search); ?>"
            >

            <select name="category" class="select-box">

                <option value="">
                    All Categories
                </option>

                <?php foreach($categories as $cat): ?>

                    <option
                        value="<?php echo htmlspecialchars($cat); ?>"
                        <?php
                        if($category === $cat){
                            echo 'selected';
                        }
                        ?>
                    >
                        <?php echo htmlspecialchars($cat); ?>
                    </option>

                <?php endforeach; ?>

            </select>


            <select name="availability" class="select-box">

                <option value="">
                    Any Availability
                </option>

                <option
                    value="Available"
                    <?php
                    if($status === 'Available'){
                        echo 'selected';
                    }
                    ?>
                >
                    🟢 Available
                </option>

                <option
                    value="Busy"
                    <?php
                    if($status === 'Busy'){
                        echo 'selected';
                    }
                    ?>
                >
                    🟡 Busy
                </option>

                <option
                    value="Unavailable"
                    <?php
                    if($status === 'Unavailable'){
                        echo 'selected';
                    }
                    ?>
                >
                    🔴 Unavailable
                </option>

            </select>


            <button type="submit" class="search-btn">
                Search
            </button>

        </form>

    </div>

</section>


<!-- =====================================================
     CATEGORIES
===================================================== -->

<section class="category-section">

    <div class="category-scroll">

        <a
            href="skills.php"
            class="category <?php echo $category === '' ? 'active' : ''; ?>"
        >
            ✨ All Skills
        </a>

        <?php foreach($categories as $cat): ?>

            <a
                href="skills.php?category=<?php echo urlencode($cat); ?>"
                class="category <?php echo $category === $cat ? 'active' : ''; ?>"
            >
                <?php echo htmlspecialchars($cat); ?>
            </a>

        <?php endforeach; ?>

    </div>

</section>


<!-- =====================================================
     SKILLS
===================================================== -->

<section class="content" id="skills">

    <div class="section-header">

        <div>

            <h2>
                Explore Student Skills
            </h2>

            <p>
                Find the right talent for your next project.
            </p>

        </div>

        <div class="result-count">

            <?php echo $totalSkills; ?>
            skill<?php echo $totalSkills != 1 ? 's' : ''; ?> found

        </div>

    </div>


    <div class="skills-grid">

        <?php if($totalSkills > 0): ?>

            <?php
            $cardIndex = 0;
            ?>

            <?php while($skill = mysqli_fetch_assoc($result)): ?>

                <?php

                $cardIndex++;

                $studentName =
                    !empty($skill['student_name'])
                    ? $skill['student_name']
                    : 'Student';

                $initial =
                    strtoupper(
                        substr(
                            $studentName,
                            0,
                            1
                        )
                    );

                $availability =
                    !empty($skill['availability'])
                    ? $skill['availability']
                    : 'Available';

                $statusClass =
                    strtolower(
                        $availability
                    );

                ?>

                <div
                    class="skill-card"
                    style="
                        animation-delay:
                        <?php echo min($cardIndex * 0.08, 0.6); ?>s;
                    "
                >

                    <!-- IMAGE -->

                    <div class="skill-image">

                        <?php if(!empty($skill['image'])): ?>

                            <img
                                src="../uploads/skills/<?php echo htmlspecialchars($skill['image']); ?>"
                                alt="<?php echo htmlspecialchars($skill['title']); ?>"
                                onerror="this.style.display='none';this.nextElementSibling.style.display='flex';"
                            >

                            <div
                                class="image-placeholder"
                                style="display:none;"
                            >
                                💻
                            </div>

                        <?php else: ?>

                            <div class="image-placeholder">

                                <?php

                                $icons = [
                                    'Coding' => '💻',
                                    'Graphic Design' => '🎨',
                                    'Web Development' => '🌐',
                                    'App Development' => '📱',
                                    'Photography' => '📸',
                                    'Video Editing' => '🎬',
                                    'Content Writing' => '✍️',
                                    'PPT / Presentation' => '📊',
                                    'Other' => '✨'
                                ];

                                echo $icons[$skill['category']] ?? '✨';

                                ?>

                            </div>

                        <?php endif; ?>


                        <div class="featured">
                            ✦ Student
                        </div>


                        <div class="status <?php echo $statusClass; ?>">

                            <?php
                            if($availability === 'Available'){
                                echo '● Available';
                            }
                            elseif($availability === 'Busy'){
                                echo '● Busy';
                            }
                            else{
                                echo '● Unavailable';
                            }
                            ?>

                        </div>

                    </div>


                    <!-- CONTENT -->

                    <div class="skill-content">

                        <span class="skill-category">

                            <?php
                            echo htmlspecialchars(
                                $skill['category'] ?: 'Student Skill'
                            );
                            ?>

                        </span>


                        <h3 class="skill-title">

                            <?php
                            echo htmlspecialchars(
                                $skill['title']
                            );
                            ?>

                        </h3>


                        <p class="skill-description">

                            <?php
                            echo htmlspecialchars(
                                $skill['description']
                                ?: 'Student is offering this skill through EduTrade.'
                            );
                            ?>

                        </p>


                        <!-- STUDENT -->

                        <div class="student">

                            <div class="student-avatar">
                                <?php echo $initial; ?>
                            </div>

                            <div class="student-info">

                                <div class="student-name">

                                    <?php
                                    echo htmlspecialchars(
                                        $studentName
                                    );
                                    ?>

                                </div>

                                <div class="experience">

                                    <?php
                                    echo !empty($skill['experience'])
                                        ? htmlspecialchars($skill['experience']) . ' experience'
                                        : 'EduTrade student';
                                    ?>

                                </div>

                            </div>

                        </div>


                        <!-- FOOTER -->

                        <div class="skill-footer">

                            <div class="price">

                                ₹<?php
                                echo number_format(
                                    (float)$skill['price'],
                                    0
                                );
                                ?>

                                <small>
                                    / project
                                </small>

                            </div>


                            <a
                                href="skill_profile.php?id=<?php echo (int)$skill['id']; ?>"
                                class="hire-btn"
                            >
                                View & Hire →
                            </a>

                        </div>

                    </div>

                </div>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="empty">

                <div class="empty-icon">
                    🔎
                </div>

                <h3>
                    No skills found
                </h3>

                <p>
                    Try another search or category,
                    or be the first student to add this skill.
                </p>

                <a
                    href="add_skills.php"
                    class="btn btn-primary"
                >
                    ✨ Add Your Skill
                </a>

            </div>

        <?php endif; ?>

    </div>

</section>


<!-- =====================================================
     FOOTER
===================================================== -->

<footer class="footer">

    © 2026 EduTrade PRO
    • Campus Marketplace
    • Skill Hub

</footer>

</div>

</body>
</html>