<?php

session_start();

require_once '../config/db.php';

/* =========================================================
   AUTHENTICATION
========================================================= */

if (
    !isset($_SESSION['logged_in']) ||
    $_SESSION['logged_in'] !== true
) {
    header("Location: ../includes/login.php");
    exit();
}


/* =========================================================
   DATABASE CHECK
========================================================= */

if (!isset($conn) || !$conn) {
    die("Database connection failed.");
}


/* =========================================================
   USER SESSION DATA
========================================================= */

$userId = (int)($_SESSION['user_id'] ?? 0);

$userName = trim(
    $_SESSION['name']
    ?? $_SESSION['username']
    ?? 'Student'
);

$userEmail = trim(
    $_SESSION['email']
    ?? ''
);

if ($userName === '') {
    $userName = 'Student';
}


/* =========================================================
   HELPER FUNCTIONS
========================================================= */

function clean($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


function getCount($conn, $query)
{
    $result = @mysqli_query($conn, $query);

    if (!$result) {
        return 0;
    }

    $row = mysqli_fetch_assoc($result);

    return (int)($row['total'] ?? 0);
}


function getInitial($name)
{
    $name = trim((string)$name);

    if ($name === '') {
        return 'S';
    }

    return strtoupper(
        substr($name, 0, 1)
    );
}


/* =========================================================
   PRODUCT IMAGE HELPER
========================================================= */

function getProductImage($image)
{
    $image = trim((string)$image);

    if ($image === '') {
        return '';
    }

    $image = str_replace('\\', '/', $image);

    $image = ltrim($image, '/');

    $filename = basename($image);

    if (
        $filename === '' ||
        $filename === '.' ||
        $filename === '..'
    ) {
        return '';
    }

    $physicalPath =
        dirname(__DIR__)
        . DIRECTORY_SEPARATOR
        . 'uploads'
        . DIRECTORY_SEPARATOR
        . 'products'
        . DIRECTORY_SEPARATOR
        . $filename;

    if (file_exists($physicalPath)) {

        return '../uploads/products/' .
            rawurlencode($filename);
    }

    return '../uploads/products/' .
        rawurlencode($filename);
}


/* =========================================================
   SKILL IMAGE HELPER
========================================================= */

function getSkillImage($image)
{
    $image = trim((string)$image);

    if ($image === '') {
        return '';
    }

    $image = str_replace('\\', '/', $image);

    $image = ltrim($image, '/');

    $filename = basename($image);

    if (
        $filename === '' ||
        $filename === '.' ||
        $filename === '..'
    ) {
        return '';
    }

    $physicalPath =
        dirname(__DIR__)
        . DIRECTORY_SEPARATOR
        . 'uploads'
        . DIRECTORY_SEPARATOR
        . 'skills'
        . DIRECTORY_SEPARATOR
        . $filename;

    if (file_exists($physicalPath)) {

        return '../uploads/skills/' .
            rawurlencode($filename);
    }

    return '../uploads/skills/' .
        rawurlencode($filename);
}


/* =========================================================
   PRODUCT CATEGORY DETECTION
========================================================= */

function getCategoryFromProduct($title, $description)
{
    $text = strtolower(
        $title . ' ' . $description
    );


    /* BOOKS */

    if (
        strpos($text, 'book') !== false ||
        strpos($text, 'textbook') !== false ||
        strpos($text, 'notes') !== false ||
        strpos($text, 'novel') !== false ||
        strpos($text, 'guide') !== false
    ) {
        return 'Books';
    }


    /* LAB */

    if (
        strpos($text, 'lab') !== false ||
        strpos($text, 'equipment') !== false ||
        strpos($text, 'multimeter') !== false ||
        strpos($text, 'breadboard') !== false ||
        strpos($text, 'arduino') !== false ||
        strpos($text, 'resistor') !== false ||
        strpos($text, 'circuit') !== false
    ) {
        return 'Lab';
    }


    /* ELECTRONICS */

    if (
        strpos($text, 'laptop') !== false ||
        strpos($text, 'mobile') !== false ||
        strpos($text, 'phone') !== false ||
        strpos($text, 'keyboard') !== false ||
        strpos($text, 'mouse') !== false ||
        strpos($text, 'calculator') !== false ||
        strpos($text, 'charger') !== false ||
        strpos($text, 'electronics') !== false ||
        strpos($text, 'earphone') !== false ||
        strpos($text, 'headphone') !== false
    ) {
        return 'Electronics';
    }


    /* STATIONERY */

    if (
        strpos($text, 'bag') !== false ||
        strpos($text, 'stationery') !== false ||
        strpos($text, 'pen') !== false ||
        strpos($text, 'pencil') !== false ||
        strpos($text, 'notebook') !== false ||
        strpos($text, 'file') !== false
    ) {
        return 'Stationery';
    }


    return 'Other';
}


/* =========================================================
   SKILL ICON
========================================================= */

function getSkillIcon(
    $title,
    $description,
    $category
) {

    $text = strtolower(
        $title .
        ' ' .
        $description .
        ' ' .
        $category
    );


    if (strpos($text, 'design') !== false) {
        return 'fa-pen-nib';
    }

    if (strpos($text, 'photo') !== false) {
        return 'fa-camera';
    }

    if (strpos($text, 'video') !== false) {
        return 'fa-video';
    }

    if (strpos($text, 'web') !== false) {
        return 'fa-globe';
    }

    if (strpos($text, 'app') !== false) {
        return 'fa-mobile-screen-button';
    }

    if (strpos($text, 'writing') !== false) {
        return 'fa-pen';
    }

    if (strpos($text, 'ppt') !== false) {
        return 'fa-file-powerpoint';
    }

    if (strpos($text, 'marketing') !== false) {
        return 'fa-bullhorn';
    }

    if (strpos($text, 'coding') !== false) {
        return 'fa-code';
    }

    return 'fa-wand-magic-sparkles';
}


/* =========================================================
   USER INITIAL
========================================================= */

$initial = getInitial($userName);


/* =========================================================
   DATABASE STATISTICS
========================================================= */

$totalStudents = getCount(
    $conn,
    "SELECT COUNT(*) AS total FROM users"
);


$totalProducts = getCount(
    $conn,
    "SELECT COUNT(*) AS total FROM products"
);


$totalSkills = getCount(
    $conn,
    "SELECT COUNT(*) AS total FROM skills"
);


/* =========================================================
   MY PRODUCTS
========================================================= */

$myProducts = getCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM products
     WHERE user_id = " . $userId
);


/* =========================================================
   MY SKILLS
========================================================= */

$mySkills = getCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM skills
     WHERE user_id = " . $userId
);


/* =========================================================
   INCOMING HIRE REQUESTS
========================================================= */

$incomingRequests = 0;

$requestCountQuery = @mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM hire_requests
     WHERE provider_id = " . $userId . "
        OR receiver_id = " . $userId
);

if ($requestCountQuery) {

    $requestRow =
        mysqli_fetch_assoc($requestCountQuery);

    $incomingRequests =
        (int)($requestRow['total'] ?? 0);
}


/* =========================================================
   SAVED PRODUCTS
========================================================= */

$savedProducts = 0;

$savedCountQuery = @mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM saved_products
     WHERE user_id = " . $userId
);

if ($savedCountQuery) {

    $savedRow =
        mysqli_fetch_assoc($savedCountQuery);

    $savedProducts =
        (int)($savedRow['total'] ?? 0);
}


/* =========================================================
   RECENT PRODUCTS
========================================================= */

$productsResult = @mysqli_query(
    $conn,
    "SELECT
        p.id,
        p.title,
        p.description,
        p.price,
        p.product_condition,
        p.image,
        p.product_age,
        p.created_at,
        p.user_id,
        u.name AS seller_name
     FROM products p
     LEFT JOIN users u
        ON p.user_id = u.id
     ORDER BY p.id DESC
     LIMIT 6"
);


/* =========================================================
   RECENT SKILLS
========================================================= */

$skillsResult = @mysqli_query(
    $conn,
    "SELECT
        s.id,
        s.user_id,
        s.title,
        s.category,
        s.description,
        s.experience,
        s.availability,
        s.image,
        s.price,
        s.created_at,
        u.name AS student_name
     FROM skills s
     LEFT JOIN users u
        ON s.user_id = u.id
     ORDER BY s.id DESC
     LIMIT 6"
);

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    EduTrade PRO | Student Dashboard
</title>


<link
    href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800;900&display=swap"
    rel="stylesheet"
>


<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

/* =========================================================
   ROOT
========================================================= */

:root {

    --bg:#030712;
    --bg-soft:#070d1d;

    --panel:rgba(255,255,255,.045);
    --panel-hover:rgba(255,255,255,.075);

    --border:rgba(255,255,255,.085);

    --border-hover:
        rgba(103,232,249,.30);

    --text:#f8fafc;

    --muted:#64748b;

    --muted-light:#94a3b8;

    --cyan:#22d3ee;

    --cyan-light:#67e8f9;

    --indigo:#6366f1;

    --purple:#a855f7;

    --green:#4ade80;

    --pink:#fb7185;

    --yellow:#facc15;

    --sidebar:260px;

    --radius:20px;
}


/* =========================================================
   RESET
========================================================= */

* {

    margin:0;
    padding:0;

    box-sizing:border-box;
}


html {
    scroll-behavior:smooth;
}


body {

    font-family:
        'Inter',
        'Poppins',
        sans-serif;

    background:

        radial-gradient(
            circle at 10% 10%,
            rgba(99,102,241,.09),
            transparent 30%
        ),

        radial-gradient(
            circle at 90% 90%,
            rgba(6,182,212,.07),
            transparent 30%
        ),

        var(--bg);

    color:var(--text);

    min-height:100vh;

    overflow-x:hidden;
}


/* =========================================================
   BACKGROUND ORBS
========================================================= */

body::before {

    content:"";

    position:fixed;

    width:520px;
    height:520px;

    top:-280px;
    left:-230px;

    border-radius:50%;

    background:
        radial-gradient(
            circle,
            rgba(99,102,241,.25),
            transparent 65%
        );

    filter:blur(55px);

    pointer-events:none;

    animation:
        orbOne 12s ease-in-out infinite;

    z-index:-1;
}


body::after {

    content:"";

    position:fixed;

    width:520px;
    height:520px;

    right:-270px;
    bottom:-270px;

    border-radius:50%;

    background:
        radial-gradient(
            circle,
            rgba(6,182,212,.20),
            transparent 65%
        );

    filter:blur(60px);

    pointer-events:none;

    animation:
        orbTwo 14s ease-in-out infinite;

    z-index:-1;
}


@keyframes orbOne {

    0%,100% {
        transform:translate(0,0);
    }

    50% {
        transform:translate(120px,100px);
    }
}


@keyframes orbTwo {

    0%,100% {
        transform:translate(0,0);
    }

    50% {
        transform:translate(-100px,-80px);
    }
}


/* =========================================================
   APP
========================================================= */

.app {
    min-height:100vh;
}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar {

    position:fixed;

    left:0;
    top:0;
    bottom:0;

    width:var(--sidebar);

    padding:22px 15px;

    background:
        linear-gradient(
            180deg,
            rgba(7,13,29,.97),
            rgba(2,6,23,.99)
        );

    border-right:
        1px solid var(--border);

    backdrop-filter:blur(30px);

    z-index:2000;

    overflow-y:auto;

    transition:
        transform .35s ease;
}


.sidebar::-webkit-scrollbar {
    width:4px;
}


.sidebar::-webkit-scrollbar-thumb {

    background:#1e293b;

    border-radius:20px;
}


/* =========================================================
   BRAND
========================================================= */

.brand {

    display:flex;

    align-items:center;

    gap:11px;

    padding:
        6px 10px 27px;
}


.brand-icon {

    width:44px;
    height:44px;

    display:flex;

    align-items:center;
    justify-content:center;

    border-radius:14px;

    background:
        linear-gradient(
            135deg,
            #06b6d4,
            #6366f1,
            #a855f7
        );

    box-shadow:
        0 0 35px
        rgba(99,102,241,.30);

    font-size:19px;
}


.brand-name {

    font-size:19px;

    font-weight:900;

    letter-spacing:-.6px;

    background:
        linear-gradient(
            90deg,
            #67e8f9,
            #818cf8,
            #c084fc
        );

    -webkit-background-clip:text;

    background-clip:text;

    color:transparent;
}


.brand-pro {

    display:inline-block;

    margin-left:4px;

    padding:3px 6px;

    border-radius:6px;

    font-size:8px;

    color:#d8b4fe;

    background:
        rgba(168,85,247,.12);

    border:
        1px solid
        rgba(168,85,247,.25);
}


/* =========================================================
   NAVIGATION
========================================================= */

.nav-section-title {

    padding:15px 11px 7px;

    color:#475569;

    font-size:9px;

    font-weight:800;

    letter-spacing:1.5px;

    text-transform:uppercase;
}


.nav-link {

    display:flex;

    align-items:center;

    gap:12px;

    width:100%;

    padding:11px 12px;

    margin:3px 0;

    border-radius:12px;

    text-decoration:none;

    color:#94a3b8;

    font-size:12px;

    font-weight:600;

    transition:.25s ease;

    position:relative;
}


.nav-link i {

    width:19px;

    text-align:center;

    font-size:14px;

    flex-shrink:0;
}


.nav-link:hover {

    color:white;

    background:
        rgba(255,255,255,.055);

    transform:translateX(3px);
}


.nav-link.active {

    color:white;

    background:
        linear-gradient(
            100deg,
            rgba(99,102,241,.30),
            rgba(6,182,212,.10)
        );

    border:
        1px solid
        rgba(129,140,248,.16);

    box-shadow:
        inset 3px 0 0
        #67e8f9;
}


.nav-link.active i {
    color:#67e8f9;
}


/* =========================================================
   NAV BADGE
========================================================= */

.nav-badge {

    margin-left:auto;

    min-width:19px;

    height:19px;

    padding:0 5px;

    display:flex;

    align-items:center;

    justify-content:center;

    border-radius:20px;

    color:white;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #a855f7
        );

    font-size:8px;

    font-weight:900;
}


/* =========================================================
   SIDEBAR PROFILE
========================================================= */

.sidebar-profile {

    margin-top:22px;

    padding:13px;

    border-radius:17px;

    background:
        linear-gradient(
            135deg,
            rgba(255,255,255,.06),
            rgba(255,255,255,.025)
        );

    border:
        1px solid
        rgba(255,255,255,.07);
}


.sidebar-profile-inner {

    display:flex;

    align-items:center;

    gap:10px;
}


.avatar {

    width:38px;
    height:38px;

    flex-shrink:0;

    display:flex;

    align-items:center;
    justify-content:center;

    border-radius:12px;

    background:
        linear-gradient(
            135deg,
            #06b6d4,
            #6366f1
        );

    font-weight:900;
}


.sidebar-profile strong {

    display:block;

    max-width:150px;

    overflow:hidden;

    white-space:nowrap;

    text-overflow:ellipsis;

    font-size:11px;
}


.sidebar-profile span {

    display:block;

    margin-top:3px;

    color:#64748b;

    font-size:9px;
}


/* =========================================================
   MAIN
========================================================= */

.main {

    margin-left:var(--sidebar);

    width:
        calc(100% - var(--sidebar));

    min-height:100vh;

    padding:
        25px 30px 45px;
}


/* =========================================================
   TOPBAR
========================================================= */

.topbar {

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:20px;

    margin-bottom:24px;
}


.top-left {

    display:flex;

    align-items:center;

    gap:13px;
}


.mobile-menu {

    display:none;

    width:42px;
    height:42px;

    border:
        1px solid
        var(--border);

    border-radius:12px;

    background:
        rgba(255,255,255,.04);

    color:white;

    cursor:pointer;
}


.page-title {

    font-size:22px;

    font-weight:900;

    letter-spacing:-.7px;
}


.page-subtitle {

    margin-top:3px;

    color:#64748b;

    font-size:10px;
}


/* =========================================================
   SEARCH
========================================================= */

.search-wrapper {
    width:360px;
}


.search {

    display:flex;

    align-items:center;

    gap:10px;

    padding:11px 14px;

    border-radius:13px;

    background:
        rgba(255,255,255,.04);

    border:
        1px solid
        var(--border);

    transition:.25s;
}


.search:focus-within {

    border-color:
        rgba(103,232,249,.35);

    box-shadow:
        0 0 30px
        rgba(6,182,212,.07);
}


.search i {
    color:#475569;
}


.search input {

    width:100%;

    border:0;

    outline:0;

    background:transparent;

    color:white;

    font-family:inherit;

    font-size:11px;
}


.search input::placeholder {
    color:#475569;
}


/* =========================================================
   TOP ACTIONS
========================================================= */

.top-actions {

    display:flex;

    align-items:center;

    gap:8px;
}


.top-btn {

    width:41px;
    height:41px;

    border:
        1px solid
        var(--border);

    border-radius:12px;

    background:
        rgba(255,255,255,.04);

    color:#94a3b8;

    display:flex;

    align-items:center;
    justify-content:center;

    cursor:pointer;

    transition:.25s;

    position:relative;

    text-decoration:none;
}


.top-btn:hover {

    color:white;

    border-color:
        var(--border-hover);

    transform:translateY(-2px);
}


.notification-dot {

    position:absolute;

    width:6px;
    height:6px;

    border-radius:50%;

    top:8px;
    right:8px;

    background:#fb7185;

    box-shadow:
        0 0 10px
        #fb7185;
}


/* =========================================================
   HERO
========================================================= */

.hero {

    position:relative;

    overflow:hidden;

    padding:31px;

    border-radius:24px;

    border:
        1px solid
        rgba(129,140,248,.18);

    background:
        linear-gradient(
            120deg,
            rgba(49,46,129,.42),
            rgba(6,182,212,.10),
            rgba(88,28,135,.20)
        );

    box-shadow:
        0 25px 70px
        rgba(0,0,0,.25);
}


.hero::before {

    content:"";

    position:absolute;

    width:330px;
    height:330px;

    right:-130px;
    top:-170px;

    border-radius:50%;

    background:
        radial-gradient(
            circle,
            rgba(34,211,238,.24),
            transparent 65%
        );

    filter:blur(20px);

    animation:
        heroFloat 8s ease-in-out infinite;
}


.hero::after {

    content:"";

    position:absolute;

    width:200px;
    height:200px;

    left:45%;
    bottom:-150px;

    border-radius:50%;

    background:
        radial-gradient(
            circle,
            rgba(168,85,247,.20),
            transparent 65%
        );

    filter:blur(25px);
}


@keyframes heroFloat {

    0%,100% {
        transform:
            translate(0,0)
            scale(1);
    }

    50% {
        transform:
            translate(-30px,40px)
            scale(1.15);
    }
}


.hero-content {

    position:relative;

    z-index:2;

    max-width:720px;
}


.hero-tag {

    display:inline-flex;

    align-items:center;

    gap:7px;

    padding:6px 10px;

    border-radius:30px;

    background:
        rgba(34,211,238,.08);

    border:
        1px solid
        rgba(34,211,238,.18);

    color:#67e8f9;

    font-size:9px;

    font-weight:800;

    letter-spacing:1px;

    text-transform:uppercase;
}


.hero h1 {

    margin-top:15px;

    font-size:34px;

    line-height:1.15;

    letter-spacing:-1.5px;
}


.gradient {

    background:
        linear-gradient(
            90deg,
            #67e8f9,
            #818cf8,
            #c084fc
        );

    -webkit-background-clip:text;

    background-clip:text;

    color:transparent;
}


.hero-description {

    margin-top:12px;

    max-width:620px;

    color:#94a3b8;

    font-size:12px;

    line-height:1.75;
}


.hero-actions {

    display:flex;

    gap:9px;

    flex-wrap:wrap;

    margin-top:21px;
}


/* =========================================================
   BUTTONS
========================================================= */

.btn {

    display:inline-flex;

    align-items:center;

    justify-content:center;

    gap:8px;

    padding:11px 16px;

    border-radius:11px;

    text-decoration:none;

    font-size:10px;

    font-weight:800;

    transition:.3s;
}


.btn-primary {

    color:white;

    background:
        linear-gradient(
            135deg,
            #06b6d4,
            #6366f1
        );

    box-shadow:
        0 10px 30px
        rgba(99,102,241,.20);
}


.btn-primary:hover {

    transform:translateY(-3px);

    box-shadow:
        0 16px 35px
        rgba(99,102,241,.30);
}


.btn-secondary {

    color:#cbd5e1;

    background:
        rgba(255,255,255,.055);

    border:
        1px solid
        rgba(255,255,255,.10);
}


.btn-secondary:hover {

    color:white;

    background:
        rgba(255,255,255,.09);

    transform:translateY(-2px);
}


/* =========================================================
   STATS
========================================================= */

.stats {

    display:grid;

    grid-template-columns:
        repeat(4,minmax(0,1fr));

    gap:13px;

    margin-top:18px;
}


.stat {

    padding:18px;

    border-radius:18px;

    background:
        rgba(255,255,255,.035);

    border:
        1px solid
        var(--border);

    transition:.3s;
}


.stat:hover {

    transform:translateY(-5px);

    border-color:
        rgba(129,140,248,.24);

    background:
        rgba(255,255,255,.05);
}


.stat-top {

    display:flex;

    justify-content:space-between;

    align-items:center;
}


.stat-icon {

    width:37px;
    height:37px;

    border-radius:11px;

    display:flex;

    align-items:center;
    justify-content:center;
}


.blue {

    color:#67e8f9;

    background:
        rgba(6,182,212,.10);
}


.purple {

    color:#c084fc;

    background:
        rgba(168,85,247,.10);
}


.pink {

    color:#f9a8d4;

    background:
        rgba(236,72,153,.10);
}


.green {

    color:#86efac;

    background:
        rgba(34,197,94,.10);
}


.stat-number {

    margin-top:13px;

    font-size:25px;

    font-weight:900;
}


.stat-label {

    margin-top:3px;

    color:#64748b;

    font-size:9px;
}


.stat-note {

    margin-top:8px;

    color:#4ade80;

    font-size:8px;
}


/* =========================================================
   SECTION
========================================================= */

.section {
    margin-top:30px;
}


.section-head {

    display:flex;

    align-items:flex-end;

    justify-content:space-between;

    gap:15px;

    margin-bottom:14px;
}


.section-title {

    font-size:17px;

    font-weight:900;

    letter-spacing:-.4px;
}


.section-description {

    margin-top:4px;

    color:#64748b;

    font-size:9px;
}


.view-all {

    color:#67e8f9;

    text-decoration:none;

    font-size:9px;

    font-weight:700;
}


.view-all:hover {
    color:white;
}


/* =========================================================
   QUICK ACTIONS
========================================================= */

.quick-grid {

    display:grid;

    grid-template-columns:
        repeat(4,minmax(0,1fr));

    gap:12px;
}


.quick-card {

    display:flex;

    align-items:center;

    gap:11px;

    padding:15px;

    border-radius:16px;

    text-decoration:none;

    color:white;

    background:
        rgba(255,255,255,.035);

    border:
        1px solid
        var(--border);

    transition:.3s;
}


.quick-card:hover {

    transform:translateY(-4px);

    background:
        rgba(255,255,255,.065);

    border-color:
        rgba(103,232,249,.22);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.20);
}


.quick-icon {

    width:39px;
    height:39px;

    flex-shrink:0;

    display:flex;

    align-items:center;
    justify-content:center;

    border-radius:11px;

    color:#67e8f9;

    background:
        linear-gradient(
            135deg,
            rgba(99,102,241,.18),
            rgba(6,182,212,.10)
        );
}


.quick-card strong {

    display:block;

    font-size:10px;
}


.quick-card span {

    display:block;

    margin-top:3px;

    color:#64748b;

    font-size:8px;
}


/* =========================================================
   FILTER
========================================================= */

.filter-bar {

    display:flex;

    align-items:center;

    gap:5px;

    padding:5px;

    width:max-content;

    max-width:100%;

    overflow-x:auto;

    border:
        1px solid
        var(--border);

    border-radius:13px;

    background:
        rgba(255,255,255,.03);

    margin-bottom:15px;
}


.filter-btn {

    border:0;

    padding:8px 13px;

    border-radius:9px;

    background:transparent;

    color:#64748b;

    font-family:inherit;

    font-size:9px;

    font-weight:800;

    cursor:pointer;

    white-space:nowrap;

    transition:.25s;
}


.filter-btn:hover {
    color:white;
}


.filter-btn.active {

    color:white;

    background:
        linear-gradient(
            135deg,
            rgba(99,102,241,.55),
            rgba(6,182,212,.25)
        );
}


/* =========================================================
   PRODUCT GRID
========================================================= */

.product-grid {

    display:grid;

    grid-template-columns:
        repeat(3,minmax(0,1fr));

    gap:14px;
}


.product-card {

    overflow:hidden;

    border-radius:18px;

    background:
        rgba(255,255,255,.035);

    border:
        1px solid
        var(--border);

    transition:.35s;

    text-decoration:none;

    color:white;
}


.product-card:hover {

    transform:translateY(-6px);

    border-color:
        rgba(103,232,249,.24);

    box-shadow:
        0 20px 45px
        rgba(0,0,0,.25);
}


/* =========================================================
   PRODUCT IMAGE
========================================================= */

.product-image {

    width:100%;

    height:190px;

    position:relative;

    overflow:hidden;

    background:
        linear-gradient(
            135deg,
            #0f172a,
            #111827
        );
}


.product-image img {

    display:block;

    width:100%;

    height:100%;

    max-width:100%;

    object-fit:cover;

    object-position:center;

    transition:
        transform .5s ease;

    background:#0f172a;
}


.product-card:hover
.product-image img {

    transform:scale(1.08);
}


/* =========================================================
   IMAGE FALLBACK
========================================================= */

.no-image {

    width:100%;

    height:100%;

    display:flex;

    align-items:center;

    justify-content:center;

    color:#334155;

    background:
        radial-gradient(
            circle at center,
            rgba(99,102,241,.15),
            transparent 60%
        );

    font-size:30px;
}


/* =========================================================
   BADGES
========================================================= */

.condition-badge {

    position:absolute;

    left:10px;

    top:10px;

    padding:5px 8px;

    border-radius:20px;

    color:#67e8f9;

    background:
        rgba(2,6,23,.78);

    border:
        1px solid
        rgba(255,255,255,.08);

    backdrop-filter:blur(10px);

    font-size:7px;

    font-weight:800;

    z-index:2;
}


.category-badge {

    position:absolute;

    right:10px;

    top:10px;

    padding:5px 8px;

    border-radius:20px;

    color:#ddd6fe;

    background:
        rgba(76,29,149,.72);

    border:
        1px solid
        rgba(196,181,253,.12);

    font-size:7px;

    font-weight:800;

    z-index:2;
}


/* =========================================================
   PRODUCT BODY
========================================================= */

.product-body {
    padding:15px;
}


.product-title {

    font-size:12px;

    font-weight:800;

    white-space:nowrap;

    overflow:hidden;

    text-overflow:ellipsis;
}


.product-description {

    margin-top:7px;

    height:29px;

    overflow:hidden;

    color:#64748b;

    font-size:8px;

    line-height:1.7;
}


.product-bottom {

    display:flex;

    align-items:center;

    justify-content:space-between;

    margin-top:13px;
}


.price {

    color:#67e8f9;

    font-size:17px;

    font-weight:900;
}


.age {

    color:#64748b;

    font-size:8px;
}


.seller {

    display:flex;

    align-items:center;

    gap:7px;

    margin-top:12px;

    padding-top:11px;

    border-top:
        1px solid
        rgba(255,255,255,.055);
}


.seller-avatar {

    width:25px;
    height:25px;

    border-radius:8px;

    display:flex;

    align-items:center;
    justify-content:center;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #06b6d4
        );

    font-size:8px;

    font-weight:900;
}


.seller-name {

    color:#94a3b8;

    font-size:8px;
}


/* =========================================================
   SKILL GRID
========================================================= */

.skill-grid {

    display:grid;

    grid-template-columns:
        repeat(3,minmax(0,1fr));

    gap:14px;
}


.skill-card {

    position:relative;

    overflow:hidden;

    padding:18px;

    border-radius:18px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.055),
            rgba(255,255,255,.025)
        );

    border:
        1px solid
        var(--border);

    transition:.35s;
}


.skill-card:hover {

    transform:translateY(-6px);

    border-color:
        rgba(192,132,252,.25);

    box-shadow:
        0 20px 45px
        rgba(0,0,0,.25);
}


.skill-card::after {

    content:"";

    position:absolute;

    width:120px;
    height:120px;

    right:-60px;
    top:-60px;

    border-radius:50%;

    background:
        rgba(168,85,247,.15);

    filter:blur(30px);
}


.skill-top {

    display:flex;

    align-items:center;

    justify-content:space-between;
}


.skill-icon {

    width:42px;
    height:42px;

    border-radius:12px;

    display:flex;

    align-items:center;
    justify-content:center;

    color:#c084fc;

    background:
        linear-gradient(
            135deg,
            rgba(168,85,247,.20),
            rgba(99,102,241,.12)
        );
}


.available {

    color:#4ade80;

    padding:5px 8px;

    border-radius:20px;

    background:
        rgba(34,197,94,.07);

    border:
        1px solid
        rgba(34,197,94,.12);

    font-size:7px;

    font-weight:800;
}


.skill-name {

    margin-top:14px;

    font-size:13px;

    font-weight:800;
}


.skill-description {

    margin-top:6px;

    min-height:31px;

    color:#64748b;

    font-size:8px;

    line-height:1.7;
}


.skill-footer {

    display:flex;

    align-items:center;

    justify-content:space-between;

    margin-top:15px;

    padding-top:12px;

    border-top:
        1px solid
        rgba(255,255,255,.055);
}


.rating {

    color:#facc15;

    font-size:8px;
}


.hire-btn {

    padding:7px 10px;

    border-radius:8px;

    text-decoration:none;

    color:white;

    background:
        linear-gradient(
            135deg,
            #7c3aed,
            #6366f1
        );

    font-size:8px;

    font-weight:800;
}


/* =========================================================
   BOTTOM GRID
========================================================= */

.bottom-grid {

    display:grid;

    grid-template-columns:
        1.35fr
        .65fr;

    gap:14px;
}


.info-card {

    padding:19px;

    border-radius:18px;

    background:
        rgba(255,255,255,.035);

    border:
        1px solid
        var(--border);
}


.info-card-title {

    font-size:14px;

    font-weight:900;
}


.info-card-subtitle {

    margin-top:4px;

    color:#64748b;

    font-size:8px;
}


/* =========================================================
   ACTIVITY
========================================================= */

.activity {
    margin-top:14px;
}


.activity-item {

    display:flex;

    gap:11px;

    padding:12px 0;

    border-bottom:
        1px solid
        rgba(255,255,255,.055);
}


.activity-item:last-child {
    border-bottom:0;
}


.activity-icon {

    width:34px;
    height:34px;

    flex-shrink:0;

    display:flex;

    align-items:center;
    justify-content:center;

    border-radius:10px;

    color:#818cf8;

    background:
        rgba(99,102,241,.10);

    font-size:10px;
}


.activity-item strong {

    display:block;

    font-size:9px;
}


.activity-item span {

    display:block;

    margin-top:3px;

    color:#64748b;

    font-size:8px;

    line-height:1.5;
}


/* =========================================================
   PROFILE
========================================================= */

.profile-user {

    display:flex;

    align-items:center;

    gap:12px;
}


.profile-avatar {

    width:48px;
    height:48px;

    border-radius:15px;

    display:flex;

    align-items:center;
    justify-content:center;

    background:
        linear-gradient(
            135deg,
            #06b6d4,
            #6366f1,
            #a855f7
        );

    font-size:17px;

    font-weight:900;
}


.profile-user strong {

    display:block;

    font-size:12px;
}


.profile-user span {

    display:block;

    margin-top:4px;

    color:#64748b;

    font-size:8px;

    word-break:break-all;
}


.profile-divider {

    height:1px;

    background:
        rgba(255,255,255,.055);

    margin:18px 0;
}


.profile-stat {

    display:flex;

    align-items:center;

    justify-content:space-between;

    padding:9px 0;
}


.profile-stat span {

    color:#64748b;

    font-size:8px;
}


.profile-stat strong {

    color:#e2e8f0;

    font-size:10px;
}


/* =========================================================
   EMPTY
========================================================= */

.empty {

    grid-column:1/-1;

    padding:38px 20px;

    text-align:center;

    border:
        1px dashed
        rgba(255,255,255,.12);

    border-radius:18px;

    background:
        rgba(255,255,255,.02);
}


.empty i {

    display:block;

    margin-bottom:10px;

    color:#334155;

    font-size:30px;
}


.empty p {

    color:#64748b;

    font-size:10px;
}


/* =========================================================
   FOOTER
========================================================= */

.footer {

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:15px;

    margin-top:38px;

    padding-top:18px;

    border-top:
        1px solid
        rgba(255,255,255,.05);

    color:#334155;

    font-size:8px;
}


/* =========================================================
   ANIMATION
========================================================= */

.reveal {

    animation:
        reveal .65s ease both;
}


.delay-1 {
    animation-delay:.08s;
}


.delay-2 {
    animation-delay:.16s;
}


.delay-3 {
    animation-delay:.24s;
}


.delay-4 {
    animation-delay:.32s;
}


@keyframes reveal {

    from {

        opacity:0;

        transform:
            translateY(18px);
    }

    to {

        opacity:1;

        transform:
            translateY(0);
    }
}


/* =========================================================
   SIDEBAR OVERLAY
========================================================= */

.sidebar-overlay {

    display:none;

    position:fixed;

    inset:0;

    background:
        rgba(0,0,0,.60);

    backdrop-filter:blur(4px);

    z-index:1500;
}


.sidebar-overlay.show {
    display:block;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:1200px) {

    .stats {

        grid-template-columns:
            repeat(2,1fr);
    }

    .quick-grid {

        grid-template-columns:
            repeat(2,1fr);
    }

    .product-grid,
    .skill-grid {

        grid-template-columns:
            repeat(2,1fr);
    }

    .search-wrapper {
        width:280px;
    }
}


@media(max-width:950px) {

    :root {
        --sidebar:250px;
    }

    .sidebar {

        transform:
            translateX(-100%);
    }

    .sidebar.open {

        transform:
            translateX(0);

        box-shadow:
            20px 0 60px
            rgba(0,0,0,.45);
    }

    .main {

        margin-left:0;

        width:100%;

        padding:20px;
    }

    .mobile-menu {

        display:flex;

        align-items:center;

        justify-content:center;
    }

    .bottom-grid {
        grid-template-columns:1fr;
    }
}


@media(max-width:700px) {

    .topbar {

        align-items:flex-start;
    }

    .search-wrapper {
        display:none;
    }

    .top-actions {
        display:none;
    }

    .hero {
        padding:24px;
    }

    .hero h1 {
        font-size:27px;
    }

    .stats {
        grid-template-columns:1fr 1fr;
    }

    .product-grid,
    .skill-grid {
        grid-template-columns:1fr;
    }
}


@media(max-width:520px) {

    .main {
        padding:15px;
    }

    .page-title {
        font-size:18px;
    }

    .page-subtitle {
        font-size:8px;
    }

    .stats {
        grid-template-columns:1fr;
    }

    .quick-grid {
        grid-template-columns:1fr;
    }

    .hero h1 {
        font-size:24px;
    }

    .hero-description {
        font-size:10px;
    }

    .hero-actions {
        flex-direction:column;
    }

    .hero-actions .btn {
        width:100%;
    }

    .section-head {

        align-items:flex-start;

        flex-direction:column;
    }

    .filter-bar {
        width:100%;
    }

    .footer {

        flex-direction:column;

        align-items:flex-start;
    }
}

</style>

</head>


<body>


<div
    class="sidebar-overlay"
    id="sidebarOverlay"
    onclick="closeSidebar()"
></div>


<div class="app">


<!-- =====================================================
     SIDEBAR
====================================================== -->

<aside
    class="sidebar"
    id="sidebar"
>


    <!-- BRAND -->

    <div class="brand">

        <div class="brand-icon">

            <i class="fa-solid fa-graduation-cap"></i>

        </div>

        <div class="brand-name">

            EduTrade

            <span class="brand-pro">
                PRO
            </span>

        </div>

    </div>


    <!-- MAIN -->

    <div class="nav-section-title">
        Main
    </div>


    <a
        href="dashboard.php"
        class="nav-link active"
    >

        <i class="fa-solid fa-house"></i>

        <span>
            Overview
        </span>

    </a>


    <a
        href="marketplace.php"
        class="nav-link"
    >

        <i class="fa-solid fa-store"></i>

        <span>
            Marketplace
        </span>

    </a>


    <a
        href="skills.php"
        class="nav-link"
    >

        <i class="fa-solid fa-wand-magic-sparkles"></i>

        <span>
            Skill Hub
        </span>

    </a>


    <!-- CAMPUS MARKETPLACE -->

    <div class="nav-section-title">
        Campus Marketplace
    </div>


    <a
        href="marketplace.php"
        class="nav-link"
    >

        <i class="fa-solid fa-book"></i>

        <span>
            Books
        </span>

    </a>


    <a
        href="marketplace.php"
        class="nav-link"
    >

        <i class="fa-solid fa-flask"></i>

        <span>
            Lab Equipment
        </span>

    </a>


    <a
        href="marketplace.php"
        class="nav-link"
    >

        <i class="fa-solid fa-laptop"></i>

        <span>
            Electronics
        </span>

    </a>


    <a
        href="marketplace.php"
        class="nav-link"
    >

        <i class="fa-solid fa-briefcase"></i>

        <span>
            Bags & Stationery
        </span>

    </a>


    <!-- CREATE -->

    <div class="nav-section-title">
        Create
    </div>


    <a
        href="add_product.php"
        class="nav-link"
    >

        <i class="fa-solid fa-plus"></i>

        <span>
            Sell Product
        </span>

    </a>


    <a
        href="add_skills.php"
        class="nav-link"
    >

        <i class="fa-solid fa-star"></i>

        <span>
            Add Your Skill
        </span>

    </a>


    <!-- =================================================
         MY SPACE
    ================================================== -->

    <div class="nav-section-title">
        My Space
    </div>


    <!-- FIXED WISHLIST -->

    <a
        href="wishlist.php"
        class="nav-link"
    >

        <i class="fa-regular fa-heart"></i>

        <span>
            Wishlist
        </span>

        <?php if ($savedProducts > 0): ?>

            <span class="nav-badge">
                <?php
                echo number_format($savedProducts);
                ?>
            </span>

        <?php endif; ?>

    </a>


    <!-- FIXED HIRE / REQUESTS -->

    <a
        href="hire_requests.php"
        class="nav-link"
    >

        <i class="fa-solid fa-paper-plane"></i>

        <span>
            Hire / Requests
        </span>

        <?php if ($incomingRequests > 0): ?>

            <span class="nav-badge">
                <?php
                echo number_format($incomingRequests);
                ?>
            </span>

        <?php endif; ?>

    </a>


    <!-- =================================================
         IMPORTANT:
         MESSAGES BUTTON REMOVED
    ================================================== -->


    <!-- SIDEBAR PROFILE -->

    <div class="sidebar-profile">

        <div class="sidebar-profile-inner">


            <div class="avatar">

                <?php
                echo clean($initial);
                ?>

            </div>


            <div>

                <strong>

                    <?php
                    echo clean($userName);
                    ?>

                </strong>


                <span>
                    Student Account
                </span>

            </div>


        </div>

    </div>


    <!-- LOGOUT -->

    <a
        href="../includes/auth.php?logout=true"
        class="nav-link"
        style="
            color:#fb7185;
            margin-top:8px;
        "
    >

        <i class="fa-solid fa-right-from-bracket"></i>

        <span>
            Logout
        </span>

    </a>


</aside>


<!-- =====================================================
     MAIN
====================================================== -->

<main class="main">


<!-- =====================================================
     TOPBAR
====================================================== -->

<header class="topbar">


    <div class="top-left">


        <button
            class="mobile-menu"
            onclick="toggleSidebar()"
            aria-label="Open menu"
            type="button"
        >

            <i class="fa-solid fa-bars"></i>

        </button>


        <div>

            <div class="page-title">
                Student Dashboard
            </div>

            <div class="page-subtitle">
                Your campus marketplace & student skill network
            </div>

        </div>


    </div>


    <!-- SEARCH -->

    <div class="search-wrapper">

        <div class="search">

            <i
                class="fa-solid fa-magnifying-glass"
            ></i>


            <input
                type="text"
                id="globalSearch"
                placeholder="Search products..."
                autocomplete="off"
            >

        </div>

    </div>


    <!-- TOP ACTIONS -->

    <div class="top-actions">


        <!-- NOTIFICATION -->

        <a
            href="hire_requests.php"
            class="top-btn"
            title="Hire Requests"
        >

            <i class="fa-regular fa-bell"></i>

            <?php if ($incomingRequests > 0): ?>

                <span class="notification-dot"></span>

            <?php endif; ?>

        </a>


        <!-- PROFILE -->

        <button
            class="top-btn"
            title="Profile"
            type="button"
            onclick="
                document
                .getElementById('profile')
                .scrollIntoView({
                    behavior:'smooth'
                })
            "
        >

            <i class="fa-regular fa-user"></i>

        </button>


    </div>


</header>


<!-- =====================================================
     HERO
====================================================== -->

<section class="hero reveal">


    <div class="hero-content">


        <span class="hero-tag">

            <i class="fa-solid fa-sparkles"></i>

            EduTrade Campus Network

        </span>


        <h1>

            Welcome back,

            <span class="gradient">

                <?php
                echo clean($userName);
                ?>

            </span>

            👋

        </h1>


        <p class="hero-description">

            Buy what you need, sell what you no longer use,
            showcase your skills and connect with students
            across your campus — all in one place.

        </p>


        <div class="hero-actions">


            <a
                href="marketplace.php"
                class="btn btn-primary"
            >

                <i class="fa-solid fa-store"></i>

                Explore Marketplace

            </a>


            <a
                href="skills.php"
                class="btn btn-secondary"
            >

                <i class="fa-solid fa-wand-magic-sparkles"></i>

                Explore Skill Hub

            </a>


            <a
                href="add_product.php"
                class="btn btn-secondary"
            >

                <i class="fa-solid fa-plus"></i>

                Sell Something

            </a>


        </div>


    </div>


</section>


<!-- =====================================================
     STATISTICS
====================================================== -->

<section class="stats">


    <!-- MY PRODUCTS -->

    <div class="stat reveal delay-1">

        <div class="stat-top">

            <div class="stat-icon blue">

                <i class="fa-solid fa-box-open"></i>

            </div>

        </div>


        <div class="stat-number">

            <?php
            echo number_format($myProducts);
            ?>

        </div>


        <div class="stat-label">
            My Products
        </div>


        <div class="stat-note">

            <i class="fa-solid fa-arrow-up"></i>

            Your listings

        </div>

    </div>


    <!-- SKILLS -->

    <div class="stat reveal delay-2">

        <div class="stat-top">

            <div class="stat-icon purple">

                <i
                    class="fa-solid fa-wand-magic-sparkles"
                ></i>

            </div>

        </div>


        <div class="stat-number">

            <?php
            echo number_format($totalSkills);
            ?>

        </div>


        <div class="stat-label">
            Skills Available
        </div>


        <div class="stat-note">

            <i class="fa-solid fa-bolt"></i>

            Skill Hub

        </div>

    </div>


    <!-- MARKETPLACE -->

    <div class="stat reveal delay-3">

        <div class="stat-top">

            <div class="stat-icon pink">

                <i class="fa-solid fa-store"></i>

            </div>

        </div>


        <div class="stat-number">

            <?php
            echo number_format($totalProducts);
            ?>

        </div>


        <div class="stat-label">
            Marketplace Products
        </div>


        <div class="stat-note">

            <i class="fa-solid fa-chart-line"></i>

            Campus listings

        </div>

    </div>


    <!-- STUDENTS -->

    <div class="stat reveal delay-4">

        <div class="stat-top">

            <div class="stat-icon green">

                <i class="fa-solid fa-users"></i>

            </div>

        </div>


        <div class="stat-number">

            <?php
            echo number_format($totalStudents);
            ?>

        </div>


        <div class="stat-label">
            Student Community
        </div>


        <div class="stat-note">

            <i class="fa-solid fa-circle-check"></i>

            Connected

        </div>

    </div>


</section>


<!-- =====================================================
     QUICK ACTIONS
====================================================== -->

<section class="section">


    <div class="section-head">

        <div>

            <div class="section-title">
                Quick Actions
            </div>

            <div class="section-description">
                Everything important is one click away
            </div>

        </div>

    </div>


    <div class="quick-grid">


        <!-- SELL -->

        <a
            href="add_product.php"
            class="quick-card"
        >

            <div class="quick-icon">

                <i class="fa-solid fa-plus"></i>

            </div>


            <div>

                <strong>
                    Sell a Product
                </strong>

                <span>
                    Create a campus listing
                </span>

            </div>

        </a>


        <!-- SKILL -->

        <a
            href="add_skills.php"
            class="quick-card"
        >

            <div class="quick-icon">

                <i class="fa-solid fa-star"></i>

            </div>


            <div>

                <strong>
                    Add Your Skill
                </strong>

                <span>
                    Showcase your talent
                </span>

            </div>

        </a>


        <!-- FIND PRODUCT -->

        <a
            href="marketplace.php"
            class="quick-card"
        >

            <div class="quick-icon">

                <i
                    class="fa-solid fa-magnifying-glass"
                ></i>

            </div>


            <div>

                <strong>
                    Find Products
                </strong>

                <span>
                    Browse campus items
                </span>

            </div>

        </a>


        <!-- FIND TALENT -->

        <a
            href="skills.php"
            class="quick-card"
        >

            <div class="quick-icon">

                <i class="fa-solid fa-user-group"></i>

            </div>


            <div>

                <strong>
                    Find Talent
                </strong>

                <span>
                    Hire a student
                </span>

            </div>

        </a>


    </div>


</section>


<!-- =====================================================
     MARKETPLACE
====================================================== -->

<section class="section">


    <div class="section-head">


        <div>

            <div class="section-title">
                🛒 Marketplace
            </div>

            <div class="section-description">
                Latest products listed by students
            </div>

        </div>


        <a
            href="marketplace.php"
            class="view-all"
        >

            View Marketplace

            <i class="fa-solid fa-arrow-right"></i>

        </a>


    </div>


    <!-- FILTERS -->

    <div class="filter-bar">


        <button
            type="button"
            class="filter-btn active"
            data-filter="all"
        >
            Latest
        </button>


        <button
            type="button"
            class="filter-btn"
            data-filter="Books"
        >
            Books
        </button>


        <button
            type="button"
            class="filter-btn"
            data-filter="Lab"
        >
            Lab
        </button>


        <button
            type="button"
            class="filter-btn"
            data-filter="Electronics"
        >
            Electronics
        </button>


        <button
            type="button"
            class="filter-btn"
            data-filter="Stationery"
        >
            Bags & Stationery
        </button>


        <button
            type="button"
            class="filter-btn"
            data-filter="Other"
        >
            Other
        </button>


    </div>


    <!-- PRODUCT GRID -->

    <div
        class="product-grid"
        id="productGrid"
    >


<?php

if (
    $productsResult &&
    mysqli_num_rows($productsResult) > 0
):


    while (
        $product =
        mysqli_fetch_assoc($productsResult)
    ):


        $productId =
            (int)($product['id'] ?? 0);


        $productTitle =
            $product['title']
            ?? 'Untitled Product';


        $description =
            $product['description']
            ?? 'No description available.';


        $price =
            $product['price']
            ?? 0;


        $condition =
            $product['product_condition']
            ?? 'Used';


        $age =
            $product['product_age']
            ?? '';


        $image =
            $product['image']
            ?? '';


        $seller =
            $product['seller_name']
            ?? 'Student';


        $category =
            getCategoryFromProduct(
                $productTitle,
                $description
            );


        $imagePath =
            getProductImage($image);


        $sellerInitial =
            getInitial($seller);

?>


        <!-- PRODUCT -->

        <a
            href="product_details.php?id=<?php echo $productId; ?>"
            class="product-card"
            data-category="<?php echo clean($category); ?>"
        >


            <div class="product-image">


<?php if ($imagePath !== ''): ?>


                <img
                    src="<?php echo clean($imagePath); ?>"
                    alt="<?php echo clean($productTitle); ?>"
                    loading="lazy"
                    onerror="showProductFallback(this)"
                >


                <div
                    class="no-image"
                    style="display:none;"
                >

                    <i
                        class="fa-solid fa-box-open"
                    ></i>

                </div>


<?php else: ?>


                <div class="no-image">

                    <i
                        class="fa-solid fa-box-open"
                    ></i>

                </div>


<?php endif; ?>


                <span class="condition-badge">

                    <?php
                    echo clean($condition);
                    ?>

                </span>


                <span class="category-badge">

                    <?php
                    echo clean($category);
                    ?>

                </span>


            </div>


            <div class="product-body">


                <div class="product-title">

                    <?php
                    echo clean($productTitle);
                    ?>

                </div>


                <div class="product-description">

                    <?php
                    echo clean($description);
                    ?>

                </div>


                <div class="product-bottom">


                    <div class="price">

                        ₹<?php

                        echo number_format(
                            (float)$price,
                            0
                        );

                        ?>

                    </div>


<?php if ($age !== ''): ?>


                    <div class="age">

                        <i
                            class="fa-regular fa-clock"
                        ></i>

                        <?php
                        echo clean($age);
                        ?>

                    </div>


<?php endif; ?>


                </div>


                <div class="seller">


                    <div class="seller-avatar">

                        <?php
                        echo clean($sellerInitial);
                        ?>

                    </div>


                    <div class="seller-name">

                        <?php
                        echo clean($seller);
                        ?>

                    </div>


                </div>


            </div>


        </a>


<?php

    endwhile;


else:

?>


        <div class="empty">


            <i
                class="fa-solid fa-box-open"
            ></i>


            <p>
                No marketplace products have been listed yet.
            </p>


            <br>


            <a
                href="add_product.php"
                class="btn btn-primary"
            >

                <i class="fa-solid fa-plus"></i>

                Add First Product

            </a>


        </div>


<?php

endif;

?>


    </div>


</section>


<!-- =====================================================
     SKILL HUB
====================================================== -->

<section class="section">


    <div class="section-head">


        <div>

            <div class="section-title">
                🎯 Skill Hub
            </div>

            <div class="section-description">
                Discover students who can help with your projects
            </div>

        </div>


        <a
            href="skills.php"
            class="view-all"
        >

            Explore Skill Hub

            <i class="fa-solid fa-arrow-right"></i>

        </a>


    </div>


    <div class="skill-grid">


<?php

if (
    $skillsResult &&
    mysqli_num_rows($skillsResult) > 0
):


    while (
        $skill =
        mysqli_fetch_assoc($skillsResult)
    ):


        $skillId =
            (int)($skill['id'] ?? 0);


        $skillName =
            $skill['title']
            ?? 'Student Skill';


        $skillDescription =
            $skill['description']
            ?? 'Student offering this skill.';


        $skillCategory =
            $skill['category']
            ?? 'Other';


        $skillAvailability =
            $skill['availability']
            ?? 'Available';


        $skillIcon =
            getSkillIcon(
                $skillName,
                $skillDescription,
                $skillCategory
            );


        $skillProvider =
            $skill['student_name']
            ?? 'Student';


        $skillPrice =
            $skill['price']
            ?? 0;

?>


        <article class="skill-card">


            <div class="skill-top">


                <div class="skill-icon">

                    <i
                        class="fa-solid
                        <?php echo clean($skillIcon); ?>"
                    ></i>

                </div>


                <span
                    class="available"
                    style="<?php

                    echo strtolower(
                        $skillAvailability
                    ) !== 'available'

                    ?

                    'color:#fbbf24;
                     background:rgba(245,158,11,.08);
                     border-color:rgba(245,158,11,.15);'

                    :

                    '';

                    ?>"
                >

                    <i
                        class="fa-solid fa-circle"
                    ></i>

                    <?php
                    echo clean(
                        $skillAvailability
                    );
                    ?>

                </span>


            </div>


            <div class="skill-name">

                <?php
                echo clean($skillName);
                ?>

            </div>


            <div class="skill-description">

                <?php
                echo clean($skillDescription);
                ?>

            </div>


            <div class="skill-footer">


                <div class="rating">

                    <i class="fa-solid fa-tag"></i>

                    <?php
                    echo clean($skillCategory);
                    ?>

                </div>


                <a
                    href="skill_profile.php?id=<?php echo $skillId; ?>"
                    class="hire-btn"
                >

                    View / Hire

                </a>


            </div>


        </article>


<?php

    endwhile;


else:

?>


        <div class="empty">


            <i
                class="fa-solid fa-wand-magic-sparkles"
            ></i>


            <p>
                No student skills have been added yet.
            </p>


            <br>


            <a
                href="add_skills.php"
                class="btn btn-primary"
            >

                <i class="fa-solid fa-star"></i>

                Add Your First Skill

            </a>


        </div>


<?php

endif;

?>


    </div>


</section>


<!-- =====================================================
     ACTIVITY + PROFILE
====================================================== -->

<section
    class="section"
    id="profile"
>


    <div class="bottom-grid">


        <!-- ACTIVITY -->

        <div class="info-card">


            <div class="info-card-title">
                Recent Activity
            </div>


            <div class="info-card-subtitle">
                Your EduTrade activity center
            </div>


            <div class="activity">


                <div class="activity-item">


                    <div class="activity-icon">

                        <i
                            class="fa-solid fa-store"
                        ></i>

                    </div>


                    <div>

                        <strong>
                            Marketplace is ready
                        </strong>

                        <span>
                            Browse books, lab equipment,
                            electronics and stationery.
                        </span>

                    </div>


                </div>


                <div class="activity-item">


                    <div class="activity-icon">

                        <i
                            class="fa-solid
                            fa-wand-magic-sparkles"
                        ></i>

                    </div>


                    <div>

                        <strong>
                            Skill Hub is active
                        </strong>

                        <span>
                            Discover talented students
                            and hire them for your work.
                        </span>

                    </div>


                </div>


                <div class="activity-item">


                    <div class="activity-icon">

                        <i
                            class="fa-solid fa-heart"
                        ></i>

                    </div>


                    <div>

                        <strong>
                            Your saved items
                        </strong>

                        <span>

                            You currently have

                            <?php
                            echo number_format(
                                $savedProducts
                            );
                            ?>

                            saved products.

                        </span>

                    </div>


                </div>


                <div class="activity-item">


                    <div class="activity-icon">

                        <i
                            class="fa-solid fa-paper-plane"
                        ></i>

                    </div>


                    <div>

                        <strong>
                            Hire & Requests
                        </strong>

                        <span>

                            Manage your student
                            project requests from
                            the Hire / Requests page.

                        </span>

                    </div>


                </div>


            </div>


        </div>


        <!-- PROFILE -->

        <div class="info-card">


            <div class="profile-user">


                <div class="profile-avatar">

                    <?php
                    echo clean($initial);
                    ?>

                </div>


                <div>

                    <strong>

                        <?php
                        echo clean($userName);
                        ?>

                    </strong>


                    <span>

                        <?php

                        echo clean(
                            $userEmail !== ''
                                ? $userEmail
                                : 'Student Account'
                        );

                        ?>

                    </span>


                </div>


            </div>


            <div class="profile-divider"></div>


            <div class="profile-stat">

                <span>
                    My Products
                </span>

                <strong>

                    <?php
                    echo number_format($myProducts);
                    ?>

                </strong>

            </div>


            <div class="profile-stat">

                <span>
                    My Skills
                </span>

                <strong>

                    <?php
                    echo number_format($mySkills);
                    ?>

                </strong>

            </div>


            <div class="profile-stat">

                <span>
                    Saved Products
                </span>

                <strong>

                    <?php
                    echo number_format($savedProducts);
                    ?>

                </strong>

            </div>


            <div class="profile-stat">

                <span>
                    Hire / Requests
                </span>

                <strong>

                    <?php
                    echo number_format($incomingRequests);
                    ?>

                </strong>

            </div>


            <div class="profile-stat">

                <span>
                    Marketplace
                </span>

                <strong>

                    <?php
                    echo number_format($totalProducts);
                    ?>

                </strong>

            </div>


            <div class="profile-stat">

                <span>
                    Student Community
                </span>

                <strong>

                    <?php
                    echo number_format($totalStudents);
                    ?>

                </strong>

            </div>


            <div style="margin-top:15px;">


                <a
                    href="#profile"
                    class="btn btn-secondary"
                    style="width:100%;"
                >

                    <i
                        class="fa-regular fa-user"
                    ></i>

                    My Profile

                </a>


            </div>


        </div>


    </div>


</section>


<!-- =====================================================
     FOOTER
====================================================== -->

<footer class="footer">


    <span>
        © 2026 EduTrade PRO
    </span>


    <span>
        Learn • Trade • Grow 🚀
    </span>


</footer>


</main>


</div>


<script>

/* =========================================================
   SIDEBAR
========================================================= */

const sidebar =
    document.getElementById('sidebar');


const sidebarOverlay =
    document.getElementById('sidebarOverlay');


function toggleSidebar()
{
    sidebar.classList.toggle('open');

    sidebarOverlay.classList.toggle(
        'show'
    );
}


function closeSidebar()
{
    sidebar.classList.remove('open');

    sidebarOverlay.classList.remove(
        'show'
    );
}


/* =========================================================
   MOBILE NAV
========================================================= */

document
    .querySelectorAll('.sidebar .nav-link')
    .forEach(link => {

        link.addEventListener(
            'click',
            () => {

                if (
                    window.innerWidth <= 950
                ) {

                    closeSidebar();

                }

            }
        );

    });


/* =========================================================
   MARKETPLACE FILTER
========================================================= */

const filterButtons =
    document.querySelectorAll(
        '.filter-btn'
    );


const productCards =
    document.querySelectorAll(
        '.product-card'
    );


filterButtons.forEach(button => {

    button.addEventListener(
        'click',
        function()
        {

            filterButtons.forEach(
                item => {

                    item.classList.remove(
                        'active'
                    );

                }
            );


            this.classList.add(
                'active'
            );


            const filter =
                this.dataset.filter;


            productCards.forEach(
                card => {

                    const category =
                        card.dataset.category;


                    if (
                        filter === 'all' ||
                        category === filter
                    ) {

                        card.style.display =
                            '';

                    }
                    else {

                        card.style.display =
                            'none';

                    }

                }
            );

        }
    );

});


/* =========================================================
   GLOBAL PRODUCT SEARCH
========================================================= */

const searchInput =
    document.getElementById(
        'globalSearch'
    );


if (searchInput) {

    searchInput.addEventListener(
        'input',
        function()
        {

            const searchValue =
                this.value
                    .toLowerCase()
                    .trim();


            filterButtons.forEach(
                item => {

                    item.classList.remove(
                        'active'
                    );

                }
            );


            if (filterButtons[0]) {

                filterButtons[0]
                    .classList.add(
                        'active'
                    );

            }


            productCards.forEach(
                card => {

                    const content =
                        card.innerText
                            .toLowerCase();


                    if (
                        content.includes(
                            searchValue
                        )
                    ) {

                        card.style.display =
                            '';

                    }
                    else {

                        card.style.display =
                            'none';

                    }

                }
            );

        }
    );

}


/* =========================================================
   ESC KEY
========================================================= */

document.addEventListener(
    'keydown',
    function(event)
    {

        if (
            event.key === 'Escape'
        ) {

            closeSidebar();

        }

    }
);


/* =========================================================
   RESPONSIVE SIDEBAR
========================================================= */

window.addEventListener(
    'resize',
    function()
    {

        if (
            window.innerWidth > 950
        ) {

            sidebar.classList.remove(
                'open'
            );

            sidebarOverlay.classList.remove(
                'show'
            );

        }

    }
);


/* =========================================================
   PRODUCT IMAGE FALLBACK
========================================================= */

function showProductFallback(image)
{

    image.style.display =
        'none';


    const fallback =
        image.nextElementSibling;


    if (fallback) {

        fallback.style.display =
            'flex';

    }

}


document
    .querySelectorAll(
        '.product-image img'
    )
    .forEach(image => {

        image.addEventListener(
            'error',
            function()
            {

                showProductFallback(
                    this
                );

            }
        );

    });


/* =========================================================
   REVEAL ON SCROLL
========================================================= */

const revealElements =
    document.querySelectorAll(
        '.section, .stat, .quick-card, .product-card, .skill-card'
    );


if (
    'IntersectionObserver'
    in window
) {

    const revealObserver =
        new IntersectionObserver(
            entries => {

                entries.forEach(
                    entry => {

                        if (
                            entry.isIntersecting
                        ) {

                            entry.target.style
                                .opacity = '1';

                            entry.target.style
                                .transform =
                                'translateY(0)';

                        }

                    }
                );

            },
            {
                threshold:.08
            }
        );


    revealElements.forEach(
        element => {

            revealObserver.observe(
                element
            );

        }
    );

}

</script>


</body>

</html>