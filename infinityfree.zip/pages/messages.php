
<?php
session_start();
require_once __DIR__ . '/../config/db.php';

if (!isset($_SESSION['user_id']) || !is_numeric($_SESSION['user_id'])) {
    header('Location: ../includes/login.php');
    exit;
}

$currentUserId = (int) $_SESSION['user_id'];

if (!isset($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

function et_json_response(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function et_h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function mbSafeUpper(string $value): string
{
    return function_exists('mb_strtoupper')
        ? mb_strtoupper($value, 'UTF-8')
        : strtoupper($value);
}

function et_initial($value): string
{
    $value = trim((string)$value);
    if ($value === '') return 'S';

    if (preg_match('/^./us', $value, $match)) {
        return mbSafeUpper($match[0]);
    }

    return 'S';
}

function et_read_json_body(): array
{
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw ?: '', true);
    return is_array($decoded) ? $decoded : $_POST;
}

function et_require_csrf(): void
{
    $sentToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    $savedToken = $_SESSION['csrf_token'] ?? '';

    if (
        !is_string($sentToken) ||
        !is_string($savedToken) ||
        $savedToken === '' ||
        !hash_equals($savedToken, $sentToken)
    ) {
        et_json_response([
            'success' => false,
            'error' => 'Your session security token is invalid. Refresh this page and try again.'
        ], 403);
    }
}

function et_get_contact(mysqli $conn, int $contactId, int $currentUserId): ?array
{
    if ($contactId < 1 || $contactId === $currentUserId) {
        return null;
    }

    $stmt = $conn->prepare(
        "SELECT id, COALESCE(NULLIF(name, ''), 'Student') AS name
         FROM users WHERE id = ? LIMIT 1"
    );

    if (!$stmt) return null;

    $stmt->bind_param('i', $contactId);
    $stmt->execute();
    $result = $stmt->get_result();
    $contact = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    return $contact ?: null;
}

/* AJAX actions remain in this file to preserve the existing route. */
$action = isset($_GET['action']) ? (string)$_GET['action'] : '';

if ($action !== '') {
    if (!isset($conn) || !($conn instanceof mysqli)) {
        et_json_response([
            'success' => false,
            'error' => 'Database connection is not available.'
        ], 500);
    }

    if ($action === 'search_users') {
        $query = trim((string)($_GET['q'] ?? ''));

        if ($query === '') {
            et_json_response(['success' => true, 'users' => []]);
        }

        if (strlen($query) > 100) {
            $query = substr($query, 0, 100);
        }

        $like = '%' . $query . '%';

        $stmt = $conn->prepare(
            "SELECT id, COALESCE(NULLIF(name, ''), 'Student') AS name
             FROM users
             WHERE id <> ? AND (name LIKE ? OR email LIKE ?)
             ORDER BY name ASC LIMIT 20"
        );

        if (!$stmt) {
            et_json_response([
                'success' => false,
                'error' => 'Could not search students right now.'
            ], 500);
        }

        $stmt->bind_param('iss', $currentUserId, $like, $like);
        $stmt->execute();
        $result = $stmt->get_result();
        $users = [];

        while ($result && ($row = $result->fetch_assoc())) {
            $users[] = [
                'id' => (int)$row['id'],
                'name' => (string)$row['name']
            ];
        }

        $stmt->close();
        et_json_response(['success' => true, 'users' => $users]);
    }

    if ($action === 'fetch' || $action === 'send') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            et_json_response([
                'success' => false,
                'error' => 'Use POST for this action.'
            ], 405);
        }

        et_require_csrf();
        $body = et_read_json_body();
        $contactId = (int)($body['with'] ?? 0);
        $contact = et_get_contact($conn, $contactId, $currentUserId);

        if (!$contact) {
            et_json_response([
                'success' => false,
                'error' => 'Student not found.'
            ], 404);
        }

        if ($action === 'fetch') {
            $stmt = $conn->prepare(
                "SELECT id, sender_id, receiver_id, message, is_read, created_at
                 FROM messages
                 WHERE (sender_id = ? AND receiver_id = ?)
                    OR (sender_id = ? AND receiver_id = ?)
                 ORDER BY id DESC LIMIT 250"
            );

            if (!$stmt) {
                et_json_response([
                    'success' => false,
                    'error' => 'Could not load this conversation.'
                ], 500);
            }

            $stmt->bind_param(
                'iiii',
                $currentUserId,
                $contactId,
                $contactId,
                $currentUserId
            );

            $stmt->execute();
            $result = $stmt->get_result();
            $messages = [];

            while ($result && ($row = $result->fetch_assoc())) {
                $messages[] = [
                    'id' => (int)$row['id'],
                    'sender_id' => (int)$row['sender_id'],
                    'receiver_id' => (int)$row['receiver_id'],
                    'message' => (string)$row['message'],
                    'is_read' => (int)$row['is_read'],
                    'created_at' => (string)$row['created_at']
                ];
            }

            $stmt->close();
            $messages = array_reverse($messages);

            $mark = $conn->prepare(
                "UPDATE messages
                 SET is_read = 1
                 WHERE sender_id = ? AND receiver_id = ? AND is_read = 0"
            );

            if ($mark) {
                $mark->bind_param('ii', $contactId, $currentUserId);
                $mark->execute();
                $mark->close();
            }

            et_json_response([
                'success' => true,
                'contact' => [
                    'id' => (int)$contact['id'],
                    'name' => (string)$contact['name']
                ],
                'messages' => $messages
            ]);
        }

        $message = trim((string)($body['message'] ?? ''));

        if ($message === '') {
            et_json_response([
                'success' => false,
                'error' => 'Type a message before sending.'
            ], 422);
        }

        if (strlen($message) > 32000) {
            et_json_response([
                'success' => false,
                'error' => 'Messages must be 8,000 characters or fewer.'
            ], 422);
        }

        $stmt = $conn->prepare(
            "INSERT INTO messages (sender_id, receiver_id, message)
             VALUES (?, ?, ?)"
        );

        if (!$stmt) {
            et_json_response([
                'success' => false,
                'error' => 'Could not send your message right now.'
            ], 500);
        }

        $stmt->bind_param('iis', $currentUserId, $contactId, $message);

        if (!$stmt->execute()) {
            $stmt->close();
            et_json_response([
                'success' => false,
                'error' => 'Your message could not be sent. Please try again.'
            ], 500);
        }

        $newId = (int)$conn->insert_id;
        $stmt->close();
        $createdAt = date('Y-m-d H:i:s');

        $timeStmt = $conn->prepare(
            "SELECT created_at FROM messages WHERE id = ? LIMIT 1"
        );

        if ($timeStmt) {
            $timeStmt->bind_param('i', $newId);
            $timeStmt->execute();
            $timeResult = $timeStmt->get_result();

            if ($timeResult && ($timeRow = $timeResult->fetch_assoc())) {
                $createdAt = (string)$timeRow['created_at'];
            }

            $timeStmt->close();
        }

        et_json_response([
            'success' => true,
            'message' => [
                'id' => $newId,
                'sender_id' => $currentUserId,
                'receiver_id' => $contactId,
                'message' => $message,
                'is_read' => 0,
                'created_at' => $createdAt
            ]
        ]);
    }

    et_json_response([
        'success' => false,
        'error' => 'Unknown messaging action.'
    ], 400);
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    die('Database connection is not available. Please check config/db.php.');
}

$currentName = (string)($_SESSION['name'] ?? 'Student');
$activeId = max(0, (int)($_GET['with'] ?? 0));
$activeContact = $activeId > 0
    ? et_get_contact($conn, $activeId, $currentUserId)
    : null;

if (!$activeContact) {
    $activeId = 0;
}

$contacts = [];

$contactsStmt = $conn->prepare(
    "SELECT
        u.id AS contact_id,
        COALESCE(NULLIF(u.name, ''), 'Student') AS contact_name,
        m.id AS last_message_id,
        m.message AS last_message,
        m.sender_id AS last_sender_id,
        m.created_at AS last_created_at,
        (
            SELECT COUNT(*)
            FROM messages unread
            WHERE unread.sender_id = u.id
              AND unread.receiver_id = ?
              AND unread.is_read = 0
        ) AS unread_count
     FROM users u
     INNER JOIN messages m ON m.id = (
        SELECT MAX(m2.id)
        FROM messages m2
        WHERE (m2.sender_id = ? AND m2.receiver_id = u.id)
           OR (m2.sender_id = u.id AND m2.receiver_id = ?)
     )
     WHERE u.id <> ?
     ORDER BY m.id DESC
     LIMIT 100"
);

if ($contactsStmt) {
    $contactsStmt->bind_param(
        'iiii',
        $currentUserId,
        $currentUserId,
        $currentUserId,
        $currentUserId
    );

    $contactsStmt->execute();
    $contactsResult = $contactsStmt->get_result();

    while ($contactsResult && ($row = $contactsResult->fetch_assoc())) {
        $contacts[] = [
            'id' => (int)$row['contact_id'],
            'name' => (string)$row['contact_name'],
            'last_message' => (string)$row['last_message'],
            'last_sender_id' => (int)$row['last_sender_id'],
            'created_at' => (string)$row['last_created_at'],
            'unread_count' => (int)$row['unread_count']
        ];
    }

    $contactsStmt->close();
}

if ($activeContact) {
    $found = false;

    foreach ($contacts as $contactRow) {
        if ($contactRow['id'] === $activeId) {
            $found = true;
            break;
        }
    }

    if (!$found) {
        array_unshift($contacts, [
            'id' => (int)$activeContact['id'],
            'name' => (string)$activeContact['name'],
            'last_message' => '',
            'last_sender_id' => 0,
            'created_at' => '',
            'unread_count' => 0
        ]);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#070b18">
<title>Messages | EduTrade</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>
:root {
    --bg: #070b18;
    --panel: rgba(15,21,42,.88);
    --line: rgba(166,185,255,.13);
    --text: #f3f5ff;
    --muted: #9ba7c5;
    --accent: #62e6ff;
    --accent2: #8b72ff;
    --pink: #ff78bd;
    --danger: #ff929e;
    --shadow: 0 24px 80px rgba(0,0,0,.35);
}

* { box-sizing: border-box; }
html { min-height:100%; background:var(--bg); scroll-behavior:smooth; }

body {
    margin:0;
    min-height:100vh;
    color:var(--text);
    font-family:'DM Sans',sans-serif;
    background:
        radial-gradient(ellipse at 8% 0%,rgba(66,100,255,.18),transparent 32rem),
        radial-gradient(ellipse at 95% 10%,rgba(155,70,255,.17),transparent 29rem),
        radial-gradient(ellipse at 55% 100%,rgba(0,204,255,.08),transparent 34rem),
        var(--bg);
}

a { color:inherit; text-decoration:none; }
button,input,textarea { font:inherit; }

.app-shell {
    max-width:1550px;
    margin:0 auto;
    padding:25px clamp(14px,3vw,44px) 32px;
}

.topbar {
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:16px;
    margin-bottom:36px;
}

.brand { display:flex; align-items:center; gap:12px; }

.brand-mark {
    width:46px;
    height:46px;
    display:grid;
    place-items:center;
    border-radius:15px;
    background:linear-gradient(135deg,#68edff,#7c72ff 75%,#c17aff);
    color:#090d1b;
    font:900 22px Manrope,sans-serif;
    box-shadow:0 0 30px rgba(99,131,255,.27);
}

.brand-name {
    font:800 21px Manrope,sans-serif;
    letter-spacing:-.7px;
}

.brand-sub {
    font-size:10px;
    letter-spacing:1.8px;
    text-transform:uppercase;
    color:#9ba8cc;
    margin-top:4px;
}

.top-actions { display:flex; align-items:center; gap:12px; }

.back-link {
    display:inline-flex;
    align-items:center;
    gap:8px;
    border:1px solid var(--line);
    padding:11px 15px;
    border-radius:13px;
    color:#dbe4ff;
    font-size:13px;
    background:rgba(255,255,255,.035);
    transition:.22s ease;
}

.back-link:hover {
    border-color:rgba(98,230,255,.48);
    background:rgba(98,230,255,.08);
    transform:translateY(-2px);
}

.user-chip {
    display:flex;
    align-items:center;
    gap:9px;
    padding:7px 13px 7px 7px;
    border:1px solid var(--line);
    background:rgba(255,255,255,.035);
    border-radius:30px;
    max-width:220px;
}

.avatar {
    width:40px;
    height:40px;
    flex:0 0 40px;
    display:grid;
    place-items:center;
    border-radius:50%;
    background:linear-gradient(135deg,#6beaff,#8372ff 70%,#ed8bff);
    color:#0a1023;
    font:800 13px Manrope,sans-serif;
    text-transform:uppercase;
}

.avatar.small { width:43px; height:43px; flex-basis:43px; }

.user-chip .user-name {
    font-size:13px;
    font-weight:700;
    max-width:150px;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
}

.eyebrow {
    font-size:11px;
    color:var(--accent);
    text-transform:uppercase;
    letter-spacing:2.2px;
    font-weight:800;
}

.page-heading {
    display:flex;
    align-items:flex-end;
    justify-content:space-between;
    gap:20px;
    margin-bottom:23px;
}

.page-heading h1 {
    margin:9px 0;
    font:800 clamp(30px,3.8vw,43px)/1.12 Manrope,sans-serif;
    letter-spacing:-1.8px;
}

.page-heading h1 span {
    background:linear-gradient(100deg,#62e6ff,#9381ff,#ff78bd);
    -webkit-background-clip:text;
    background-clip:text;
    -webkit-text-fill-color:transparent;
}

.page-heading p {
    margin:0;
    color:var(--muted);
    font-size:14px;
    line-height:1.7;
}

.online-note {
    display:flex;
    align-items:center;
    gap:9px;
    color:#c2cbe6;
    font-size:12px;
    padding:12px 15px;
    border:1px solid var(--line);
    border-radius:14px;
    background:rgba(255,255,255,.035);
    white-space:nowrap;
}

.online-dot {
    height:8px;
    width:8px;
    border-radius:50%;
    background:var(--accent);
    box-shadow:0 0 13px rgba(98,230,255,.85);
}

.messenger {
    height:min(720px,calc(100vh - 235px));
    min-height:510px;
    display:grid;
    grid-template-columns:325px minmax(0,1fr);
    border:1px solid rgba(164,181,255,.16);
    border-radius:25px;
    overflow:hidden;
    background:rgba(12,17,36,.82);
    box-shadow:var(--shadow),0 0 55px rgba(79,89,255,.045);
    backdrop-filter:blur(24px);
    -webkit-backdrop-filter:blur(24px);
}

.sidebar {
    min-width:0;
    border-right:1px solid var(--line);
    display:flex;
    flex-direction:column;
    background:rgba(17,23,46,.72);
}

.sidebar-head {
    padding:23px 19px 17px;
    border-bottom:1px solid var(--line);
}

.sidebar-title-row {
    display:flex;
    align-items:center;
    justify-content:space-between;
    margin-bottom:17px;
}

.sidebar-title { font:800 17px Manrope,sans-serif; }

.count-pill {
    font-size:11px;
    padding:6px 9px;
    border-radius:9px;
    background:linear-gradient(135deg,rgba(98,230,255,.13),rgba(139,114,255,.14));
    border:1px solid rgba(120,155,255,.17);
    color:var(--accent);
    font-weight:800;
}

.search-wrap { position:relative; }

.search-icon {
    position:absolute;
    left:13px;
    top:50%;
    transform:translateY(-50%);
    font-size:19px;
    color:#8e9cc2;
}

.search-input {
    width:100%;
    border:1px solid rgba(164,181,255,.14);
    outline:none;
    border-radius:13px;
    background:rgba(6,10,25,.68);
    color:var(--text);
    padding:13px 12px 13px 40px;
    font-size:12px;
    transition:.2s;
}

.search-input:focus {
    border-color:rgba(98,230,255,.55);
    box-shadow:0 0 0 3px rgba(98,230,255,.075);
}

.search-input::placeholder { color:#7784a7; }

.search-results {
    display:none;
    padding:8px 10px 12px;
    border-bottom:1px solid var(--line);
    max-height:205px;
    overflow:auto;
    background:rgba(10,14,31,.45);
}

.search-results.visible { display:block; }

.section-label {
    padding:17px 19px 9px;
    color:#8190b4;
    text-transform:uppercase;
    letter-spacing:1.5px;
    font-size:10px;
    font-weight:800;
}

.contacts { overflow:auto; flex:1; padding:0 9px 13px; }

.contacts::-webkit-scrollbar,
.messages-scroll::-webkit-scrollbar,
.search-results::-webkit-scrollbar { width:5px; }

.contacts::-webkit-scrollbar-thumb,
.messages-scroll::-webkit-scrollbar-thumb,
.search-results::-webkit-scrollbar-thumb {
    background:rgba(139,151,211,.28);
    border-radius:10px;
}

.contact-link {
    display:flex;
    align-items:center;
    gap:11px;
    padding:12px 10px;
    border-radius:15px;
    margin:4px 0;
    transition:background .2s,border-color .2s,transform .2s;
    border:1px solid transparent;
}

.contact-link:hover {
    background:rgba(255,255,255,.045);
    transform:translateX(2px);
}

.contact-link.active {
    background:linear-gradient(110deg,rgba(98,230,255,.11),rgba(139,114,255,.12));
    border-color:rgba(116,153,255,.2);
    box-shadow:inset 3px 0 0 #62e6ff;
}

.contact-link .avatar { background:linear-gradient(135deg,#72e8ff,#8a7aff); }

.contact-main { flex:1; min-width:0; }

.contact-top {
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:7px;
    margin-bottom:5px;
}

.contact-name {
    font-size:13px;
    font-weight:700;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
}

.contact-preview {
    font-size:11px;
    color:#9ba8c6;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}

.contact-meta {
    display:flex;
    flex-direction:column;
    align-items:flex-end;
    gap:6px;
    flex:0 0 auto;
}

.contact-time { font-size:10px; color:#8290b0; }

.unread-badge {
    min-width:20px;
    height:20px;
    padding:0 5px;
    display:grid;
    place-items:center;
    border-radius:20px;
    color:#080d1c;
    background:linear-gradient(135deg,#62e6ff,#a5a0ff);
    font-size:10px;
    font-weight:900;
}

.no-conversations {
    padding:23px 12px;
    text-align:center;
    color:var(--muted);
    font-size:12px;
    line-height:1.7;
}

.chat-panel {
    display:flex;
    flex-direction:column;
    min-width:0;
    min-height:0;
    background:radial-gradient(ellipse at 95% 0%,rgba(115,85,255,.055),transparent 23rem),rgba(9,14,30,.35);
}

.chat-header {
    min-height:83px;
    padding:17px 23px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    border-bottom:1px solid var(--line);
    background:rgba(255,255,255,.018);
}

.chat-person { display:flex; align-items:center; gap:12px; min-width:0; }
.chat-person .avatar { background:linear-gradient(135deg,#62e6ff,#8974ff,#df8cff); }
.chat-person-text { min-width:0; }

.chat-person-name {
    font:800 15px Manrope,sans-serif;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
}

.chat-person-sub { font-size:11px; color:var(--muted); margin-top:5px; }

.private-label {
    display:flex;
    align-items:center;
    gap:7px;
    color:#b4c2e7;
    border:1px solid var(--line);
    padding:9px 11px;
    border-radius:11px;
    font-size:11px;
    white-space:nowrap;
    background:rgba(255,255,255,.025);
}

.private-label span { color:var(--accent); }

.mobile-back {
    display:none;
    border:1px solid var(--line);
    background:rgba(255,255,255,.04);
    color:var(--text);
    width:35px;
    height:35px;
    border-radius:11px;
    place-items:center;
}

.messages-scroll {
    flex:1;
    min-height:0;
    overflow-y:auto;
    padding:25px clamp(15px,3vw,36px);
    scroll-behavior:smooth;
}

.messages-list { display:flex; flex-direction:column; gap:15px; min-height:100%; }

.chat-day-note {
    align-self:center;
    color:#a2afd0;
    background:rgba(255,255,255,.035);
    border:1px solid var(--line);
    border-radius:30px;
    padding:7px 13px;
    font-size:10px;
    margin:0 0 8px;
}

.message-row {
    display:flex;
    align-items:flex-end;
    gap:9px;
    max-width:min(78%,620px);
    animation:messageIn .2s ease-out;
}

.message-row.own { align-self:flex-end; flex-direction:row-reverse; }
.message-row.other { align-self:flex-start; }

.message-avatar {
    width:29px;
    height:29px;
    flex:0 0 29px;
    border-radius:50%;
    display:grid;
    place-items:center;
    background:linear-gradient(135deg,#252c59,#513c82);
    color:#d5d6ff;
    font:700 9px Manrope,sans-serif;
    text-transform:uppercase;
    border:1px solid rgba(165,167,255,.2);
}

.message-bubble {
    padding:12px 15px 8px;
    border:1px solid rgba(164,181,255,.13);
    background:linear-gradient(135deg,rgba(28,37,68,.96),rgba(22,29,53,.96));
    border-radius:17px 17px 17px 5px;
    min-width:75px;
    overflow-wrap:anywhere;
    box-shadow:0 5px 20px rgba(0,0,0,.08);
}

.own .message-bubble {
    background:linear-gradient(125deg,#57dfff 0%,#8582ff 75%,#a58bff 100%);
    border-color:rgba(255,255,255,.18);
    color:#0b1024;
    border-radius:17px 17px 5px 17px;
    box-shadow:0 8px 24px rgba(105,127,255,.13);
}

.message-text { font-size:13px; line-height:1.7; white-space:pre-wrap; margin:0; }

.message-time {
    display:flex;
    justify-content:flex-end;
    gap:5px;
    margin-top:6px;
    font-size:9px;
    color:#9daac9;
}

.own .message-time { color:rgba(11,16,36,.68); }

.empty-state { margin:auto; text-align:center; max-width:350px; padding:32px 15px; }

.empty-icon {
    width:70px;
    height:70px;
    margin:0 auto 18px;
    border-radius:23px;
    background:linear-gradient(135deg,rgba(98,230,255,.13),rgba(139,114,255,.16),rgba(255,120,189,.08));
    border:1px solid rgba(142,151,255,.2);
    display:grid;
    place-items:center;
    font-size:28px;
    box-shadow:0 12px 35px rgba(90,90,255,.08);
}

.empty-state h3 { margin:0 0 10px; font:800 18px Manrope,sans-serif; letter-spacing:-.4px; }
.empty-state p { color:var(--muted); font-size:13px; line-height:1.8; margin:0; }

.welcome-panel {
    height:100%;
    min-height:350px;
    display:flex;
    align-items:center;
    justify-content:center;
}

.welcome-panel .empty-state { padding:36px; }
.welcome-panel .empty-icon { width:84px; height:84px; font-size:32px; }
.welcome-panel h3 { font-size:21px; }
.welcome-panel p { max-width:310px; }

.composer-wrap {
    border-top:1px solid var(--line);
    padding:16px 21px 18px;
    background:rgba(255,255,255,.012);
}

.composer-error { display:none; color:var(--danger); font-size:12px; margin:0 0 10px; }
.composer-error.show { display:block; }

.composer {
    display:flex;
    align-items:flex-end;
    gap:10px;
    padding:7px 7px 7px 15px;
    border:1px solid rgba(164,181,255,.17);
    border-radius:17px;
    background:rgba(6,10,25,.72);
    transition:border-color .2s,box-shadow .2s;
}

.composer:focus-within {
    border-color:rgba(98,230,255,.55);
    box-shadow:0 0 0 3px rgba(98,230,255,.065),0 0 24px rgba(98,230,255,.035);
}

.composer textarea {
    flex:1;
    min-width:0;
    resize:none;
    max-height:120px;
    min-height:41px;
    border:0;
    outline:none;
    background:transparent;
    color:var(--text);
    padding:10px 0;
    font-size:13px;
    line-height:1.6;
}

.composer textarea::placeholder { color:#7885a7; }

.send-btn {
    width:44px;
    height:44px;
    flex:0 0 44px;
    border:0;
    border-radius:13px;
    background:linear-gradient(135deg,#62e6ff,#8b79ff 80%);
    color:#0b1023;
    display:grid;
    place-items:center;
    cursor:pointer;
    font-size:20px;
    font-weight:900;
    box-shadow:0 5px 20px rgba(103,133,255,.19);
    transition:transform .18s,filter .18s,box-shadow .18s;
}

.send-btn:hover { filter:brightness(1.1); transform:translateY(-2px); box-shadow:0 8px 26px rgba(103,133,255,.3); }
.send-btn:active { transform:scale(.96); }
.send-btn:disabled { opacity:.5; cursor:not-allowed; transform:none; }

.composer-hint {
    display:flex;
    justify-content:space-between;
    gap:10px;
    color:#7885a5;
    font-size:10px;
    margin-top:10px;
    padding:0 3px;
}

.search-result {
    display:flex;
    align-items:center;
    gap:10px;
    padding:10px 8px;
    border-radius:12px;
    transition:background .18s;
}

.search-result:hover { background:rgba(98,230,255,.07); }
.search-result .avatar { width:34px; height:34px; flex-basis:34px; font-size:10px; }
.search-result-name { font-size:12px; font-weight:700; }
.search-result-hint { font-size:10px; color:var(--muted); margin-top:3px; }
.search-empty { font-size:11px; color:var(--muted); padding:12px 8px; }

.page-footer { text-align:center; color:#7784a6; font-size:11px; margin-top:19px; }

.page-footer strong {
    background:linear-gradient(90deg,#62e6ff,#a18aff,#ff8bc7);
    -webkit-background-clip:text;
    background-clip:text;
    -webkit-text-fill-color:transparent;
    font-weight:700;
}

@keyframes messageIn {
    from { opacity:0; transform:translateY(5px); }
    to { opacity:1; transform:translateY(0); }
}

@media(max-width:900px) {
    .messenger { grid-template-columns:285px minmax(0,1fr); }
    .private-label,.online-note { display:none; }
    .message-row { max-width:86%; }
}

@media(max-width:650px) {
    .app-shell { padding:14px 10px 22px; }
    .topbar { margin-bottom:25px; }
    .brand-mark { width:40px; height:40px; border-radius:13px; }
    .brand-name { font-size:18px; }
    .brand-sub { font-size:9px; letter-spacing:1.3px; }
    .back-link { padding:9px 10px; font-size:12px; }
    .user-chip { display:none; }
    .page-heading { align-items:flex-start; margin-bottom:16px; }
    .page-heading h1 { font-size:30px; }
    .page-heading p { font-size:12px; }
    .messenger { height:calc(100dvh - 190px); min-height:470px; grid-template-columns:1fr; border-radius:19px; }
    .sidebar { border-right:0; }
    .chat-panel { display:none; }
    .messenger.has-active .sidebar { display:none; }
    .messenger.has-active .chat-panel { display:flex; }
    .chat-header { min-height:72px; padding:13px 12px; }
    .mobile-back { display:grid; }
    .chat-person { gap:9px; }
    .avatar.small { width:37px; height:37px; flex-basis:37px; }
    .chat-person-name { font-size:13px; }
    .chat-person-sub { font-size:10px; }
    .messages-scroll { padding:18px 12px; }
    .message-row { max-width:90%; }
    .message-text { font-size:12px; }
    .composer-wrap { padding:11px 10px 12px; }
    .composer { padding-left:11px; }
    .send-btn { width:40px; height:40px; flex-basis:40px; }
    .composer-hint { font-size:9px; }
    .sidebar-head { padding:17px 14px 14px; }
    .section-label { padding-left:15px; }
    .contacts { padding:0 5px 10px; }
    .contact-link { padding:11px 9px; }
    .page-footer { font-size:10px; line-height:1.7; }
}

@media(prefers-reduced-motion:reduce) {
    *,*::before,*::after {
        animation-duration:.01ms!important;
        animation-iteration-count:1!important;
        transition-duration:.01ms!important;
        scroll-behavior:auto!important;
    }
}
</style>
</head>

<body>
<div class="app-shell">

    <header class="topbar">
        <a class="brand" href="dashboard.php" aria-label="EduTrade dashboard">
            <div class="brand-mark">E</div>
            <div>
                <div class="brand-name">EduTrade</div>
                <div class="brand-sub">Campus connections</div>
            </div>
        </a>

        <div class="top-actions">
            <a class="back-link" href="dashboard.php"><span aria-hidden="true">←</span> Dashboard</a>
            <div class="user-chip">
                <div class="avatar"><?= et_h(et_initial($currentName)) ?></div>
                <div class="user-name"><?= et_h($currentName) ?></div>
            </div>
        </div>
    </header>

    <section class="page-heading">
        <div>
            <div class="eyebrow">Your campus network</div>
            <h1>Messages<span>.</span></h1>
            <p>Connect with sellers, creators and students — all in one place.</p>
        </div>
        <div class="online-note"><span class="online-dot"></span> Private student conversations</div>
    </section>

    <main class="messenger <?= $activeId > 0 ? 'has-active' : '' ?>" id="messenger">

        <aside class="sidebar">
            <div class="sidebar-head">
                <div class="sidebar-title-row">
                    <div class="sidebar-title">Your inbox</div>
                    <div class="count-pill"><?= count($contacts) ?> chats</div>
                </div>

                <div class="search-wrap">
                    <span class="search-icon" aria-hidden="true">⌕</span>
                    <input
                        class="search-input"
                        type="search"
                        id="studentSearch"
                        placeholder="Find a student to message"
                        autocomplete="off"
                        maxlength="100"
                        aria-label="Search students"
                    >
                </div>
            </div>

            <div class="search-results" id="searchResults" aria-live="polite"></div>

            <div class="section-label">Recent conversations</div>

            <nav class="contacts" aria-label="Recent conversations">
                <?php if (!$contacts): ?>
                    <div class="no-conversations">
                        No conversations yet.<br>
                        Search for a student above to say hello.
                    </div>
                <?php else: ?>
                    <?php foreach ($contacts as $item): ?>
                        <?php
                        $preview = trim($item['last_message']);

                        if ($item['last_sender_id'] === $currentUserId && $preview !== '') {
                            $preview = 'You: ' . $preview;
                        }

                        if (strlen($preview) > 58) {
                            $preview = substr($preview, 0, 55) . '…';
                        }

                        $timeLabel = '';

                        if (!empty($item['created_at'])) {
                            $stamp = strtotime($item['created_at']);
                            if ($stamp !== false) {
                                $timeLabel = date('M j', $stamp);
                            }
                        }
                        ?>

                        <a
                            class="contact-link <?= $item['id'] === $activeId ? 'active' : '' ?>"
                            data-user-id="<?= (int)$item['id'] ?>"
                            href="?with=<?= (int)$item['id'] ?>"
                        >
                            <div class="avatar"><?= et_h(et_initial($item['name'])) ?></div>

                            <div class="contact-main">
                                <div class="contact-top">
                                    <span class="contact-name"><?= et_h($item['name']) ?></span>
                                </div>
                                <div class="contact-preview">
                                    <?= et_h($preview !== '' ? $preview : 'Start the conversation') ?>
                                </div>
                            </div>

                            <div class="contact-meta">
                                <span class="contact-time"><?= et_h($timeLabel) ?></span>

                                <?php if ($item['unread_count'] > 0 && $item['id'] !== $activeId): ?>
                                    <span class="unread-badge">
                                        <?= $item['unread_count'] > 99 ? '99+' : (int)$item['unread_count'] ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </nav>
        </aside>

        <section class="chat-panel" aria-label="Chat conversation">

            <?php if ($activeId > 0 && $activeContact): ?>

                <header class="chat-header">
                    <div class="chat-person">
                        <a href="messages.php" class="mobile-back" aria-label="Back to inbox">←</a>

                        <div class="avatar small">
                            <?= et_h(et_initial($activeContact['name'])) ?>
                        </div>

                        <div class="chat-person-text">
                            <div class="chat-person-name" id="chatContactName">
                                <?= et_h($activeContact['name']) ?>
                            </div>
                            <div class="chat-person-sub">EduTrade student · Private conversation</div>
                        </div>
                    </div>

                    <div class="private-label"><span>●</span> Private chat</div>
                </header>

                <div class="messages-scroll" id="messagesScroll">
                    <div class="messages-list" id="messagesList">
                        <div class="empty-state">
                            <div class="empty-icon">✉</div>
                            <h3>Opening conversation…</h3>
                            <p>Your messages will appear here.</p>
                        </div>
                    </div>
                </div>

                <div class="composer-wrap">
                    <div class="composer-error" id="composerError" role="alert"></div>

                    <form class="composer" id="messageForm">
                        <textarea
                            id="messageInput"
                            maxlength="8000"
                            rows="1"
                            placeholder="Write a message…"
                            aria-label="Write a message"
                            required
                        ></textarea>

                        <button
                            class="send-btn"
                            id="sendButton"
                            type="submit"
                            aria-label="Send message"
                            title="Send message"
                        >➤</button>
                    </form>

                    <div class="composer-hint">
                        <span>Be kind. Keep campus conversations respectful.</span>
                        <span id="characterCount">0 / 8000</span>
                    </div>
                </div>

            <?php else: ?>

                <div class="welcome-panel">
                    <div class="empty-state">
                        <div class="empty-icon">✉</div>
                        <h3>Your next connection starts here.</h3>
                        <p>
                            Choose a conversation or search for a student to message a seller,
                            contact a creator, or discuss a campus project.
                        </p>
                    </div>
                </div>

            <?php endif; ?>

        </section>
    </main>

    <footer class="page-footer">
        A better campus starts with <strong>student-to-student connections.</strong>
    </footer>

</div>

<script>
(() => {
    'use strict';

    const activeId = <?= (int)$activeId ?>;
    const csrfToken = <?= json_encode($csrfToken, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>;
    const currentUserId = <?= (int)$currentUserId ?>;
    const apiBase = 'messages.php';

    const searchInput = document.getElementById('studentSearch');
    const searchResults = document.getElementById('searchResults');
    const messagesScroll = document.getElementById('messagesScroll');
    const messagesList = document.getElementById('messagesList');
    const messageForm = document.getElementById('messageForm');
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');
    const composerError = document.getElementById('composerError');
    const characterCount = document.getElementById('characterCount');

    let searchTimer = null;
    let pollTimer = null;
    let lastRenderedId = 0;
    let firstLoad = true;

    function initials(name) {
        const clean = String(name || 'S').trim();
        return Array.from(clean)[0]
            ? Array.from(clean)[0].toUpperCase()
            : 'S';
    }

    function safeTime(value) {
        if (!value) return '';

        const parsed = new Date(String(value).replace(' ', 'T'));

        if (Number.isNaN(parsed.getTime())) return '';

        return parsed.toLocaleTimeString([], {
            hour: 'numeric',
            minute: '2-digit'
        });
    }

    function showError(message) {
        if (!composerError) return;
        composerError.textContent = message || 'Something went wrong. Please try again.';
        composerError.classList.add('show');
    }

    function clearError() {
        if (!composerError) return;
        composerError.textContent = '';
        composerError.classList.remove('show');
    }

    async function parseJson(response) {
        let data;

        try {
            data = await response.json();
        } catch (_) {
            throw new Error('The server returned an unexpected response. Check PHP errors and try again.');
        }

        if (!response.ok || !data.success) {
            throw new Error(data.error || 'The request could not be completed.');
        }

        return data;
    }

    async function apiPost(action, payload) {
        const response = await fetch(
            `${apiBase}?action=${encodeURIComponent(action)}`,
            {
                method: 'POST',
                cache: 'no-store',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken,
                    'Accept': 'application/json'
                },
                body: JSON.stringify(payload)
            }
        );

        return parseJson(response);
    }

    function makeEmptyState(title, text) {
        const wrapper = document.createElement('div');
        wrapper.className = 'empty-state';

        const icon = document.createElement('div');
        icon.className = 'empty-icon';
        icon.textContent = '✉';

        const heading = document.createElement('h3');
        heading.textContent = title;

        const paragraph = document.createElement('p');
        paragraph.textContent = text;

        wrapper.append(icon, heading, paragraph);
        return wrapper;
    }

    function makeMessage(message) {
        const isOwn = Number(message.sender_id) === currentUserId;

        const row = document.createElement('div');
        row.className = `message-row ${isOwn ? 'own' : 'other'}`;
        row.dataset.messageId = String(message.id);

        if (!isOwn) {
            const avatar = document.createElement('div');
            avatar.className = 'message-avatar';

            const nameNode = document.getElementById('chatContactName');
            avatar.textContent = initials(nameNode ? nameNode.textContent : 'S');

            row.appendChild(avatar);
        }

        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';

        const text = document.createElement('p');
        text.className = 'message-text';
        text.textContent = String(message.message || '');

        const meta = document.createElement('div');
        meta.className = 'message-time';

        const time = document.createElement('span');
        time.textContent = safeTime(message.created_at);
        meta.appendChild(time);

        if (isOwn && Number(message.is_read) === 1) {
            const read = document.createElement('span');
            read.textContent = '✓✓';
            read.setAttribute('aria-label', 'Read');
            meta.appendChild(read);
        }

        bubble.append(text, meta);
        row.appendChild(bubble);

        return row;
    }

    async function loadMessages(forceScroll = false) {
        if (!activeId || !messagesList || !messagesScroll) return;

        const wasNearBottom =
            messagesScroll.scrollHeight -
            messagesScroll.scrollTop -
            messagesScroll.clientHeight < 100;

        try {
            const data = await apiPost('fetch', {with: activeId});
            const list = Array.isArray(data.messages) ? data.messages : [];
            const newLastId = list.length
                ? Number(list[list.length - 1].id)
                : 0;

            messagesList.replaceChildren();

            if (list.length === 0) {
                messagesList.appendChild(
                    makeEmptyState(
                        'Start with a hello.',
                        'This is your private conversation. Send the first message whenever you are ready.'
                    )
                );
            } else {
                list.forEach(item => {
                    messagesList.appendChild(makeMessage(item));
                });
            }

            if (
                firstLoad ||
                forceScroll ||
                (wasNearBottom && newLastId !== lastRenderedId)
            ) {
                messagesScroll.scrollTop = messagesScroll.scrollHeight;
            }

            firstLoad = false;
            lastRenderedId = newLastId;

            const activeLink = document.querySelector(
                `.contact-link[data-user-id="${activeId}"]`
            );

            if (activeLink) {
                const badge = activeLink.querySelector('.unread-badge');
                if (badge) badge.remove();
            }
        } catch (error) {
            if (firstLoad) {
                messagesList.replaceChildren(
                    makeEmptyState('Could not load messages', error.message)
                );
                firstLoad = false;
            }
        }
    }

    function buildSearchResult(user) {
        const link = document.createElement('a');
        link.className = 'search-result';
        link.href = `?with=${encodeURIComponent(Number(user.id))}`;

        const avatar = document.createElement('div');
        avatar.className = 'avatar';
        avatar.textContent = initials(user.name);

        const details = document.createElement('div');

        const name = document.createElement('div');
        name.className = 'search-result-name';
        name.textContent = user.name || 'Student';

        const hint = document.createElement('div');
        hint.className = 'search-result-hint';
        hint.textContent = 'Start a private conversation';

        details.append(name, hint);
        link.append(avatar, details);

        return link;
    }

    if (searchInput && searchResults) {
        searchInput.addEventListener('input', () => {
            clearTimeout(searchTimer);

            const query = searchInput.value.trim();

            if (!query) {
                searchResults.replaceChildren();
                searchResults.classList.remove('visible');
                return;
            }

            searchResults.classList.add('visible');
            searchResults.replaceChildren();

            const loading = document.createElement('div');
            loading.className = 'search-empty';
            loading.textContent = 'Searching students…';
            searchResults.appendChild(loading);

            searchTimer = setTimeout(async () => {
                try {
                    const response = await fetch(
                        `${apiBase}?action=search_users&q=${encodeURIComponent(query)}`,
                        {
                            cache: 'no-store',
                            headers: {'Accept': 'application/json'}
                        }
                    );

                    const data = await parseJson(response);
                    searchResults.replaceChildren();

                    if (!data.users || data.users.length === 0) {
                        const empty = document.createElement('div');
                        empty.className = 'search-empty';
                        empty.textContent = 'No students found. Try another name.';
                        searchResults.appendChild(empty);
                        return;
                    }

                    data.users.forEach(user => {
                        searchResults.appendChild(buildSearchResult(user));
                    });
                } catch (_) {
                    searchResults.replaceChildren();

                    const error = document.createElement('div');
                    error.className = 'search-empty';
                    error.textContent = 'Search is unavailable right now.';
                    searchResults.appendChild(error);
                }
            }, 220);
        });
    }

    if (messageInput) {
        const resize = () => {
            messageInput.style.height = 'auto';
            messageInput.style.height =
                `${Math.min(messageInput.scrollHeight, 120)}px`;
        };

        messageInput.addEventListener('input', () => {
            resize();

            if (characterCount) {
                characterCount.textContent =
                    `${messageInput.value.length} / 8000`;
            }

            clearError();
        });

        messageInput.addEventListener('keydown', event => {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();

                if (messageForm) {
                    messageForm.requestSubmit();
                }
            }
        });
    }

    if (messageForm && messageInput && sendButton && activeId) {
        messageForm.addEventListener('submit', async event => {
            event.preventDefault();

            const message = messageInput.value.trim();

            if (!message) {
                showError('Type a message before sending.');
                messageInput.focus();
                return;
            }

            if (message.length > 8000) {
                showError('Your message is too long.');
                return;
            }

            clearError();
            sendButton.disabled = true;

            try {
                await apiPost('send', {
                    with: activeId,
                    message: message
                });

                messageInput.value = '';
                messageInput.style.height = 'auto';

                if (characterCount) {
                    characterCount.textContent = '0 / 8000';
                }

                await loadMessages(true);
                messageInput.focus();
            } catch (error) {
                showError(error.message);
            } finally {
                sendButton.disabled = false;
            }
        });

        loadMessages(true);

        pollTimer = setInterval(() => {
            if (!document.hidden) {
                loadMessages(false);
            }
        }, 3000);
    }

    window.addEventListener('beforeunload', () => {
        if (pollTimer) clearInterval(pollTimer);
        if (searchTimer) clearTimeout(searchTimer);
    });
})();
</script>
</body>
</html>
