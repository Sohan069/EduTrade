<?php
session_start();

require_once "../config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../includes/login.php");
    exit;
}

$currentUserId = (int)$_SESSION['user_id'];

$userName = $_SESSION['name'] ?? 'Student';

function clean($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Extract project title from message
|--------------------------------------------------------------------------
*/

function getProjectTitle($message)
{
    $message = trim((string)$message);

    if (
        preg_match(
            '/^\[Project:\s*(.*?)\]\s*(?:\r?\n|$)/i',
            $message,
            $matches
        )
    ) {
        return trim($matches[1]);
    }

    return "Project Request";
}

/*
|--------------------------------------------------------------------------
| Remove project title from displayed message
|--------------------------------------------------------------------------
*/

function getCleanMessage($message)
{
    $message = trim((string)$message);

    $message = preg_replace(
        '/^\[Project:\s*.*?\]\s*(?:\r?\n|$)/i',
        '',
        $message
    );

    return trim($message);
}

/*
|--------------------------------------------------------------------------
| UPDATE REQUEST STATUS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $requestId = (int)($_POST['request_id'] ?? 0);
    $newStatus = trim($_POST['status'] ?? '');

    $allowedStatuses = [
        'Accepted',
        'Rejected',
        'Started',
        'Completed',
        'Cancelled'
    ];

    if (
        $requestId > 0 &&
        in_array($newStatus, $allowedStatuses, true)
    ) {

        /*
         * Provider/receiver is allowed to update the request.
         * We check BOTH ID systems because the table contains both.
         */

        $update = $conn->prepare("
            UPDATE hire_requests
            SET status = ?
            WHERE id = ?
              AND (
                    receiver_id = ?
                    OR provider_id = ?
                  )
            LIMIT 1
        ");

        if ($update) {

            $update->bind_param(
                "siii",
                $newStatus,
                $requestId,
                $currentUserId,
                $currentUserId
            );

            $update->execute();
            $update->close();
        }
    }

    header("Location: hire_requests.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| FETCH INCOMING REQUESTS
|--------------------------------------------------------------------------
|
| We use requester_id/provider_id OR sender_id/receiver_id.
| Therefore old and new requests both appear.
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        hr.id,
        hr.sender_id,
        hr.receiver_id,
        hr.skill_id,
        hr.requester_id,
        hr.provider_id,
        hr.message,
        hr.budget,
        hr.status,
        hr.created_at,
        hr.updated_at,

        requester.name AS requester_name,
        requester.email AS requester_email,

        sender.name AS sender_name,
        sender.email AS sender_email,

        provider.name AS provider_name,
        provider.email AS provider_email,

        s.title AS skill_title,
        s.category AS skill_category,
        s.image AS skill_image

    FROM hire_requests hr

    LEFT JOIN users requester
        ON requester.id = hr.requester_id

    LEFT JOIN users sender
        ON sender.id = hr.sender_id

    LEFT JOIN users provider
        ON provider.id = hr.provider_id

    LEFT JOIN skills s
        ON s.id = hr.skill_id

    WHERE
        (
            hr.provider_id = ?
            OR hr.receiver_id = ?
        )

    ORDER BY
        CASE hr.status
            WHEN 'Pending' THEN 1
            WHEN 'Accepted' THEN 2
            WHEN 'Started' THEN 3
            WHEN 'Completed' THEN 4
            WHEN 'Rejected' THEN 5
            WHEN 'Cancelled' THEN 6
            ELSE 7
        END,
        hr.created_at DESC
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Database Error: " . clean($conn->error));
}

$stmt->bind_param(
    "ii",
    $currentUserId,
    $currentUserId
);

$stmt->execute();

$result = $stmt->get_result();

$requests = [];

while ($row = $result->fetch_assoc()) {
    $requests[] = $row;
}

$stmt->close();

/*
|--------------------------------------------------------------------------
| Counts
|--------------------------------------------------------------------------
*/

$totalRequests = count($requests);

$pendingCount = 0;
$activeCount = 0;
$completedCount = 0;

foreach ($requests as $request) {

    if ($request['status'] === 'Pending') {
        $pendingCount++;
    }

    if (
        $request['status'] === 'Accepted' ||
        $request['status'] === 'Started'
    ) {
        $activeCount++;
    }

    if ($request['status'] === 'Completed') {
        $completedCount++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Hire Requests | EduTrade</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap"
    rel="stylesheet"
>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Poppins', sans-serif;
    background:
        radial-gradient(circle at 12% 8%, rgba(34,211,238,.13), transparent 30%),
        radial-gradient(circle at 88% 16%, rgba(168,85,247,.15), transparent 32%),
        radial-gradient(circle at 50% 100%, rgba(236,72,153,.07), transparent 35%),
        #070b18;
    color: #fff;
    min-height: 100vh;
}

a {
    text-decoration: none;
    color: inherit;
}

/* SIDEBAR */

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 245px;
    height: 100vh;
    padding: 28px 18px;
    background: rgba(7,17,31,.88);
    border-right: 1px solid rgba(255,255,255,.08);
    backdrop-filter: blur(22px);
    z-index: 20;
}

.logo {
    font-size: 25px;
    font-weight: 800;
    margin-bottom: 40px;
    padding-left: 12px;
}

.logo span {
    color: #22d3ee;
}

.nav-title {
    font-size: 11px;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    padding: 0 12px;
    margin-bottom: 12px;
}

.nav-link {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 13px 14px;
    margin-bottom: 6px;
    border-radius: 12px;
    color: #94a3b8;
    transition: .25s;
}

.nav-link:hover {
    background: rgba(255,255,255,.06);
    color: #fff;
    transform: translateX(3px);
}

.nav-link.active {
    background: linear-gradient(
        135deg,
        rgba(34,211,238,.16),
        rgba(168,85,247,.10)
    );
    color: #22d3ee;
    border: 1px solid rgba(34,211,238,.20);
}

.logout {
    position: absolute;
    bottom: 25px;
    left: 18px;
    right: 18px;
    color: #f87171;
}

/* MAIN */

.main {
    margin-left: 245px;
    padding: 45px;
    max-width: 1500px;
}

.top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
    margin-bottom: 35px;
}

.eyebrow {
    color: #22d3ee;
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    margin-bottom: 8px;
}

h1 {
    font-size: clamp(30px, 4vw, 48px);
    letter-spacing: -1.5px;
    margin-bottom: 10px;
}

.subtitle {
    color: #94a3b8;
    line-height: 1.7;
}

/* STATS */

.stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
    margin-bottom: 35px;
}

.stat {
    padding: 23px;
    border-radius: 20px;
    background: rgba(15,27,45,.72);
    border: 1px solid rgba(255,255,255,.07);
    box-shadow: 0 15px 45px rgba(0,0,0,.16);
}

.stat-label {
    color: #64748b;
    font-size: 13px;
    margin-bottom: 9px;
}

.stat-value {
    font-size: 30px;
    font-weight: 800;
}

/* REQUEST */

.requests {
    display: grid;
    gap: 20px;
}

.request-card {
    position: relative;
    overflow: hidden;
    padding: 26px;
    border-radius: 24px;
    background: rgba(15,27,45,.78);
    border: 1px solid rgba(255,255,255,.08);
    box-shadow: 0 20px 60px rgba(0,0,0,.18);
    transition: .3s;
}

.request-card:hover {
    transform: translateY(-3px);
    border-color: rgba(34,211,238,.24);
}

.request-card::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
    background: linear-gradient(135deg, #22d3ee, #8b5cf6 70%, #ec4899);
}

.request-header {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    align-items: flex-start;
    margin-bottom: 22px;
}

.student {
    display: flex;
    gap: 15px;
    align-items: center;
}

.avatar {
    width: 50px;
    height: 50px;
    border-radius: 15px;
    display: grid;
    place-items: center;
    background: linear-gradient(135deg, #22d3ee, #7c3aed 65%, #ec4899);
    font-size: 20px;
    font-weight: 800;
}

.student-name {
    font-size: 17px;
    font-weight: 700;
}

.student-email {
    color: #64748b;
    font-size: 13px;
    margin-top: 4px;
}

.status {
    padding: 8px 13px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 800;
}

.status.Pending {
    color: #fbbf24;
    background: rgba(251,191,36,.12);
}

.status.Accepted {
    color: #22d3ee;
    background: rgba(96,165,250,.12);
}

.status.Started {
    color: #22d3ee;
    background: rgba(34,211,238,.12);
}

.status.Completed {
    color: #a78bfa;
    background: rgba(167,139,250,.12);
}

.status.Rejected,
.status.Cancelled {
    color: #f87171;
    background: rgba(248,113,113,.12);
}

.project-title {
    font-size: 23px;
    font-weight: 800;
    margin-bottom: 14px;
}

.skill {
    color: #22d3ee;
    font-size: 13px;
    font-weight: 700;
    margin-bottom: 20px;
}

.details {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
    margin-bottom: 20px;
}

.detail {
    padding: 15px;
    border-radius: 15px;
    background: rgba(255,255,255,.035);
    border: 1px solid rgba(255,255,255,.05);
}

.detail-label {
    font-size: 11px;
    color: #64748b;
    margin-bottom: 5px;
    text-transform: uppercase;
}

.detail-value {
    font-size: 14px;
    font-weight: 700;
}

.message {
    padding: 18px;
    border-radius: 16px;
    background: rgba(0,0,0,.16);
    color: #cbd5e1;
    line-height: 1.7;
    margin-bottom: 20px;
    white-space: pre-wrap;
}

.contact-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding: 16px;
    margin-bottom: 20px;
    border-radius: 16px;
    background: linear-gradient(135deg, rgba(34,211,238,.07), rgba(168,85,247,.08));
    border: 1px solid rgba(34,211,238,.17);
}

.contact-info strong {
    display: block;
    font-size: 12px;
    color: #64748b;
    margin-bottom: 5px;
}

.contact-info span {
    color: #cbd5e1;
    font-size: 14px;
}

.contact-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 11px 17px;
    border-radius: 12px;
    background: rgba(34,211,238,.10);
    color: #22d3ee;
    font-weight: 700;
    font-size: 13px;
    border: 1px solid rgba(34,211,238,.20);
}

.actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.btn {
    border: none;
    cursor: pointer;
    padding: 11px 17px;
    border-radius: 11px;
    font-family: inherit;
    font-weight: 700;
    transition: .2s;
}

.btn:hover {
    transform: translateY(-2px);
}

.btn-green {
    background: linear-gradient(135deg, #22d3ee, #8b5cf6 70%, #ec4899);
    color: #ffffff;
}

.btn-red {
    background: rgba(248,113,113,.12);
    color: #f87171;
    border: 1px solid rgba(248,113,113,.15);
}

.btn-blue {
    background: rgba(34,211,238,.10);
    color: #22d3ee;
    border: 1px solid rgba(34,211,238,.18);
}

.btn-purple {
    background: rgba(167,139,250,.13);
    color: #c4b5fd;
    border: 1px solid rgba(167,139,250,.15);
}

.date {
    margin-top: 16px;
    color: #475569;
    font-size: 12px;
}

/* EMPTY */

.empty {
    padding: 80px 25px;
    text-align: center;
    border: 1px dashed rgba(255,255,255,.12);
    border-radius: 24px;
    background: rgba(15,27,45,.45);
}

.empty-icon {
    font-size: 50px;
    margin-bottom: 18px;
}

.empty h2 {
    margin-bottom: 10px;
}

.empty p {
    color: #64748b;
    margin-bottom: 22px;
}

.empty-btn {
    display: inline-block;
    padding: 13px 20px;
    border-radius: 12px;
    background: linear-gradient(135deg, #22d3ee, #8b5cf6 70%, #ec4899);
    color: #ffffff;
    font-weight: 800;
}

/* MOBILE */

.mobile-back {
    display: none;
}

@media(max-width: 900px) {

    .sidebar {
        display: none;
    }

    .main {
        margin-left: 0;
        padding: 25px 18px;
    }

    .mobile-back {
        display: inline-block;
        color: #22d3ee;
        margin-bottom: 25px;
        font-weight: 700;
    }

    .stats {
        grid-template-columns: 1fr;
    }

    .details {
        grid-template-columns: 1fr;
    }

    .request-header {
        flex-direction: column;
    }

    .contact-box {
        flex-direction: column;
        align-items: flex-start;
    }

    .top {
        flex-direction: column;
    }
}

</style>

</head>

<body>

<aside class="sidebar">

    <div class="logo">
        Edu<span>Trade</span>
    </div>

    <div class="nav-title">Workspace</div>

    <a href="dashboard.php" class="nav-link">
        🏠 Dashboard
    </a>

    <a href="marketplace.php" class="nav-link">
        🛒 Marketplace
    </a>

    <a href="skills.php" class="nav-link">
        💼 Skill Hub
    </a>

    <a href="wishlist.php" class="nav-link">
        ♡ Wishlist
    </a>

    <a href="hire_requests.php" class="nav-link active">
        📩 Hire Requests
    </a>

    <a href="../includes/logout.php" class="nav-link logout">
        ↪ Logout
    </a>

</aside>


<main class="main">

    <a href="skills.php" class="mobile-back">
        ← Back to Skill Hub
    </a>

    <section class="top">

        <div>

            <div class="eyebrow">
                Skill Hub
            </div>

            <h1>Hire Requests</h1>

            <p class="subtitle">
                Manage students who want to work with you.
                Accept projects, start work, and complete them.
            </p>

        </div>

    </section>


    <section class="stats">

        <div class="stat">
            <div class="stat-label">
                Total Requests
            </div>

            <div class="stat-value">
                <?php echo $totalRequests; ?>
            </div>
        </div>


        <div class="stat">
            <div class="stat-label">
                Pending
            </div>

            <div class="stat-value">
                <?php echo $pendingCount; ?>
            </div>
        </div>


        <div class="stat">
            <div class="stat-label">
                Active Projects
            </div>

            <div class="stat-value">
                <?php echo $activeCount; ?>
            </div>
        </div>

    </section>


    <?php if (empty($requests)): ?>

        <div class="empty">

            <div class="empty-icon">
                📩
            </div>

            <h2>No Hire Requests Yet</h2>

            <p>
                When another student hires you, their project request
                will appear here.
            </p>

            <a href="skills.php" class="empty-btn">
                View Skill Hub
            </a>

        </div>

    <?php else: ?>

        <section class="requests">

            <?php foreach ($requests as $request): ?>

                <?php

                $projectTitle = getProjectTitle(
                    $request['message']
                );

                $cleanMessage = getCleanMessage(
                    $request['message']
                );

                /*
                 * Prefer requester information.
                 * Fall back to sender information for old requests.
                 */

                $studentName =
                    !empty($request['requester_name'])
                    ? $request['requester_name']
                    : $request['sender_name'];

                $studentEmail =
                    !empty($request['requester_email'])
                    ? $request['requester_email']
                    : $request['sender_email'];

                $initial =
                    strtoupper(
                        substr(
                            trim($studentName ?: 'S'),
                            0,
                            1
                        )
                    );

                ?>

                <article class="request-card">

                    <div class="request-header">

                        <div class="student">

                            <div class="avatar">
                                <?php echo clean($initial); ?>
                            </div>

                            <div>

                                <div class="student-name">
                                    <?php
                                    echo clean(
                                        $studentName ?: 'Student'
                                    );
                                    ?>
                                </div>

                                <div class="student-email">
                                    <?php
                                    echo clean(
                                        $studentEmail ?: 'Email unavailable'
                                    );
                                    ?>
                                </div>

                            </div>

                        </div>


                        <div class="status <?php echo clean($request['status']); ?>">
                            <?php echo clean($request['status']); ?>
                        </div>

                    </div>


                    <div class="project-title">
                        <?php echo clean($projectTitle); ?>
                    </div>


                    <div class="skill">

                        💼
                        <?php
                        echo clean(
                            $request['skill_title']
                            ?: 'Skill'
                        );
                        ?>

                        <?php if (!empty($request['skill_category'])): ?>

                            ·
                            <?php
                            echo clean(
                                $request['skill_category']
                            );
                            ?>

                        <?php endif; ?>

                    </div>


                    <div class="details">

                        <div class="detail">

                            <div class="detail-label">
                                Budget
                            </div>

                            <div class="detail-value">
                                ₹<?php
                                echo number_format(
                                    (float)$request['budget'],
                                    2
                                );
                                ?>
                            </div>

                        </div>


                        <div class="detail">

                            <div class="detail-label">
                                Status
                            </div>

                            <div class="detail-value">
                                <?php
                                echo clean(
                                    $request['status']
                                );
                                ?>
                            </div>

                        </div>


                        <div class="detail">

                            <div class="detail-label">
                                Received
                            </div>

                            <div class="detail-value">
                                <?php
                                echo date(
                                    'd M Y',
                                    strtotime(
                                        $request['created_at']
                                    )
                                );
                                ?>
                            </div>

                        </div>

                    </div>


                    <?php if ($cleanMessage !== ''): ?>

                        <div class="message">
                            <?php echo clean($cleanMessage); ?>
                        </div>

                    <?php endif; ?>


                    <?php if (!empty($studentEmail)): ?>

                        <div class="contact-box">

                            <div class="contact-info">

                                <strong>
                                    CONTACT STUDENT
                                </strong>

                                <span>
                                    <?php
                                    echo clean($studentEmail);
                                    ?>
                                </span>

                            </div>


                            <a
                                class="contact-btn"
                                href="mailto:<?php echo clean($studentEmail); ?>?subject=<?php echo rawurlencode('EduTrade Project - ' . $projectTitle); ?>"
                            >
                                ✉ Contact Student
                            </a>

                        </div>

                    <?php endif; ?>


                    <div class="actions">

                        <?php if ($request['status'] === 'Pending'): ?>

                            <form method="POST">

                                <input
                                    type="hidden"
                                    name="request_id"
                                    value="<?php echo (int)$request['id']; ?>"
                                >

                                <input
                                    type="hidden"
                                    name="status"
                                    value="Accepted"
                                >

                                <button
                                    type="submit"
                                    class="btn btn-green"
                                >
                                    ✓ Accept Request
                                </button>

                            </form>


                            <form method="POST">

                                <input
                                    type="hidden"
                                    name="request_id"
                                    value="<?php echo (int)$request['id']; ?>"
                                >

                                <input
                                    type="hidden"
                                    name="status"
                                    value="Rejected"
                                >

                                <button
                                    type="submit"
                                    class="btn btn-red"
                                >
                                    ✕ Reject
                                </button>

                            </form>

                        <?php elseif ($request['status'] === 'Accepted'): ?>

                            <form method="POST">

                                <input
                                    type="hidden"
                                    name="request_id"
                                    value="<?php echo (int)$request['id']; ?>"
                                >

                                <input
                                    type="hidden"
                                    name="status"
                                    value="Started"
                                >

                                <button
                                    type="submit"
                                    class="btn btn-blue"
                                >
                                    🚀 Start Project
                                </button>

                            </form>

                        <?php elseif ($request['status'] === 'Started'): ?>

                            <form method="POST">

                                <input
                                    type="hidden"
                                    name="request_id"
                                    value="<?php echo (int)$request['id']; ?>"
                                >

                                <input
                                    type="hidden"
                                    name="status"
                                    value="Completed"
                                >

                                <button
                                    type="submit"
                                    class="btn btn-purple"
                                >
                                    ✓ Complete Project
                                </button>

                            </form>

                        <?php elseif ($request['status'] === 'Completed'): ?>

                            <span class="btn btn-purple">
                                ✓ Project Completed
                            </span>

                        <?php elseif ($request['status'] === 'Rejected'): ?>

                            <span class="btn btn-red">
                                Request Rejected
                            </span>

                        <?php elseif ($request['status'] === 'Cancelled'): ?>

                            <span class="btn btn-red">
                                Request Cancelled
                            </span>

                        <?php endif; ?>

                    </div>


                    <div class="date">
                        Request ID #<?php echo (int)$request['id']; ?>
                        ·
                        Last updated
                        <?php
                        echo date(
                            'd M Y, h:i A',
                            strtotime(
                                $request['updated_at']
                            )
                        );
                        ?>
                    </div>

                </article>

            <?php endforeach; ?>

        </section>

    <?php endif; ?>

</main>

<script>
/* Update request status without navigating away from Hire Requests. */
document.addEventListener('submit', async function (event) {
    const form = event.target;

    if (!form.matches('.actions form')) return;

    event.preventDefault();

    const button = form.querySelector('button[type="submit"]');
    const originalText = button ? button.textContent : '';

    if (button) {
        button.disabled = true;
        button.textContent = 'Updating...';
    }

    try {
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: new FormData(form),
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            credentials: 'same-origin'
        });

        if (!response.ok) throw new Error('Request update failed');

        const html = await response.text();
        const parsed = new DOMParser().parseFromString(html, 'text/html');
        const newMain = parsed.querySelector('.main');
        const currentMain = document.querySelector('.main');

        if (!newMain || !currentMain) throw new Error('Could not refresh requests');

        currentMain.replaceWith(newMain);

        // Keep the user on this page and allow the newly inserted forms to work.
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
        if (button) {
            button.disabled = false;
            button.textContent = originalText;
        }
        alert('Could not update the request. Please try again.');
    }
});
</script>

</body>
</html>