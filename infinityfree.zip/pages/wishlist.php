<?php
session_start();

require_once "../config/db.php";

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../includes/login.php");
    exit;
}

$userId = (int)$_SESSION['user_id'];
$userName = $_SESSION['name'] ?? 'Student';

function clean($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/* =========================================================
   REMOVE SAVED PRODUCT
========================================================= */
if (isset($_GET['remove'])) {

    $productId = (int)$_GET['remove'];

    if ($productId > 0) {

        $stmt = $conn->prepare("
            DELETE FROM saved_products
            WHERE user_id = ? AND product_id = ?
        ");

        if ($stmt) {
            $stmt->bind_param("ii", $userId, $productId);
            $stmt->execute();
            $stmt->close();
        }
    }

    header("Location: wishlist.php?removed=1");
    exit;
}

/* =========================================================
   FETCH SAVED PRODUCTS
========================================================= */

$savedProducts = [];

$sql = "
    SELECT
        sp.id AS saved_id,
        sp.created_at AS saved_at,

        p.id,
        p.user_id,
        p.title,
        p.description,
        p.price,
        p.product_condition,
        p.image,
        p.product_age,
        p.quantity,
        p.negotiable,
        p.location,
        p.created_at,

        u.name AS seller_name

    FROM saved_products sp

    INNER JOIN products p
        ON sp.product_id = p.id

    LEFT JOIN users u
        ON p.user_id = u.id

    WHERE sp.user_id = ?

    ORDER BY sp.created_at DESC
";

$stmt = $conn->prepare($sql);

if ($stmt) {

    $stmt->bind_param("i", $userId);
    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $savedProducts[] = $row;
    }

    $stmt->close();
}

/* =========================================================
   PRODUCT IMAGE HELPER
========================================================= */

function getProductImage($image)
{
    $image = trim((string)$image);

    if ($image === '') {
        return '';
    }

    $filename = basename(str_replace('\\', '/', $image));

    $physicalPath = dirname(__DIR__) . "/uploads/products/" . $filename;

    if (!file_exists($physicalPath)) {
        return '';
    }

    return "../uploads/products/" . rawurlencode($filename);
}

/* =========================================================
   CATEGORY DETECTION
========================================================= */

function getCategory($title, $description)
{
    $text = strtolower($title . ' ' . $description);

    if (
        strpos($text, 'book') !== false ||
        strpos($text, 'notes') !== false ||
        strpos($text, 'textbook') !== false ||
        strpos($text, 'reference') !== false
    ) {
        return ['Books', '📚'];
    }

    if (
        strpos($text, 'lab') !== false ||
        strpos($text, 'kit') !== false ||
        strpos($text, 'equipment') !== false
    ) {
        return ['Lab Equipment', '🧪'];
    }

    if (
        strpos($text, 'laptop') !== false ||
        strpos($text, 'computer') !== false ||
        strpos($text, 'keyboard') !== false ||
        strpos($text, 'mouse') !== false ||
        strpos($text, 'electronic') !== false ||
        strpos($text, 'charger') !== false
    ) {
        return ['Electronics', '💻'];
    }

    if (
        strpos($text, 'bag') !== false ||
        strpos($text, 'stationery') !== false ||
        strpos($text, 'pen') !== false ||
        strpos($text, 'calculator') !== false
    ) {
        return ['Bags & Stationery', '🎒'];
    }

    return ['Campus Items', '🎓'];
}

$totalSaved = count($savedProducts);
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Wishlist | EduTrade</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
        rel="stylesheet"
    >

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Inter', sans-serif;
            background:
                radial-gradient(circle at 10% 0%, rgba(34, 211, 238, 0.10), transparent 28%),
                radial-gradient(circle at 90% 10%, rgba(139, 92, 246, 0.12), transparent 30%),
                #050816;
            color: #f8fafc;
            min-height: 100vh;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        button {
            font-family: inherit;
        }

        /* =====================================================
           SIDEBAR
        ===================================================== */

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;

            padding: 26px 18px;

            background:
                linear-gradient(
                    180deg,
                    rgba(15, 23, 42, 0.98),
                    rgba(2, 6, 23, 0.98)
                );

            border-right: 1px solid rgba(148, 163, 184, 0.12);

            z-index: 1000;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;

            padding: 0 12px 28px;
        }

        .brand-icon {
            width: 44px;
            height: 44px;

            border-radius: 14px;

            display: flex;
            align-items: center;
            justify-content: center;

            font-size: 22px;

            background:
                linear-gradient(
                    135deg,
                    #22d3ee,
                    #6366f1
                );

            box-shadow:
                0 10px 30px rgba(34, 211, 238, 0.20);
        }

        .brand h2 {
            font-size: 20px;
            font-weight: 800;
            letter-spacing: -0.5px;
        }

        .brand span {
            display: block;
            margin-top: 3px;

            font-size: 10px;
            color: #94a3b8;

            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .nav-title {
            padding: 0 13px;
            margin: 12px 0 10px;

            color: #64748b;

            font-size: 10px;
            font-weight: 700;

            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 13px;

            padding: 13px 14px;
            margin-bottom: 5px;

            border-radius: 13px;

            color: #94a3b8;

            font-size: 13px;
            font-weight: 600;

            transition: 0.25s ease;
        }

        .nav-item:hover {
            color: #fff;

            background: rgba(255, 255, 255, 0.05);

            transform: translateX(3px);
        }

        .nav-item.active {
            color: #fff;

            background:
                linear-gradient(
                    135deg,
                    rgba(34, 211, 238, 0.16),
                    rgba(99, 102, 241, 0.18)
                );

            border: 1px solid rgba(34, 211, 238, 0.12);

            box-shadow:
                0 8px 25px rgba(34, 211, 238, 0.05);
        }

        .nav-icon {
            width: 25px;
            text-align: center;
            font-size: 17px;
        }

        .sidebar-bottom {
            position: absolute;
            left: 18px;
            right: 18px;
            bottom: 22px;
        }

        .user-mini {
            display: flex;
            align-items: center;
            gap: 11px;

            padding: 12px;

            border-radius: 14px;

            background: rgba(255, 255, 255, 0.035);
            border: 1px solid rgba(148, 163, 184, 0.10);
        }

        .avatar {
            width: 36px;
            height: 36px;

            border-radius: 11px;

            display: flex;
            align-items: center;
            justify-content: center;

            background:
                linear-gradient(
                    135deg,
                    #06b6d4,
                    #6366f1
                );

            font-size: 13px;
            font-weight: 800;
        }

        .user-mini strong {
            display: block;
            max-width: 130px;

            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;

            font-size: 12px;
        }

        .user-mini small {
            color: #64748b;
            font-size: 10px;
        }

        /* =====================================================
           MAIN
        ===================================================== */

        .main {
            margin-left: 260px;
            padding: 38px 42px 60px;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;

            margin-bottom: 34px;
        }

        .eyebrow {
            color: #22d3ee;

            font-size: 11px;
            font-weight: 800;

            text-transform: uppercase;
            letter-spacing: 2px;

            margin-bottom: 8px;
        }

        .page-title {
            font-size: clamp(28px, 4vw, 42px);
            line-height: 1.05;

            letter-spacing: -1.5px;
            font-weight: 800;
        }

        .page-title span {
            background:
                linear-gradient(
                    90deg,
                    #22d3ee,
                    #818cf8
                );

            -webkit-background-clip: text;
            background-clip: text;

            color: transparent;
        }

        .subtitle {
            margin-top: 10px;

            color: #64748b;
            font-size: 13px;
        }

        .count-box {
            min-width: 110px;

            padding: 15px 20px;

            text-align: center;

            border-radius: 16px;

            background:
                linear-gradient(
                    135deg,
                    rgba(34, 211, 238, 0.08),
                    rgba(99, 102, 241, 0.10)
                );

            border: 1px solid rgba(34, 211, 238, 0.12);
        }

        .count-box strong {
            display: block;

            font-size: 24px;
            font-weight: 800;

            color: #22d3ee;
        }

        .count-box span {
            display: block;

            margin-top: 3px;

            color: #64748b;

            font-size: 10px;
            font-weight: 700;

            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* =====================================================
           ALERT
        ===================================================== */

        .alert {
            padding: 14px 18px;
            margin-bottom: 24px;

            border-radius: 14px;

            background: rgba(34, 197, 94, 0.08);
            border: 1px solid rgba(34, 197, 94, 0.15);

            color: #86efac;

            font-size: 13px;
        }

        /* =====================================================
           GRID
        ===================================================== */

        .products-grid {
            display: grid;

            grid-template-columns:
                repeat(3, minmax(0, 1fr));

            gap: 22px;
        }

        .product-card {
            position: relative;

            overflow: hidden;

            border-radius: 22px;

            background:
                linear-gradient(
                    145deg,
                    rgba(15, 23, 42, 0.92),
                    rgba(8, 15, 32, 0.92)
                );

            border: 1px solid rgba(148, 163, 184, 0.10);

            transition:
                transform 0.3s ease,
                border-color 0.3s ease,
                box-shadow 0.3s ease;

            animation: cardIn 0.5s ease both;
        }

        .product-card:hover {
            transform: translateY(-7px);

            border-color: rgba(34, 211, 238, 0.28);

            box-shadow:
                0 25px 60px rgba(0, 0, 0, 0.30),
                0 0 35px rgba(34, 211, 238, 0.04);
        }

        @keyframes cardIn {
            from {
                opacity: 0;
                transform: translateY(15px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .image-wrap {
            position: relative;

            height: 215px;

            background:
                linear-gradient(
                    135deg,
                    #0f172a,
                    #111827
                );

            overflow: hidden;
        }

        .image-wrap img {
            width: 100%;
            height: 100%;

            object-fit: cover;

            display: block;

            transition: transform 0.45s ease;
        }

        .product-card:hover .image-wrap img {
            transform: scale(1.06);
        }

        .image-placeholder {
            width: 100%;
            height: 100%;

            display: flex;
            align-items: center;
            justify-content: center;

            font-size: 48px;

            color: #334155;

            background:
                radial-gradient(
                    circle at center,
                    rgba(34, 211, 238, 0.08),
                    transparent 55%
                );
        }

        .category-badge {
            position: absolute;
            top: 13px;
            left: 13px;

            padding: 7px 10px;

            border-radius: 9px;

            background: rgba(2, 6, 23, 0.78);

            backdrop-filter: blur(12px);

            border: 1px solid rgba(255,255,255,0.10);

            color: #e2e8f0;

            font-size: 10px;
            font-weight: 700;
        }

        .remove-btn {
            position: absolute;
            top: 12px;
            right: 12px;

            width: 38px;
            height: 38px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 11px;

            background: rgba(2, 6, 23, 0.80);

            border: 1px solid rgba(248, 113, 113, 0.15);

            color: #fca5a5;

            font-size: 17px;

            transition: 0.25s ease;
        }

        .remove-btn:hover {
            background: rgba(239, 68, 68, 0.18);
            color: #f87171;

            transform: scale(1.06);
        }

        .product-content {
            padding: 19px;
        }

        .product-title {
            font-size: 17px;
            font-weight: 750;

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .description {
            margin-top: 8px;

            color: #64748b;

            font-size: 12px;
            line-height: 1.6;

            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;

            overflow: hidden;

            min-height: 38px;
        }

        .price-row {
            display: flex;
            align-items: center;
            justify-content: space-between;

            margin-top: 17px;
        }

        .price {
            color: #22d3ee;

            font-size: 20px;
            font-weight: 800;
        }

        .negotiable {
            color: #86efac;

            font-size: 10px;
            font-weight: 700;
        }

        .condition {
            padding: 6px 9px;

            border-radius: 8px;

            background: rgba(255,255,255,0.04);

            color: #cbd5e1;

            font-size: 10px;
            font-weight: 700;
        }

        .meta {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;

            margin-top: 14px;
        }

        .meta-item {
            padding: 6px 9px;

            border-radius: 8px;

            background: rgba(255,255,255,0.035);

            color: #64748b;

            font-size: 10px;
        }

        .seller {
            display: flex;
            align-items: center;
            gap: 9px;

            margin-top: 17px;
            padding-top: 14px;

            border-top: 1px solid rgba(148, 163, 184, 0.08);
        }

        .seller-avatar {
            width: 29px;
            height: 29px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 9px;

            background: rgba(99, 102, 241, 0.15);

            color: #a5b4fc;

            font-size: 10px;
            font-weight: 800;
        }

        .seller-info {
            min-width: 0;
        }

        .seller-info strong {
            display: block;

            max-width: 180px;

            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;

            color: #cbd5e1;

            font-size: 11px;
        }

        .seller-info span {
            display: block;

            margin-top: 2px;

            color: #475569;

            font-size: 9px;
        }

        .view-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;

            width: 100%;

            margin-top: 16px;
            padding: 11px;

            border-radius: 11px;

            background:
                linear-gradient(
                    135deg,
                    rgba(34, 211, 238, 0.12),
                    rgba(99, 102, 241, 0.14)
                );

            border: 1px solid rgba(34, 211, 238, 0.10);

            color: #cbd5e1;

            font-size: 11px;
            font-weight: 700;

            transition: 0.25s ease;
        }

        .view-btn:hover {
            background:
                linear-gradient(
                    135deg,
                    rgba(34, 211, 238, 0.20),
                    rgba(99, 102, 241, 0.22)
                );

            color: white;

            transform: translateY(-2px);
        }

        /* =====================================================
           EMPTY STATE
        ===================================================== */

        .empty {
            min-height: 470px;

            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;

            text-align: center;

            padding: 50px;

            border-radius: 25px;

            background:
                linear-gradient(
                    145deg,
                    rgba(15, 23, 42, 0.75),
                    rgba(8, 15, 32, 0.75)
                );

            border: 1px solid rgba(148, 163, 184, 0.10);
        }

        .empty-icon {
            width: 90px;
            height: 90px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 28px;

            background:
                linear-gradient(
                    135deg,
                    rgba(34, 211, 238, 0.10),
                    rgba(99, 102, 241, 0.12)
                );

            font-size: 40px;

            margin-bottom: 22px;
        }

        .empty h2 {
            font-size: 22px;
            font-weight: 800;
        }

        .empty p {
            max-width: 460px;

            margin-top: 10px;

            color: #64748b;

            font-size: 13px;
            line-height: 1.7;
        }

        .browse-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;

            margin-top: 24px;
            padding: 13px 21px;

            border-radius: 12px;

            background:
                linear-gradient(
                    135deg,
                    #06b6d4,
                    #6366f1
                );

            color: white;

            font-size: 12px;
            font-weight: 800;

            box-shadow:
                0 12px 30px rgba(99, 102, 241, 0.20);

            transition: 0.25s ease;
        }

        .browse-btn:hover {
            transform: translateY(-3px);

            box-shadow:
                0 17px 35px rgba(99, 102, 241, 0.30);
        }

        /* =====================================================
           MOBILE
        ===================================================== */

        .mobile-header {
            display: none;
        }

        @media (max-width: 1150px) {

            .products-grid {
                grid-template-columns:
                    repeat(2, minmax(0, 1fr));
            }

        }

        @media (max-width: 850px) {

            .sidebar {
                display: none;
            }

            .mobile-header {
                display: flex;

                position: sticky;
                top: 0;

                z-index: 900;

                align-items: center;
                justify-content: space-between;

                padding: 15px 20px;

                background: rgba(2, 6, 23, 0.90);

                backdrop-filter: blur(18px);

                border-bottom:
                    1px solid rgba(148, 163, 184, 0.10);
            }

            .mobile-brand {
                font-weight: 800;
                font-size: 17px;
            }

            .mobile-brand span {
                color: #22d3ee;
            }

            .mobile-dashboard {
                padding: 9px 12px;

                border-radius: 9px;

                background: rgba(255,255,255,0.05);

                color: #cbd5e1;

                font-size: 11px;
                font-weight: 700;
            }

            .main {
                margin-left: 0;
                padding: 28px 20px 50px;
            }

        }

        @media (max-width: 650px) {

            .topbar {
                align-items: flex-start;
            }

            .count-box {
                min-width: 85px;
                padding: 11px;
            }

            .count-box strong {
                font-size: 19px;
            }

            .page-title {
                font-size: 30px;
            }

            .products-grid {
                grid-template-columns: 1fr;
            }

            .image-wrap {
                height: 235px;
            }

        }

    </style>

</head>

<body>

<!-- =========================================================
     MOBILE HEADER
========================================================= -->

<div class="mobile-header">

    <div class="mobile-brand">
        Edu<span>Trade</span>
    </div>

    <a href="dashboard.php" class="mobile-dashboard">
        ← Dashboard
    </a>

</div>


<!-- =========================================================
     SIDEBAR
========================================================= -->

<aside class="sidebar">

    <div class="brand">

        <div class="brand-icon">
            🎓
        </div>

        <div>
            <h2>EduTrade</h2>
            <span>Campus Network</span>
        </div>

    </div>


    <div class="nav-title">
        Main Menu
    </div>

    <a href="dashboard.php" class="nav-item">

        <span class="nav-icon">⌂</span>

        Dashboard

    </a>

    <a href="marketplace.php" class="nav-item">

        <span class="nav-icon">🛍</span>

        Marketplace

    </a>

    <a href="skills.php" class="nav-item">

        <span class="nav-icon">⚡</span>

        Skill Hub

    </a>


    <div class="nav-title">
        My Space
    </div>

    <a href="wishlist.php" class="nav-item active">

        <span class="nav-icon">♡</span>

        Wishlist

    </a>


    <div class="nav-title">
        Account
    </div>

    <a href="../includes/logout.php" class="nav-item">

        <span class="nav-icon">↪</span>

        Logout

    </a>


    <div class="sidebar-bottom">

        <div class="user-mini">

            <div class="avatar">
                <?php echo strtoupper(substr($userName, 0, 1)); ?>
            </div>

            <div>

                <strong>
                    <?php echo clean($userName); ?>
                </strong>

                <small>
                    Student Account
                </small>

            </div>

        </div>

    </div>

</aside>


<!-- =========================================================
     MAIN CONTENT
========================================================= -->

<main class="main">

    <div class="topbar">

        <div>

            <div class="eyebrow">
                My Space
            </div>

            <h1 class="page-title">
                Saved <span>Products</span>
            </h1>

            <p class="subtitle">
                Products you've saved for later.
            </p>

        </div>


        <div class="count-box">

            <strong>
                <?php echo $totalSaved; ?>
            </strong>

            <span>
                Saved
            </span>

        </div>

    </div>


    <?php if (isset($_GET['removed'])): ?>

        <div class="alert">
            ✓ Product removed from your wishlist.
        </div>

    <?php endif; ?>


    <?php if ($totalSaved > 0): ?>

        <div class="products-grid">

            <?php foreach ($savedProducts as $index => $product): ?>

                <?php

                $imagePath = getProductImage($product['image']);

                $categoryData = getCategory(
                    $product['title'],
                    $product['description']
                );

                $categoryName = $categoryData[0];
                $categoryIcon = $categoryData[1];

                $sellerName = trim((string)$product['seller_name']);

                if ($sellerName === '') {
                    $sellerName = 'EduTrade Student';
                }

                $sellerInitial = strtoupper(
                    substr($sellerName, 0, 1)
                );

                ?>

                <article
                    class="product-card"
                    style="animation-delay: <?php echo $index * 0.06; ?>s;"
                >

                    <div class="image-wrap">

                        <?php if ($imagePath !== ''): ?>

                            <img
                                src="<?php echo clean($imagePath); ?>"
                                alt="<?php echo clean($product['title']); ?>"
                                loading="lazy"
                                onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
                            >

                            <div
                                class="image-placeholder"
                                style="display:none;"
                            >
                                <?php echo $categoryIcon; ?>
                            </div>

                        <?php else: ?>

                            <div class="image-placeholder">
                                <?php echo $categoryIcon; ?>
                            </div>

                        <?php endif; ?>


                        <div class="category-badge">

                            <?php echo $categoryIcon; ?>

                            <?php echo clean($categoryName); ?>

                        </div>


                        <a
                            href="wishlist.php?remove=<?php echo (int)$product['id']; ?>"
                            class="remove-btn"
                            title="Remove from Wishlist"
                            onclick="return confirm('Remove this product from your wishlist?');"
                        >
                            ♥
                        </a>

                    </div>


                    <div class="product-content">

                        <h2 class="product-title">
                            <?php echo clean($product['title']); ?>
                        </h2>


                        <p class="description">
                            <?php echo clean($product['description']); ?>
                        </p>


                        <div class="price-row">

                            <div>

                                <div class="price">

                                    ₹<?php
                                    echo number_format(
                                        (float)$product['price'],
                                        2
                                    );
                                    ?>

                                </div>

                                <?php if (
                                    isset($product['negotiable']) &&
                                    (int)$product['negotiable'] === 1
                                ): ?>

                                    <div class="negotiable">
                                        💬 Price Negotiable
                                    </div>

                                <?php endif; ?>

                            </div>


                            <div class="condition">

                                <?php
                                echo clean(
                                    $product['product_condition'] ?: 'Used'
                                );
                                ?>

                            </div>

                        </div>


                        <div class="meta">

                            <?php if (
                                isset($product['product_age']) &&
                                trim((string)$product['product_age']) !== ''
                            ): ?>

                                <div class="meta-item">
                                    ⏱
                                    <?php echo clean($product['product_age']); ?>
                                </div>

                            <?php endif; ?>


                            <?php if (
                                isset($product['quantity']) &&
                                (int)$product['quantity'] > 0
                            ): ?>

                                <div class="meta-item">
                                    📦
                                    <?php echo (int)$product['quantity']; ?>
                                    available
                                </div>

                            <?php endif; ?>


                            <?php if (
                                isset($product['location']) &&
                                trim((string)$product['location']) !== ''
                            ): ?>

                                <div class="meta-item">
                                    📍
                                    <?php echo clean($product['location']); ?>
                                </div>

                            <?php endif; ?>

                        </div>


                        <div class="seller">

                            <div class="seller-avatar">
                                <?php echo clean($sellerInitial); ?>
                            </div>

                            <div class="seller-info">

                                <strong>
                                    <?php echo clean($sellerName); ?>
                                </strong>

                                <span>
                                    Saved product
                                </span>

                            </div>

                        </div>


                        <a
                            href="product_details.php?id=<?php echo (int)$product['id']; ?>"
                            class="view-btn"
                        >
                            View Product
                            <span>→</span>
                        </a>

                    </div>

                </article>

            <?php endforeach; ?>

        </div>

    <?php else: ?>

        <section class="empty">

            <div class="empty-icon">
                ♡
            </div>

            <h2>
                Your wishlist is empty
            </h2>

            <p>
                Found something useful on EduTrade?
                Save it here so you can easily come back to it later.
            </p>

            <a href="marketplace.php" class="browse-btn">
                🛍 Browse Marketplace
                <span>→</span>
            </a>

        </section>

    <?php endif; ?>

</main>


<script>

    /* Prevent accidental double-clicks on remove links */
    document.querySelectorAll('.remove-btn').forEach(function(button) {

        button.addEventListener('click', function() {

            button.style.pointerEvents = 'none';
            button.style.opacity = '0.5';

        });

    });

</script>

</body>
</html>