<?php

session_start();

require_once "../config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../includes/login.php");
    exit;
}

$user_id = (int)$_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT
        p.*,
        u.name AS seller_name
    FROM saved_products sp
    INNER JOIN products p
        ON sp.product_id = p.id
    LEFT JOIN users u
        ON p.user_id = u.id
    WHERE sp.user_id = ?
    ORDER BY sp.created_at DESC
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();

$products = [];

while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}

$stmt->close();

function productImage($filename)
{
    if (empty($filename)) {
        return '';
    }

    $filename = basename($filename);

    $path = "../uploads/products/" . $filename;

    $physicalPath = dirname(__DIR__) .
        "/uploads/products/" . $filename;

    if (file_exists($physicalPath)) {
        return $path;
    }

    return '';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Saved Products | EduTrade</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background:
        radial-gradient(circle at top left, #172554, transparent 35%),
        radial-gradient(circle at bottom right, #312e81, transparent 35%),
        #050816;
    color: #fff;
    min-height: 100vh;
}

.navbar {
    height: 75px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 6%;
    border-bottom: 1px solid rgba(255,255,255,.08);
    background: rgba(5,8,22,.72);
    backdrop-filter: blur(18px);
    position: sticky;
    top: 0;
    z-index: 100;
}

.logo {
    font-size: 25px;
    font-weight: 800;
    text-decoration: none;
    color: white;
}

.logo span {
    color: #22c55e;
}

.nav-links {
    display: flex;
    gap: 24px;
}

.nav-links a {
    color: #cbd5e1;
    text-decoration: none;
    font-size: 14px;
}

.nav-links a:hover {
    color: #22c55e;
}

.container {
    width: min(1200px, 92%);
    margin: auto;
    padding: 55px 0;
}

.hero h1 {
    font-size: 42px;
    margin-bottom: 10px;
}

.hero p {
    color: #94a3b8;
    margin-bottom: 40px;
}

.grid {
    display: grid;
    grid-template-columns:
        repeat(3, 1fr);
    gap: 24px;
}

.card {
    background: rgba(15,23,42,.72);
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 22px;
    overflow: hidden;
    transition: .3s;
}

.card:hover {
    transform: translateY(-7px);
    border-color: rgba(34,197,94,.4);
}

.image-box {
    height: 220px;
    background: #0f172a;
    overflow: hidden;
}

.image-box img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.no-image {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #64748b;
    font-size: 45px;
}

.content {
    padding: 22px;
}

.condition {
    display: inline-block;
    padding: 6px 10px;
    border-radius: 30px;
    background: rgba(34,197,94,.12);
    color: #4ade80;
    font-size: 12px;
    margin-bottom: 12px;
}

.title {
    font-size: 20px;
    font-weight: 700;
    margin-bottom: 9px;
}

.description {
    color: #94a3b8;
    line-height: 1.6;
    font-size: 14px;
    min-height: 45px;
}

.price {
    color: #4ade80;
    font-size: 23px;
    font-weight: 800;
    margin: 18px 0;
}

.seller {
    color: #94a3b8;
    font-size: 13px;
    margin-bottom: 18px;
}

.actions {
    display: flex;
    gap: 10px;
}

.btn {
    flex: 1;
    padding: 12px;
    border-radius: 12px;
    text-align: center;
    text-decoration: none;
    font-weight: 700;
    border: none;
    cursor: pointer;
}

.view {
    background: #22c55e;
    color: #04110a;
}

.remove {
    background: rgba(239,68,68,.12);
    color: #f87171;
}

.empty {
    text-align: center;
    padding: 90px 20px;
    color: #94a3b8;
}

.empty-icon {
    font-size: 65px;
    margin-bottom: 20px;
}

.empty h2 {
    color: white;
    margin-bottom: 10px;
}

.empty a {
    display: inline-block;
    margin-top: 25px;
    background: #22c55e;
    color: #04110a;
    padding: 13px 22px;
    border-radius: 12px;
    text-decoration: none;
    font-weight: 700;
}

@media(max-width: 950px) {
    .grid {
        grid-template-columns: repeat(2,1fr);
    }
}

@media(max-width: 650px) {

    .nav-links {
        display: none;
    }

    .grid {
        grid-template-columns: 1fr;
    }

    .hero h1 {
        font-size: 32px;
    }
}

</style>

</head>

<body>

<nav class="navbar">

    <a href="dashboard.php" class="logo">
        Edu<span>Trade</span>
    </a>

    <div class="nav-links">
        <a href="dashboard.php">Dashboard</a>
        <a href="marketplace.php">Marketplace</a>
        <a href="skills.php">Skill Hub</a>
        <a href="saved_skills.php">Saved Skills</a>
        <a href="hire_requests.php">Hire Requests</a>
    </div>

</nav>

<main class="container">

    <div class="hero">

        <h1>🔖 Saved Products</h1>

        <p>
            Products you've saved for later.
        </p>

    </div>

    <?php if (count($products) > 0): ?>

        <div class="grid">

        <?php foreach ($products as $product): ?>

            <?php
                $img = productImage($product['image'] ?? '');
            ?>

            <article class="card">

                <div class="image-box">

                    <?php if ($img): ?>

                        <img
                            src="<?php echo htmlspecialchars($img); ?>"
                            alt="<?php echo htmlspecialchars($product['title']); ?>"
                        >

                    <?php else: ?>

                        <div class="no-image">📦</div>

                    <?php endif; ?>

                </div>

                <div class="content">

                    <span class="condition">
                        <?php
                        echo htmlspecialchars(
                            $product['product_condition'] ?? 'Campus Item'
                        );
                        ?>
                    </span>

                    <h2 class="title">
                        <?php
                        echo htmlspecialchars($product['title']);
                        ?>
                    </h2>

                    <p class="description">
                        <?php
                        echo htmlspecialchars(
                            mb_strimwidth(
                                $product['description'] ?? '',
                                0,
                                100,
                                '...'
                            )
                        );
                        ?>
                    </p>

                    <div class="price">
                        ₹<?php
                        echo number_format(
                            (float)($product['price'] ?? 0),
                            2
                        );
                        ?>
                    </div>

                    <div class="seller">
                        👤 <?php
                        echo htmlspecialchars(
                            $product['seller_name'] ?? 'Student'
                        );
                        ?>
                    </div>

                    <div class="actions">

                        <a
                            class="btn view"
                            href="product_details.php?id=<?php echo (int)$product['id']; ?>"
                        >
                            View Product
                        </a>

                        <button
                            class="btn remove"
                            onclick="removeProduct(<?php echo (int)$product['id']; ?>, this)"
                        >
                            Remove
                        </button>

                    </div>

                </div>

            </article>

        <?php endforeach; ?>

        </div>

    <?php else: ?>

        <div class="empty">

            <div class="empty-icon">🔖</div>

            <h2>No Saved Products Yet</h2>

            <p>
                Save interesting campus products and find them here later.
            </p>

            <a href="marketplace.php">
                Browse Marketplace
            </a>

        </div>

    <?php endif; ?>

</main>

<script>

async function removeProduct(productId, button) {

    button.disabled = true;
    button.innerText = "Removing...";

    try {

        const formData = new FormData();

        formData.append("product_id", productId);
        formData.append("action", "remove");

        const response = await fetch(
            "../api/save_products.php",
            {
                method: "POST",
                body: formData
            }
        );

        const data = await response.json();

        if (data.success) {
            location.reload();
        } else {
            alert(data.message || "Unable to remove product.");
            button.disabled = false;
            button.innerText = "Remove";
        }

    } catch (error) {

        alert("Something went wrong.");

        button.disabled = false;
        button.innerText = "Remove";
    }
}

</script>

</body>
</html>