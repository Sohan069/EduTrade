<?php
session_start();

require_once "../config/db.php";

/* =========================================================
   EDU TRADE PRO
   ADD PRODUCT
   ========================================================= */

/* ---------------------------------------------------------
   LOGIN CHECK
--------------------------------------------------------- */

if (!isset($_SESSION['user_id'])) {
    header("Location: ../includes/login.php");
    exit();
}


/* ---------------------------------------------------------
   USER INFORMATION
--------------------------------------------------------- */

$userId = (int) $_SESSION['user_id'];

$userName = $_SESSION['name'] ?? 'Student';

$userEmail = $_SESSION['email'] ?? '';


/* =========================================================
   UPLOAD DIRECTORY
========================================================= */

$uploadDir = "../uploads/products/";

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}


/* =========================================================
   FORM VARIABLES
========================================================= */

$title = '';
$category = '';
$description = '';
$price = '';
$condition = 'Used';
$productAge = '';
$quantity = '1';
$location = '';

$negotiable = 0;

$contactMethod = '';
$contactValue = '';
$additionalContact = '';

$error = '';

$imageName = '';


/* =========================================================
   DATABASE COMPATIBILITY
========================================================= */

$requiredColumns = [

    "product_condition" => "
        ALTER TABLE products
        ADD COLUMN product_condition VARCHAR(50) DEFAULT 'Used'
    ",

    "product_age" => "
        ALTER TABLE products
        ADD COLUMN product_age VARCHAR(100) DEFAULT NULL
    ",

    "image" => "
        ALTER TABLE products
        ADD COLUMN image VARCHAR(255) DEFAULT NULL
    ",

    "quantity" => "
        ALTER TABLE products
        ADD COLUMN quantity INT DEFAULT 1
    ",

    "negotiable" => "
        ALTER TABLE products
        ADD COLUMN negotiable TINYINT(1) DEFAULT 0
    ",

    "location" => "
        ALTER TABLE products
        ADD COLUMN location VARCHAR(150) DEFAULT NULL
    ",

    "contact_method" => "
        ALTER TABLE products
        ADD COLUMN contact_method VARCHAR(50) DEFAULT NULL
    ",

    "contact_value" => "
        ALTER TABLE products
        ADD COLUMN contact_value VARCHAR(255) DEFAULT NULL
    ",

    "additional_contact" => "
        ALTER TABLE products
        ADD COLUMN additional_contact VARCHAR(255) DEFAULT NULL
    "

];


/* ---------------------------------------------------------
   CREATE MISSING COLUMNS
--------------------------------------------------------- */

foreach ($requiredColumns as $column => $alterQuery) {

    $safeColumn = mysqli_real_escape_string(
        $conn,
        $column
    );

    $check = mysqli_query(
        $conn,
        "SHOW COLUMNS FROM products LIKE '$safeColumn'"
    );

    if ($check && mysqli_num_rows($check) === 0) {
        @mysqli_query($conn, $alterQuery);
    }
}


/* =========================================================
   FORM SUBMISSION
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    /* -----------------------------------------------------
       GET FORM VALUES
    ----------------------------------------------------- */

    $title = trim($_POST['title'] ?? '');

    $category = trim($_POST['category'] ?? '');

    $description = trim($_POST['description'] ?? '');

    $price = trim($_POST['price'] ?? '');

    $condition = trim(
        $_POST['product_condition'] ?? 'Used'
    );

    $productAge = trim(
        $_POST['product_age'] ?? ''
    );

    $quantity = trim(
        $_POST['quantity'] ?? '1'
    );

    $location = trim(
        $_POST['location'] ?? ''
    );

    $negotiable = isset(
        $_POST['negotiable']
    ) ? 1 : 0;

    $contactMethod = trim(
        $_POST['contact_method'] ?? ''
    );

    $contactValue = trim(
        $_POST['contact_value'] ?? ''
    );

    $additionalContact = trim(
        $_POST['additional_contact'] ?? ''
    );


    /* =====================================================
       BASIC VALIDATION
    ===================================================== */

    if ($title === '') {

        $error = "Please enter the product name.";

    } elseif (strlen($title) < 3) {

        $error =
            "Product name must contain at least 3 characters.";

    } elseif ($category === '') {

        $error =
            "Please select a product category.";

    } elseif ($description === '') {

        $error =
            "Please enter a product description.";

    } elseif (strlen($description) < 10) {

        $error =
            "Please provide more details about the product.";

    } elseif ($price === '' || !is_numeric($price)) {

        $error =
            "Please enter a valid price.";

    } elseif ((float)$price < 0) {

        $error =
            "Price cannot be negative.";

    } elseif ($condition === '') {

        $error =
            "Please select the product condition.";

    } elseif (
        $quantity === '' ||
        !is_numeric($quantity) ||
        (int)$quantity < 1
    ) {

        $error =
            "Please enter a valid quantity.";

    } elseif ($contactMethod === '') {

        $error =
            "Please select a contact method.";

    } elseif ($contactValue === '') {

        $error =
            "Please provide contact information.";

    }


    /* =====================================================
       CONTACT VALIDATION
    ===================================================== */

    if ($error === '') {

        if (
            $contactMethod === 'phone' ||
            $contactMethod === 'whatsapp' ||
            $contactMethod === 'phone_whatsapp'
        ) {

            $cleanNumber = preg_replace(
                '/[^0-9]/',
                '',
                $contactValue
            );

            if (strlen($cleanNumber) < 10) {

                $error =
                    "Please enter a valid phone number.";

            }

        } elseif ($contactMethod === 'email') {

            if (
                !filter_var(
                    $contactValue,
                    FILTER_VALIDATE_EMAIL
                )
            ) {

                $error =
                    "Please enter a valid email address.";

            }

        } elseif ($contactMethod === 'email_phone') {

            if (
                !filter_var(
                    $contactValue,
                    FILTER_VALIDATE_EMAIL
                )
            ) {

                $error =
                    "Please enter a valid email address.";

            }

            if ($additionalContact === '') {

                $error =
                    "Please enter your phone number too.";

            } else {

                $cleanNumber = preg_replace(
                    '/[^0-9]/',
                    '',
                    $additionalContact
                );

                if (strlen($cleanNumber) < 10) {

                    $error =
                        "Please enter a valid phone number.";

                }

            }

        }

    }


    /* =====================================================
       IMAGE UPLOAD
    ===================================================== */

    if (
        $error === '' &&
        isset($_FILES['product_image'])
    ) {

        $file = $_FILES['product_image'];


        /* -------------------------------------------------
           USER DID NOT SELECT IMAGE
        ------------------------------------------------- */

        if ($file['error'] === UPLOAD_ERR_NO_FILE) {

            $imageName = '';

        } elseif ($file['error'] !== UPLOAD_ERR_OK) {

            $error =
                "There was a problem uploading the image.";

        } else {


            /* ---------------------------------------------
               FILE SIZE
            --------------------------------------------- */

            $maxSize = 5 * 1024 * 1024;

            if ($file['size'] > $maxSize) {

                $error =
                    "Image must be smaller than 5 MB.";

            }


            /* ---------------------------------------------
               MIME TYPE
            --------------------------------------------- */

            if ($error === '') {

                $allowedTypes = [

                    'image/jpeg',
                    'image/png',
                    'image/webp'

                ];

                $fileType = mime_content_type(
                    $file['tmp_name']
                );

                if (
                    !in_array(
                        $fileType,
                        $allowedTypes,
                        true
                    )
                ) {

                    $error =
                        "Only JPG, PNG and WEBP images are allowed.";

                }

            }


            /* ---------------------------------------------
               FILE EXTENSION
            --------------------------------------------- */

            if ($error === '') {

                $extension = '';

                if ($fileType === 'image/jpeg') {
                    $extension = 'jpg';
                } elseif ($fileType === 'image/png') {
                    $extension = 'png';
                } elseif ($fileType === 'image/webp') {
                    $extension = 'webp';
                }


                /* -----------------------------------------
                   SAFE UNIQUE NAME
                ----------------------------------------- */

                $imageName =
                    'product_' .
                    $userId .
                    '_' .
                    date('Ymd_His') .
                    '_' .
                    bin2hex(
                        random_bytes(5)
                    ) .
                    '.' .
                    $extension;


                $destination =
                    $uploadDir . $imageName;


                /* -----------------------------------------
                   MOVE IMAGE
                ----------------------------------------- */

                if (
                    !move_uploaded_file(
                        $file['tmp_name'],
                        $destination
                    )
                ) {

                    $error =
                        "Unable to save the uploaded image.";

                    $imageName = '';

                }

            }

        }

    }


    /* =====================================================
       INSERT PRODUCT
    ===================================================== */

    if ($error === '') {


        $priceValue =
            (float)$price;

        $quantityValue =
            (int)$quantity;


        /* -------------------------------------------------
           CATEGORY IS STORED INSIDE DESCRIPTION
           TO KEEP EXISTING DATABASE COMPATIBILITY
        ------------------------------------------------- */

        $finalDescription =
            "Category: " .
            $category .
            "\n\n" .
            $description;


        /* =================================================
           IMPORTANT

           EXACTLY 13 COLUMNS
           EXACTLY 13 VALUES
           EXACTLY 13 bind parameters
        ================================================= */

        $sql = "

            INSERT INTO products
            (
                user_id,
                title,
                description,
                price,
                product_condition,
                product_age,
                image,
                quantity,
                negotiable,
                location,
                contact_method,
                contact_value,
                additional_contact
            )

            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?
            )

        ";


        $stmt = mysqli_prepare(
            $conn,
            $sql
        );


        if (!$stmt) {

            $error =
                "Database error: " .
                mysqli_error($conn);


            /* ---------------------------------------------
               DELETE IMAGE IF PREPARE FAILED
            --------------------------------------------- */

            if (
                $imageName !== '' &&
                file_exists(
                    $uploadDir . $imageName
                )
            ) {

                unlink(
                    $uploadDir . $imageName
                );

            }

        } else {


            /* =================================================
               13 VARIABLES

               1  userId
               2  title
               3  finalDescription
               4  priceValue
               5  condition
               6  productAge
               7  imageName
               8  quantityValue
               9  negotiable
               10 location
               11 contactMethod
               12 contactValue
               13 additionalContact
            ================================================= */

            mysqli_stmt_bind_param(
                $stmt,
                "issdsssiiisss",
                $userId,
                $title,
                $finalDescription,
                $priceValue,
                $condition,
                $productAge,
                $imageName,
                $quantityValue,
                $negotiable,
                $location,
                $contactMethod,
                $contactValue,
                $additionalContact
            );


            /* =================================================
               EXECUTE
            ================================================= */

            if (
                mysqli_stmt_execute($stmt)
            ) {

                mysqli_stmt_close(
                    $stmt
                );


                /* ---------------------------------------------
                   SUCCESS REDIRECT

                   add_product.php
                   ↓
                   marketplace.php

                   Both are inside /pages/
                --------------------------------------------- */

                header(
                    "Location: marketplace.php?added=success"
                );

                exit();

            } else {

                $error =
                    "Unable to add product: " .
                    mysqli_stmt_error($stmt);


                mysqli_stmt_close(
                    $stmt
                );


                /* ---------------------------------------------
                   DELETE IMAGE IF DATABASE INSERT FAILED
                --------------------------------------------- */

                if (
                    $imageName !== '' &&
                    file_exists(
                        $uploadDir . $imageName
                    )
                ) {

                    unlink(
                        $uploadDir . $imageName
                    );

                }

            }

        }

    }

}


/* =========================================================
   AVATAR
========================================================= */

$avatarLetter =
    strtoupper(
        substr(
            trim($userName),
            0,
            1
        )
    );

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Add Product | EduTrade PRO</title>


<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap"
    rel="stylesheet"
>


<style>

/* =========================================================
   RESET
========================================================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

html{
    scroll-behavior:smooth;
}

body{

    font-family:'Poppins',sans-serif;

    min-height:100vh;

    color:#f8fafc;

    background:
        radial-gradient(
            circle at 10% 10%,
            rgba(0,245,255,.12),
            transparent 25%
        ),
        radial-gradient(
            circle at 90% 20%,
            rgba(139,92,246,.15),
            transparent 28%
        ),
        radial-gradient(
            circle at 50% 100%,
            rgba(236,72,153,.08),
            transparent 30%
        ),
        #020617;

    overflow-x:hidden;
}


/* =========================================================
   BACKGROUND ORBS
========================================================= */

.orb{

    position:fixed;

    border-radius:50%;

    filter:blur(90px);

    opacity:.22;

    pointer-events:none;

    z-index:-1;

    animation:floatOrb 9s ease-in-out infinite;
}

.orb.one{

    width:260px;
    height:260px;

    background:#00e5ff;

    top:5%;
    left:-120px;
}

.orb.two{

    width:300px;
    height:300px;

    background:#8b5cf6;

    right:-140px;
    top:45%;

    animation-delay:2s;
}

.orb.three{

    width:240px;
    height:240px;

    background:#ec4899;

    bottom:-120px;
    left:45%;

    animation-delay:4s;
}

@keyframes floatOrb{

    0%,100%{
        transform:translateY(0) scale(1);
    }

    50%{
        transform:translateY(-30px) scale(1.08);
    }

}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar{

    position:fixed;

    left:0;
    top:0;

    width:260px;
    height:100vh;

    padding:25px 18px;

    background:rgba(2,6,23,.78);

    border-right:1px solid rgba(255,255,255,.08);

    backdrop-filter:blur(25px);

    z-index:1000;

    transition:.3s;
}

.logo{

    text-align:center;

    font-size:25px;

    font-weight:800;

    margin-bottom:40px;

    letter-spacing:.5px;

    background:
        linear-gradient(
            90deg,
            #00f5ff,
            #8b5cf6,
            #ec4899
        );

    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.logo span{

    display:block;

    font-size:10px;

    margin-top:3px;

    letter-spacing:3px;

    color:#64748b;

    -webkit-text-fill-color:#64748b;
}

.nav{

    display:flex;

    flex-direction:column;

    gap:8px;
}

.nav a{

    text-decoration:none;

    color:#94a3b8;

    padding:14px 16px;

    border-radius:14px;

    display:flex;

    align-items:center;

    gap:13px;

    font-size:14px;

    transition:.3s;

    border:1px solid transparent;
}

.nav a:hover{

    color:white;

    background:
        linear-gradient(
            90deg,
            rgba(0,245,255,.12),
            rgba(139,92,246,.12)
        );

    border-color:rgba(0,245,255,.15);

    transform:translateX(5px);
}

.nav a.active{

    color:white;

    background:
        linear-gradient(
            135deg,
            rgba(0,245,255,.18),
            rgba(139,92,246,.22)
        );

    border-color:rgba(0,245,255,.25);

    box-shadow:
        0 8px 30px rgba(0,245,255,.08);
}

.nav-icon{

    width:28px;
    height:28px;

    display:flex;

    align-items:center;
    justify-content:center;

    border-radius:8px;

    background:rgba(255,255,255,.06);
}


/* =========================================================
   MAIN
========================================================= */

.main{

    margin-left:260px;

    padding:30px 40px 70px;

    max-width:1550px;
}


/* =========================================================
   TOPBAR
========================================================= */

.topbar{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-bottom:28px;
}

.topbar-left h1{

    font-size:30px;

    font-weight:700;
}

.topbar-left p{

    margin-top:5px;

    color:#64748b;

    font-size:13px;
}

.profile{

    display:flex;

    align-items:center;

    gap:12px;

    padding:9px 14px;

    border-radius:14px;

    background:rgba(255,255,255,.05);

    border:1px solid rgba(255,255,255,.08);
}

.avatar{

    width:38px;
    height:38px;

    display:flex;

    align-items:center;
    justify-content:center;

    border-radius:12px;

    font-weight:700;

    background:
        linear-gradient(
            135deg,
            #00f5ff,
            #8b5cf6
        );
}

.profile small{
    color:#64748b;
}


/* =========================================================
   GRID
========================================================= */

.page-grid{

    display:grid;

    grid-template-columns:minmax(0,1fr) 330px;

    gap:25px;

    align-items:start;
}


/* =========================================================
   FORM CARD
========================================================= */

.form-card{

    border-radius:26px;

    padding:30px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.065),
            rgba(255,255,255,.025)
        );

    border:1px solid rgba(255,255,255,.08);

    backdrop-filter:blur(25px);

    box-shadow:
        0 25px 70px rgba(0,0,0,.25);
}

.form-header{

    display:flex;

    align-items:flex-start;

    gap:15px;

    margin-bottom:30px;
}

.header-icon{

    width:52px;
    height:52px;

    flex-shrink:0;

    display:flex;

    align-items:center;
    justify-content:center;

    border-radius:16px;

    font-size:25px;

    background:
        linear-gradient(
            135deg,
            rgba(0,245,255,.14),
            rgba(139,92,246,.18)
        );

    border:1px solid rgba(0,245,255,.15);
}

.form-header h2{

    font-size:22px;

    margin-bottom:5px;
}

.form-header p{

    color:#64748b;

    font-size:12px;

    line-height:1.6;
}


/* =========================================================
   ALERT
========================================================= */

.alert{

    padding:15px 17px;

    border-radius:14px;

    margin-bottom:22px;

    font-size:12px;

    line-height:1.6;
}

.alert.error{

    color:#fecaca;

    background:rgba(239,68,68,.09);

    border:1px solid rgba(239,68,68,.2);
}


/* =========================================================
   FORM SECTION
========================================================= */

.form-section{

    padding:23px 0;

    border-top:1px solid rgba(255,255,255,.06);
}

.form-section:first-of-type{

    border-top:0;

    padding-top:0;
}

.section-title{

    display:flex;

    align-items:center;

    gap:10px;

    margin-bottom:18px;
}

.section-number{

    width:30px;
    height:30px;

    border-radius:9px;

    display:flex;

    align-items:center;
    justify-content:center;

    font-size:11px;

    font-weight:700;

    background:
        linear-gradient(
            135deg,
            #00cfe8,
            #7c3aed
        );
}

.section-title h3{

    font-size:15px;
}

.section-title span{

    color:#64748b;

    font-size:10px;

    margin-left:auto;
}


/* =========================================================
   FORM GRID
========================================================= */

.form-grid{

    display:grid;

    grid-template-columns:1fr 1fr;

    gap:17px;
}

.form-group{

    display:flex;

    flex-direction:column;
}

.form-group.full{

    grid-column:1/-1;
}

label{

    font-size:11px;

    font-weight:600;

    color:#cbd5e1;

    margin-bottom:8px;
}

.required{

    color:#22d3ee;

    margin-left:2px;
}

.optional{

    color:#64748b;

    font-size:9px;

    font-weight:400;

    margin-left:5px;
}

input,
select,
textarea{

    width:100%;

    padding:13px 14px;

    border-radius:12px;

    border:1px solid rgba(255,255,255,.09);

    background:rgba(2,6,23,.65);

    color:white;

    outline:none;

    font-family:inherit;

    font-size:12px;

    transition:.25s;
}

input:focus,
select:focus,
textarea:focus{

    border-color:#00e5ff;

    box-shadow:
        0 0 0 3px rgba(0,229,255,.06);
}

input::placeholder,
textarea::placeholder{

    color:#475569;
}

select option{

    background:#0f172a;

    color:white;
}

textarea{

    min-height:130px;

    resize:vertical;

    line-height:1.7;
}

.field-help{

    color:#475569;

    font-size:9px;

    margin-top:6px;

    line-height:1.5;
}


/* =========================================================
   PRICE
========================================================= */

.price-wrap{

    position:relative;
}

.price-symbol{

    position:absolute;

    left:14px;
    top:50%;

    transform:translateY(-50%);

    color:#67e8f9;

    font-weight:700;
}

.price-input{

    padding-left:32px;
}


/* =========================================================
   CHECKBOX
========================================================= */

.check-row{

    display:flex;

    align-items:center;

    gap:10px;

    padding:13px 14px;

    border-radius:12px;

    background:rgba(255,255,255,.025);

    border:1px solid rgba(255,255,255,.07);

    cursor:pointer;

    transition:.25s;
}

.check-row:hover{

    border-color:rgba(0,245,255,.2);

    background:rgba(0,245,255,.035);
}

.check-row input{

    width:17px;
    height:17px;

    accent-color:#8b5cf6;

    cursor:pointer;
}

.check-row span{

    font-size:11px;

    color:#cbd5e1;
}


/* =========================================================
   CONTACT OPTIONS
========================================================= */

.contact-options{

    display:grid;

    grid-template-columns:repeat(2,1fr);

    gap:10px;

    margin-bottom:17px;
}

.contact-option{

    position:relative;
}

.contact-option input{

    position:absolute;

    opacity:0;

    pointer-events:none;
}

.contact-label{

    display:flex;

    align-items:center;

    gap:10px;

    padding:13px;

    border-radius:13px;

    cursor:pointer;

    border:1px solid rgba(255,255,255,.08);

    background:rgba(255,255,255,.025);

    transition:.25s;
}

.contact-label:hover{

    border-color:rgba(0,245,255,.25);

    transform:translateY(-2px);
}

.contact-option input:checked + .contact-label{

    border-color:#00e5ff;

    background:
        linear-gradient(
            135deg,
            rgba(0,245,255,.09),
            rgba(139,92,246,.09)
        );

    box-shadow:
        0 10px 30px rgba(0,229,255,.05);
}

.contact-icon{

    width:34px;
    height:34px;

    display:flex;

    align-items:center;
    justify-content:center;

    border-radius:10px;

    background:rgba(255,255,255,.06);

    font-size:16px;
}

.contact-label strong{

    display:block;

    font-size:11px;
}

.contact-label small{

    display:block;

    margin-top:2px;

    color:#64748b;

    font-size:9px;
}


/* =========================================================
   CONTACT INPUT
========================================================= */

.contact-input-box{

    display:none;

    animation:slideDown .3s ease;
}

.contact-input-box.show{

    display:block;
}

@keyframes slideDown{

    from{
        opacity:0;
        transform:translateY(-8px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}


/* =========================================================
   IMAGE UPLOAD
========================================================= */

.upload-box{

    position:relative;

    min-height:250px;

    display:flex;

    align-items:center;
    justify-content:center;

    text-align:center;

    border-radius:18px;

    border:1px dashed rgba(0,245,255,.25);

    background:
        radial-gradient(
            circle at center,
            rgba(0,245,255,.06),
            transparent 65%
        );

    overflow:hidden;

    cursor:pointer;

    transition:.3s;
}

.upload-box:hover{

    border-color:#00e5ff;

    background:
        radial-gradient(
            circle at center,
            rgba(0,245,255,.09),
            transparent 65%
        );
}

.upload-box.dragging{

    border-color:#00e5ff;

    transform:scale(1.01);

    box-shadow:
        0 0 40px rgba(0,229,255,.08);
}

.upload-box input{

    position:absolute;

    inset:0;

    opacity:0;

    cursor:pointer;
}

.upload-content{

    pointer-events:none;
}

.upload-icon{

    font-size:42px;

    margin-bottom:10px;
}

.upload-content h4{

    font-size:13px;

    margin-bottom:5px;
}

.upload-content p{

    color:#64748b;

    font-size:10px;
}

.upload-content strong{

    color:#67e8f9;
}


/* =========================================================
   IMAGE PREVIEW
========================================================= */

.image-preview{

    display:none;

    position:absolute;

    inset:0;

    background:#020617;
}

.image-preview img{

    width:100%;
    height:100%;

    object-fit:cover;
}

.remove-image{

    position:absolute;

    right:12px;
    top:12px;

    width:35px;
    height:35px;

    border-radius:50%;

    border:1px solid rgba(255,255,255,.15);

    background:rgba(2,6,23,.8);

    color:white;

    cursor:pointer;

    font-size:15px;

    z-index:5;
}

.remove-image:hover{

    background:#ef4444;

    border-color:#ef4444;
}


/* =========================================================
   BUTTONS
========================================================= */

.form-actions{

    display:flex;

    gap:12px;

    margin-top:25px;

    padding-top:22px;

    border-top:1px solid rgba(255,255,255,.06);
}

.btn{

    flex:1;

    text-align:center;

    text-decoration:none;

    padding:14px 18px;

    border-radius:13px;

    font-family:inherit;

    font-size:12px;

    font-weight:600;

    cursor:pointer;

    transition:.3s;

    border:1px solid rgba(255,255,255,.08);
}

.btn-cancel{

    color:#94a3b8;

    background:rgba(255,255,255,.035);
}

.btn-cancel:hover{

    color:white;

    background:rgba(255,255,255,.07);
}

.btn-submit{

    color:white;

    border:0;

    background:
        linear-gradient(
            135deg,
            #00cfe8,
            #7c3aed,
            #ec4899
        );

    box-shadow:
        0 10px 30px rgba(124,58,237,.15);
}

.btn-submit:hover{

    transform:translateY(-3px);

    box-shadow:
        0 15px 40px rgba(124,58,237,.3);
}

.btn-submit:disabled{

    opacity:.65;

    cursor:not-allowed;

    transform:none;
}


/* =========================================================
   INFO CARD
========================================================= */

.info-card{

    position:sticky;

    top:25px;

    padding:24px;

    border-radius:23px;

    background:
        linear-gradient(
            145deg,
            rgba(0,245,255,.07),
            rgba(139,92,246,.08)
        );

    border:1px solid rgba(255,255,255,.08);

    backdrop-filter:blur(25px);
}

.info-card h3{

    font-size:17px;

    margin-bottom:7px;
}

.info-card > p{

    color:#64748b;

    font-size:10px;

    line-height:1.7;

    margin-bottom:22px;
}

.tip{

    display:flex;

    gap:12px;

    padding:13px 0;

    border-top:1px solid rgba(255,255,255,.06);
}

.tip-icon{

    width:32px;
    height:32px;

    flex-shrink:0;

    display:flex;

    align-items:center;
    justify-content:center;

    border-radius:9px;

    background:rgba(255,255,255,.05);
}

.tip h4{

    font-size:11px;

    margin-bottom:3px;
}

.tip p{

    color:#64748b;

    font-size:9px;

    line-height:1.5;
}

.privacy-box{

    margin-top:20px;

    padding:13px;

    border-radius:13px;

    background:rgba(34,197,94,.05);

    border:1px solid rgba(34,197,94,.12);
}

.privacy-box strong{

    display:block;

    color:#86efac;

    font-size:10px;

    margin-bottom:4px;
}

.privacy-box span{

    color:#64748b;

    font-size:9px;

    line-height:1.5;
}


/* =========================================================
   FOOTER
========================================================= */

footer{

    text-align:center;

    margin-top:55px;

    color:#475569;

    font-size:10px;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:1100px){

    .page-grid{

        grid-template-columns:1fr;
    }

    .info-card{

        position:relative;

        top:auto;
    }

}

@media(max-width:850px){

    .sidebar{

        width:80px;

        padding:20px 10px;
    }

    .logo{

        font-size:0;
    }

    .logo::before{

        content:"E";

        font-size:25px;
    }

    .logo span{

        display:none;
    }

    .nav a{

        justify-content:center;

        padding:13px;
    }

    .nav a span:not(.nav-icon){

        display:none;
    }

    .main{

        margin-left:80px;

        padding:25px;
    }

}

@media(max-width:650px){

    .main{

        padding:18px;
    }

    .topbar{

        flex-direction:column;

        align-items:flex-start;

        gap:15px;
    }

    .form-card{

        padding:21px;
    }

    .form-grid{

        grid-template-columns:1fr;
    }

    .form-group.full{

        grid-column:auto;
    }

    .contact-options{

        grid-template-columns:1fr;
    }

    .form-actions{

        flex-direction:column;
    }

}

</style>

</head>


<body>


<!-- =========================================================
     BACKGROUND
========================================================= -->

<div class="orb one"></div>

<div class="orb two"></div>

<div class="orb three"></div>


<!-- =========================================================
     SIDEBAR
========================================================= -->

<aside class="sidebar">

    <div class="logo">

        EduTrade PRO

        <span>CAMPUS MARKET</span>

    </div>


    <nav class="nav">

        <a href="dashboard.php">

            <span class="nav-icon">🏠</span>

            <span>Dashboard</span>

        </a>


        <a href="marketplace.php">

            <span class="nav-icon">🛒</span>

            <span>Marketplace</span>

        </a>


        <a href="skills.php">

            <span class="nav-icon">🎯</span>

            <span>Skill Hub</span>

        </a>


        <a
            href="add_product.php"
            class="active"
        >

            <span class="nav-icon">➕</span>

            <span>Add Product</span>

        </a>


        <a href="add_skills.php">

            <span class="nav-icon">✨</span>

            <span>Add Skill</span>

        </a>


        <a href="wishlist.php">

            <span class="nav-icon">❤️</span>

            <span>Wishlist</span>

        </a>


        <a href="../includes/auth.php?logout=true">

            <span class="nav-icon">🚪</span>

            <span>Logout</span>

        </a>

    </nav>

</aside>


<!-- =========================================================
     MAIN
========================================================= -->

<main class="main">


    <!-- TOPBAR -->

    <div class="topbar">

        <div class="topbar-left">

            <h1>
                Sell Something 🚀
            </h1>

            <p>
                Turn your unused campus items into value.
            </p>

        </div>


        <div class="profile">

            <div class="avatar">

                <?php
                echo htmlspecialchars(
                    $avatarLetter
                );
                ?>

            </div>

            <div>

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $userName
                    );
                    ?>
                </strong>

                <br>

                <small>
                    Student Seller
                </small>

            </div>

        </div>

    </div>


    <!-- PAGE GRID -->

    <div class="page-grid">


        <!-- =================================================
             FORM CARD
        ================================================= -->

        <div class="form-card">


            <div class="form-header">

                <div class="header-icon">
                    🛍️
                </div>

                <div>

                    <h2>
                        Create Product Listing
                    </h2>

                    <p>
                        Add your campus product and let
                        other students discover it.
                    </p>

                </div>

            </div>


            <!-- ERROR -->

            <?php if ($error !== ''): ?>

                <div class="alert error">

                    ⚠️

                    <?php
                    echo htmlspecialchars(
                        $error
                    );
                    ?>

                </div>

            <?php endif; ?>


            <!-- =================================================
                 PRODUCT FORM
            ================================================= -->

            <form
                method="POST"
                enctype="multipart/form-data"
                id="productForm"
            >


                <!-- =================================================
                     SECTION 01
                ================================================= -->

                <section class="form-section">

                    <div class="section-title">

                        <div class="section-number">
                            01
                        </div>

                        <h3>
                            Product Information
                        </h3>

                        <span>
                            Required
                        </span>

                    </div>


                    <div class="form-grid">


                        <!-- TITLE -->

                        <div class="form-group full">

                            <label>

                                Product Name

                                <span class="required">
                                    *
                                </span>

                            </label>

                            <input
                                type="text"
                                name="title"
                                value="<?php
                                echo htmlspecialchars(
                                    $title
                                );
                                ?>"
                                placeholder="Example: Engineering Mathematics Book"
                                maxlength="150"
                                required
                            >

                        </div>


                        <!-- CATEGORY -->

                        <div class="form-group">

                            <label>

                                Category

                                <span class="required">
                                    *
                                </span>

                            </label>

                            <select
                                name="category"
                                required
                            >

                                <option value="">
                                    Select category
                                </option>

                                <option
                                    value="Books"
                                    <?php
                                    echo $category === 'Books'
                                        ? 'selected'
                                        : '';
                                    ?>
                                >
                                    📚 Books
                                </option>

                                <option
                                    value="Lab Equipment"
                                    <?php
                                    echo $category === 'Lab Equipment'
                                        ? 'selected'
                                        : '';
                                    ?>
                                >
                                    🔬 Lab Equipment
                                </option>

                                <option
                                    value="Electronics"
                                    <?php
                                    echo $category === 'Electronics'
                                        ? 'selected'
                                        : '';
                                    ?>
                                >
                                    💻 Electronics
                                </option>

                                <option
                                    value="Bags & Stationery"
                                    <?php
                                    echo $category === 'Bags & Stationery'
                                        ? 'selected'
                                        : '';
                                    ?>
                                >
                                    🎒 Bags & Stationery
                                </option>

                                <option
                                    value="Campus Items"
                                    <?php
                                    echo $category === 'Campus Items'
                                        ? 'selected'
                                        : '';
                                    ?>
                                >
                                    🎓 Campus Items
                                </option>

                                <option
                                    value="Other Campus Item"
                                    <?php
                                    echo $category === 'Other Campus Item'
                                        ? 'selected'
                                        : '';
                                    ?>
                                >
                                    📦 Other Campus Item
                                </option>

                            </select>

                        </div>


                        <!-- CONDITION -->

                        <div class="form-group">

                            <label>

                                Condition

                                <span class="required">
                                    *
                                </span>

                            </label>

                            <select
                                name="product_condition"
                                required
                            >

                                <option
                                    value="New"
                                    <?php
                                    echo $condition === 'New'
                                        ? 'selected'
                                        : '';
                                    ?>
                                >
                                    ✨ New
                                </option>

                                <option
                                    value="Like New"
                                    <?php
                                    echo $condition === 'Like New'
                                        ? 'selected'
                                        : '';
                                    ?>
                                >
                                    ⭐ Like New
                                </option>

                                <option
                                    value="Good"
                                    <?php
                                    echo $condition === 'Good'
                                        ? 'selected'
                                        : '';
                                    ?>
                                >
                                    👍 Good
                                </option>

                                <option
                                    value="Fair"
                                    <?php
                                    echo $condition === 'Fair'
                                        ? 'selected'
                                        : '';
                                    ?>
                                >
                                    🙂 Fair
                                </option>

                                <option
                                    value="Used"
                                    <?php
                                    echo $condition === 'Used'
                                        ? 'selected'
                                        : '';
                                    ?>
                                >
                                    📦 Used
                                </option>

                            </select>

                        </div>


                        <!-- DESCRIPTION -->

                        <div class="form-group full">

                            <label>

                                Description

                                <span class="required">
                                    *
                                </span>

                            </label>

                            <textarea
                                name="description"
                                maxlength="2000"
                                placeholder="Describe the product, condition, defects, accessories and anything a buyer should know..."
                                required
                            ><?php
                            echo htmlspecialchars(
                                $description
                            );
                            ?></textarea>

                            <div class="field-help">

                                Be honest and detailed.
                                Good descriptions help buyers.

                            </div>

                        </div>

                    </div>

                </section>


                <!-- =================================================
                     SECTION 02
                ================================================= -->

                <section class="form-section">

                    <div class="section-title">

                        <div class="section-number">
                            02
                        </div>

                        <h3>
                            Price & Details
                        </h3>

                        <span>
                            Required + Optional
                        </span>

                    </div>


                    <div class="form-grid">


                        <!-- PRICE -->

                        <div class="form-group">

                            <label>

                                Selling Price

                                <span class="required">
                                    *
                                </span>

                            </label>

                            <div class="price-wrap">

                                <span class="price-symbol">
                                    ₹
                                </span>

                                <input
                                    class="price-input"
                                    type="number"
                                    name="price"
                                    value="<?php
                                    echo htmlspecialchars(
                                        $price
                                    );
                                    ?>"
                                    placeholder="0"
                                    min="0"
                                    step="0.01"
                                    required
                                >

                            </div>

                        </div>


                        <!-- QUANTITY -->

                        <div class="form-group">

                            <label>

                                Quantity

                                <span class="required">
                                    *
                                </span>

                            </label>

                            <input
                                type="number"
                                name="quantity"
                                value="<?php
                                echo htmlspecialchars(
                                    $quantity
                                );
                                ?>"
                                min="1"
                                max="999"
                                required
                            >

                        </div>


                        <!-- NEGOTIABLE -->

                        <div class="form-group full">

                            <label class="check-row">

                                <input
                                    type="checkbox"
                                    name="negotiable"
                                    value="1"
                                    <?php
                                    echo $negotiable
                                        ? 'checked'
                                        : '';
                                    ?>
                                >

                                <span>
                                    💬 Price is negotiable
                                </span>

                            </label>

                        </div>


                        <!-- PRODUCT AGE -->

                        <div class="form-group">

                            <label>

                                Product Age

                                <span class="optional">
                                    Optional
                                </span>

                            </label>

                            <input
                                type="text"
                                name="product_age"
                                value="<?php
                                echo htmlspecialchars(
                                    $productAge
                                );
                                ?>"
                                placeholder="Example: 1 year"
                                maxlength="100"
                            >

                        </div>


                        <!-- LOCATION -->

                        <div class="form-group">

                            <label>

                                Campus / Location

                                <span class="optional">
                                    Optional
                                </span>

                            </label>

                            <input
                                type="text"
                                name="location"
                                value="<?php
                                echo htmlspecialchars(
                                    $location
                                );
                                ?>"
                                placeholder="Example: Main Campus"
                                maxlength="150"
                            >

                        </div>

                    </div>

                </section>


                <!-- =================================================
                     SECTION 03
                ================================================= -->

                <section class="form-section">

                    <div class="section-title">

                        <div class="section-number">
                            03
                        </div>

                        <h3>
                            Product Photo
                        </h3>

                        <span>
                            Optional
                        </span>

                    </div>


                    <div
                        class="upload-box"
                        id="uploadBox"
                    >

                        <input
                            type="file"
                            name="product_image"
                            id="productImage"
                            accept="image/jpeg,image/png,image/webp"
                        >


                        <div
                            class="upload-content"
                            id="uploadContent"
                        >

                            <div class="upload-icon">
                                📸
                            </div>

                            <h4>
                                Add a product photo
                            </h4>

                            <p>
                                Click or drag an image here
                            </p>

                            <p>
                                JPG, PNG or WEBP • Maximum 5 MB
                            </p>

                            <br>

                            <strong>
                                Photo is optional
                            </strong>

                        </div>


                        <div
                            class="image-preview"
                            id="imagePreview"
                        >

                            <img
                                src=""
                                id="previewImage"
                                alt="Product preview"
                            >

                            <button
                                type="button"
                                class="remove-image"
                                id="removeImage"
                            >
                                ✕
                            </button>

                        </div>

                    </div>

                </section>


                <!-- =================================================
                     SECTION 04
                ================================================= -->

                <section class="form-section">

                    <div class="section-title">

                        <div class="section-number">
                            04
                        </div>

                        <h3>
                            Contact Information
                        </h3>

                        <span>
                            Required
                        </span>

                    </div>


                    <label>

                        How should buyers contact you?

                        <span class="required">
                            *
                        </span>

                    </label>


                    <div class="contact-options">


                        <!-- PHONE -->

                        <div class="contact-option">

                            <input
                                type="radio"
                                name="contact_method"
                                value="phone"
                                id="contactPhone"
                                <?php
                                echo $contactMethod === 'phone'
                                    ? 'checked'
                                    : '';
                                ?>
                            >

                            <label
                                class="contact-label"
                                for="contactPhone"
                            >

                                <div class="contact-icon">
                                    📞
                                </div>

                                <div>

                                    <strong>
                                        Phone
                                    </strong>

                                    <small>
                                        Call me
                                    </small>

                                </div>

                            </label>

                        </div>


                        <!-- EMAIL -->

                        <div class="contact-option">

                            <input
                                type="radio"
                                name="contact_method"
                                value="email"
                                id="contactEmail"
                                <?php
                                echo $contactMethod === 'email'
                                    ? 'checked'
                                    : '';
                                ?>
                            >

                            <label
                                class="contact-label"
                                for="contactEmail"
                            >

                                <div class="contact-icon">
                                    📧
                                </div>

                                <div>

                                    <strong>
                                        Email
                                    </strong>

                                    <small>
                                        Send me an email
                                    </small>

                                </div>

                            </label>

                        </div>


                        <!-- WHATSAPP -->

                        <div class="contact-option">

                            <input
                                type="radio"
                                name="contact_method"
                                value="whatsapp"
                                id="contactWhatsApp"
                                <?php
                                echo $contactMethod === 'whatsapp'
                                    ? 'checked'
                                    : '';
                                ?>
                            >

                            <label
                                class="contact-label"
                                for="contactWhatsApp"
                            >

                                <div class="contact-icon">
                                    💬
                                </div>

                                <div>

                                    <strong>
                                        WhatsApp
                                    </strong>

                                    <small>
                                        Message me
                                    </small>

                                </div>

                            </label>

                        </div>


                        <!-- PHONE + WHATSAPP -->

                        <div class="contact-option">

                            <input
                                type="radio"
                                name="contact_method"
                                value="phone_whatsapp"
                                id="contactBoth"
                                <?php
                                echo $contactMethod === 'phone_whatsapp'
                                    ? 'checked'
                                    : '';
                                ?>
                            >

                            <label
                                class="contact-label"
                                for="contactBoth"
                            >

                                <div class="contact-icon">
                                    📱
                                </div>

                                <div>

                                    <strong>
                                        Phone + WhatsApp
                                    </strong>

                                    <small>
                                        Same number
                                    </small>

                                </div>

                            </label>

                        </div>


                        <!-- EMAIL + PHONE -->

                        <div class="contact-option">

                            <input
                                type="radio"
                                name="contact_method"
                                value="email_phone"
                                id="contactEmailPhone"
                                <?php
                                echo $contactMethod === 'email_phone'
                                    ? 'checked'
                                    : '';
                                ?>
                            >

                            <label
                                class="contact-label"
                                for="contactEmailPhone"
                            >

                                <div class="contact-icon">
                                    📇
                                </div>

                                <div>

                                    <strong>
                                        Email + Phone
                                    </strong>

                                    <small>
                                        Both options
                                    </small>

                                </div>

                            </label>

                        </div>

                    </div>


                    <!-- CONTACT INPUT -->

                    <div
                        class="contact-input-box"
                        id="contactInputBox"
                    >

                        <div class="form-group">

                            <label id="contactInputLabel">
                                Contact Information
                            </label>

                            <input
                                type="text"
                                name="contact_value"
                                id="contactValue"
                                value="<?php
                                echo htmlspecialchars(
                                    $contactValue
                                );
                                ?>"
                            >

                            <div
                                class="field-help"
                                id="contactHelp"
                            ></div>

                        </div>


                        <!-- SECOND CONTACT -->

                        <div
                            class="form-group"
                            id="additionalContactBox"
                            style="display:none;margin-top:15px;"
                        >

                            <label>

                                Phone Number

                                <span class="required">
                                    *
                                </span>

                            </label>

                            <input
                                type="text"
                                name="additional_contact"
                                value="<?php
                                echo htmlspecialchars(
                                    $additionalContact
                                );
                                ?>"
                                placeholder="+91 XXXXX XXXXX"
                            >

                        </div>

                    </div>

                </section>


                <!-- =================================================
                     ACTIONS
                ================================================= -->

                <div class="form-actions">

                    <a
                        href="marketplace.php"
                        class="btn btn-cancel"
                    >
                        ← Cancel
                    </a>


                    <button
                        type="submit"
                        class="btn btn-submit"
                        id="submitButton"
                    >
                        🚀 Publish Product
                    </button>

                </div>


            </form>

        </div>


        <!-- =================================================
             SIDE INFORMATION
        ================================================= -->

        <aside class="info-card">

            <h3>
                Make your listing better ✨
            </h3>

            <p>
                A clear and honest listing helps other
                students understand your product and
                contact you easily.
            </p>


            <div class="tip">

                <div class="tip-icon">
                    📸
                </div>

                <div>

                    <h4>
                        Add a real photo
                    </h4>

                    <p>
                        Listings with clear photos are
                        easier for students to understand.
                    </p>

                </div>

            </div>


            <div class="tip">

                <div class="tip-icon">
                    💰
                </div>

                <div>

                    <h4>
                        Set a fair price
                    </h4>

                    <p>
                        Mark your price as negotiable if
                        you are open to offers.
                    </p>

                </div>

            </div>


            <div class="tip">

                <div class="tip-icon">
                    📝
                </div>

                <div>

                    <h4>
                        Describe honestly
                    </h4>

                    <p>
                        Mention scratches, defects,
                        usage and accessories.
                    </p>

                </div>

            </div>


            <div class="tip">

                <div class="tip-icon">
                    🎓
                </div>

                <div>

                    <h4>
                        Campus-friendly
                    </h4>

                    <p>
                        EduTrade is designed for useful
                        student and campus products.
                    </p>

                </div>

            </div>


            <div class="privacy-box">

                <strong>
                    🔒 Contact privacy
                </strong>

                <span>
                    Only the contact information you choose
                    is intended for interested buyers.
                </span>

            </div>

        </aside>


    </div>


    <footer>

        EduTrade PRO • Student Marketplace
        • Learn. Trade. Grow. 🚀

    </footer>


</main>


<script>

/* =========================================================
   CONTACT SYSTEM
========================================================= */

const contactRadios =
    document.querySelectorAll(
        'input[name="contact_method"]'
    );

const contactInputBox =
    document.getElementById(
        'contactInputBox'
    );

const contactInput =
    document.getElementById(
        'contactValue'
    );

const contactLabel =
    document.getElementById(
        'contactInputLabel'
    );

const contactHelp =
    document.getElementById(
        'contactHelp'
    );

const additionalContactBox =
    document.getElementById(
        'additionalContactBox'
    );


function updateContactField(){

    const selected =
        document.querySelector(
            'input[name="contact_method"]:checked'
        );


    if(!selected){

        contactInputBox.classList.remove(
            'show'
        );

        contactInput.required = false;

        additionalContactBox.style.display =
            'none';

        return;

    }


    contactInputBox.classList.add(
        'show'
    );

    contactInput.required = true;


    if(selected.value === 'phone'){

        contactLabel.innerHTML =
            'Phone Number <span class="required">*</span>';

        contactInput.type =
            'tel';

        contactInput.placeholder =
            '+91 XXXXX XXXXX';

        contactHelp.textContent =
            'Enter a phone number buyers can call.';

        additionalContactBox.style.display =
            'none';

    }


    else if(selected.value === 'email'){

        contactLabel.innerHTML =
            'Email Address <span class="required">*</span>';

        contactInput.type =
            'email';

        contactInput.placeholder =
            'student@example.com';

        contactHelp.textContent =
            'Use an email address you check regularly.';

        additionalContactBox.style.display =
            'none';

    }


    else if(selected.value === 'whatsapp'){

        contactLabel.innerHTML =
            'WhatsApp Number <span class="required">*</span>';

        contactInput.type =
            'tel';

        contactInput.placeholder =
            '+91 XXXXX XXXXX';

        contactHelp.textContent =
            'Enter the WhatsApp number buyers should message.';

        additionalContactBox.style.display =
            'none';

    }


    else if(selected.value === 'phone_whatsapp'){

        contactLabel.innerHTML =
            'Phone / WhatsApp Number <span class="required">*</span>';

        contactInput.type =
            'tel';

        contactInput.placeholder =
            '+91 XXXXX XXXXX';

        contactHelp.textContent =
            'The same number will be used for calls and WhatsApp.';

        additionalContactBox.style.display =
            'none';

    }


    else if(selected.value === 'email_phone'){

        contactLabel.innerHTML =
            'Email Address <span class="required">*</span>';

        contactInput.type =
            'email';

        contactInput.placeholder =
            'student@example.com';

        contactHelp.textContent =
            'Both your email and phone number are required.';

        additionalContactBox.style.display =
            'block';

    }

}


contactRadios.forEach(
    radio => {

        radio.addEventListener(
            'change',
            updateContactField
        );

    }
);


updateContactField();


/* =========================================================
   IMAGE PREVIEW
========================================================= */

const productImage =
    document.getElementById(
        'productImage'
    );

const imagePreview =
    document.getElementById(
        'imagePreview'
    );

const previewImage =
    document.getElementById(
        'previewImage'
    );

const uploadContent =
    document.getElementById(
        'uploadContent'
    );

const removeImage =
    document.getElementById(
        'removeImage'
    );

const uploadBox =
    document.getElementById(
        'uploadBox'
    );


function previewSelectedImage(file){

    if(!file){
        return;
    }


    const allowedTypes = [

        'image/jpeg',
        'image/png',
        'image/webp'

    ];


    if(
        !allowedTypes.includes(
            file.type
        )
    ){

        alert(
            'Please select a JPG, PNG or WEBP image.'
        );

        productImage.value = '';

        return;

    }


    if(
        file.size >
        5 * 1024 * 1024
    ){

        alert(
            'Image must be smaller than 5 MB.'
        );

        productImage.value = '';

        return;

    }


    const reader =
        new FileReader();


    reader.onload =
        function(event){

            previewImage.src =
                event.target.result;

            imagePreview.style.display =
                'block';

            uploadContent.style.display =
                'none';

        };


    reader.readAsDataURL(file);

}


productImage.addEventListener(
    'change',
    function(){

        previewSelectedImage(
            this.files[0]
        );

    }
);


/* =========================================================
   REMOVE IMAGE
========================================================= */

removeImage.addEventListener(
    'click',
    function(event){

        event.preventDefault();

        event.stopPropagation();

        productImage.value = '';

        previewImage.src = '';

        imagePreview.style.display =
            'none';

        uploadContent.style.display =
            'block';

    }
);


/* =========================================================
   DRAG & DROP
========================================================= */

uploadBox.addEventListener(
    'dragover',
    function(event){

        event.preventDefault();

        this.classList.add(
            'dragging'
        );

    }
);


uploadBox.addEventListener(
    'dragleave',
    function(){

        this.classList.remove(
            'dragging'
        );

    }
);


uploadBox.addEventListener(
    'drop',
    function(event){

        event.preventDefault();

        this.classList.remove(
            'dragging'
        );


        const files =
            event.dataTransfer.files;


        if(files.length > 0){

            try{

                const dataTransfer =
                    new DataTransfer();

                dataTransfer.items.add(
                    files[0]
                );

                productImage.files =
                    dataTransfer.files;

                previewSelectedImage(
                    files[0]
                );

            }catch(error){

                console.error(
                    error
                );

            }

        }

    }
);


/* =========================================================
   FORM SUBMIT
========================================================= */

const productForm =
    document.getElementById(
        'productForm'
    );

const submitButton =
    document.getElementById(
        'submitButton'
    );


productForm.addEventListener(
    'submit',
    function(){

        submitButton.disabled =
            true;

        submitButton.innerHTML =
            '⏳ Publishing...';

    }
);


/* =========================================================
   DESCRIPTION FEEDBACK
========================================================= */

const description =
    document.querySelector(
        'textarea[name="description"]'
    );


description.addEventListener(
    'input',
    function(){

        if(
            this.value.length > 1900
        ){

            this.style.borderColor =
                '#f59e0b';

        }else{

            this.style.borderColor =
                '';

        }

    }
);


/* =========================================================
   SIDEBAR SCROLL EFFECT
========================================================= */

window.addEventListener(
    'scroll',
    function(){

        const sidebar =
            document.querySelector(
                '.sidebar'
            );


        if(
            window.scrollY > 40
        ){

            sidebar.style.boxShadow =
                '0 10px 40px rgba(0,0,0,.25)';

        }else{

            sidebar.style.boxShadow =
                'none';

        }

    }
);

</script>


</body>
</html>