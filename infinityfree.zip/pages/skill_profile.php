
<?php
session_start();

require_once "../config/db.php";

/* =========================================================
   LOGIN CHECK
========================================================= */
if (!isset($_SESSION['user_id'])) {
    header("Location: ../includes/login.php");
    exit;
}

$currentUserId = (int) $_SESSION['user_id'];

/* =========================================================
   HELPERS
========================================================= */
function clean($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function getInitial($name)
{
    $name = trim((string)$name);

    if ($name === '') {
        return 'S';
    }

    if (function_exists('mb_substr')) {
        return strtoupper(mb_substr($name, 0, 1, 'UTF-8'));
    }

    return strtoupper(substr($name, 0, 1));
}

function getSkillImage($image)
{
    $image = trim((string)$image);

    if ($image === '') {
        return '';
    }

    $filename = basename(str_replace('\\', '/', $image));
    $physicalPath = dirname(__DIR__) . "/uploads/skills/" . $filename;

    if (!is_file($physicalPath)) {
        return '';
    }

    return "../uploads/skills/" . rawurlencode($filename);
}

/* =========================================================
   SKILL ID
========================================================= */
$skillId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($skillId <= 0) {
    header("Location: skills.php");
    exit;
}

/* =========================================================
   FETCH SKILL AND OWNER
========================================================= */
$stmt = $conn->prepare("
    SELECT
        s.id,
        s.user_id,
        s.title,
        s.category,
        s.description,
        s.experience,
        s.availability,
        s.image,
        s.price,
        s.created_at,
        u.name AS student_name,
        u.email AS student_email
    FROM skills s
    LEFT JOIN users u ON s.user_id = u.id
    WHERE s.id = ?
    LIMIT 1
");

if (!$stmt) {
    header("Location: skills.php");
    exit;
}

$stmt->bind_param("i", $skillId);
$stmt->execute();

$result = $stmt->get_result();
$skill = $result->fetch_assoc();

$stmt->close();

if (!$skill) {
    header("Location: skills.php");
    exit;
}

/* =========================================================
   OWNER AND AVAILABILITY
========================================================= */
$skillOwnerId = (int)$skill['user_id'];
$isOwner = ($currentUserId === $skillOwnerId);

$availability = trim((string)($skill['availability'] ?? ''));
$isUnavailable = (strtolower($availability) === 'unavailable');

$skillImage = getSkillImage($skill['image'] ?? '');

/* =========================================================
   HIRE STATUS MESSAGE
========================================================= */
$hireStatus = $_GET['hire'] ?? '';
$hireAlert = '';
$hireAlertType = '';

if ($hireStatus === 'success') {
    $hireAlert = 'Hire request sent successfully. The student can now review your project.';
    $hireAlertType = 'success';
} elseif ($hireStatus === 'error') {
    $hireAlert = 'Unable to send the hire request. Please check your details and try again.';
    $hireAlertType = 'error';
} elseif ($hireStatus === 'owner') {
    $hireAlert = 'You cannot hire yourself.';
    $hireAlertType = 'error';
} elseif ($hireStatus === 'unavailable') {
    $hireAlert = 'This student is currently unavailable for new projects.';
    $hireAlertType = 'error';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?php echo clean($skill['title']); ?> | EduTrade</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {
    --cyan: #22d3ee;
    --cyan-light: #67e8f9;
    --violet: #818cf8;
    --bg: #050816;
    --panel: rgba(15, 23, 42, .88);
    --border: rgba(255, 255, 255, .08);
    --muted: #94a3b8;
}

body {
    min-height: 100vh;
    font-family: "Inter", sans-serif;
    color: #f8fafc;
    background:
        radial-gradient(circle at 8% 0%, rgba(34,211,238,.12), transparent 28%),
        radial-gradient(circle at 92% 5%, rgba(139,92,246,.13), transparent 30%),
        #050816;
}

a {
    color: inherit;
    text-decoration: none;
}

button, input, textarea {
    font: inherit;
}

.navbar {
    position: sticky;
    top: 0;
    z-index: 1000;
    min-height: 76px;
    padding: 14px 5%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
    background: rgba(5,8,22,.88);
    border-bottom: 1px solid var(--border);
    backdrop-filter: blur(20px);
}

.brand {
    display: flex;
    align-items: center;
    gap: 11px;
    font-size: 18px;
    font-weight: 900;
}

.brand-icon {
    width: 42px;
    height: 42px;
    display: grid;
    place-items: center;
    border-radius: 13px;
    background: linear-gradient(135deg, var(--cyan), #6366f1, #8b5cf6);
}

.brand span {
    color: var(--cyan);
}

.nav-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}

.nav-btn {
    padding: 11px 15px;
    border-radius: 11px;
    border: 1px solid var(--border);
    background: rgba(255,255,255,.035);
    color: var(--muted);
    font-size: 11px;
    font-weight: 800;
    transition: .2s;
}

.nav-btn:hover {
    color: white;
    border-color: rgba(34,211,238,.35);
    transform: translateY(-2px);
}

.container {
    width: min(1250px, calc(100% - 36px));
    margin: auto;
    padding: 42px 0 80px;
}

.alert {
    padding: 15px 18px;
    margin-bottom: 22px;
    border-radius: 14px;
    font-size: 12px;
    font-weight: 700;
}

.alert.success {
    color: #bbf7d0;
    background: rgba(34,197,94,.08);
    border: 1px solid rgba(34,197,94,.22);
}

.alert.error {
    color: #fecaca;
    background: rgba(239,68,68,.08);
    border: 1px solid rgba(239,68,68,.22);
}

.breadcrumb {
    display: flex;
    flex-wrap: wrap;
    gap: 9px;
    margin-bottom: 22px;
    color: #64748b;
    font-size: 11px;
    font-weight: 700;
}

.breadcrumb a:hover {
    color: var(--cyan);
}

.profile {
    display: grid;
    grid-template-columns: minmax(0, 1.05fr) minmax(340px, .95fr);
    gap: 22px;
    align-items: stretch;
}

.image-panel,
.details-panel {
    overflow: hidden;
    border: 1px solid var(--border);
    border-radius: 26px;
    background: var(--panel);
    box-shadow: 0 30px 80px rgba(0,0,0,.22);
}

.image-panel {
    position: relative;
    min-height: 500px;
    background:
        radial-gradient(circle at 20% 20%, rgba(34,211,238,.1), transparent 35%),
        #0b1222;
}

.skill-image {
    display: block;
    width: 100%;
    height: 100%;
    min-height: 500px;
    object-fit: cover;
}

.image-empty {
    min-height: 500px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 12px;
    color: #64748b;
}

.image-empty-icon {
    width: 75px;
    height: 75px;
    display: grid;
    place-items: center;
    border-radius: 22px;
    font-size: 30px;
    background: rgba(34,211,238,.08);
}

.owner-badge {
    position: absolute;
    top: 18px;
    left: 18px;
    padding: 9px 12px;
    border-radius: 999px;
    color: #a5f3fc;
    background: rgba(2,6,23,.78);
    border: 1px solid rgba(34,211,238,.2);
    font-size: 10px;
    font-weight: 900;
    text-transform: uppercase;
}

.details-panel {
    padding: 30px;
}

.meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 18px;
}

.category {
    padding: 8px 11px;
    border-radius: 9px;
    color: #a5f3fc;
    background: rgba(34,211,238,.08);
    border: 1px solid rgba(34,211,238,.15);
    font-size: 9px;
    font-weight: 900;
    letter-spacing: .7px;
    text-transform: uppercase;
}

.availability {
    padding: 8px 11px;
    border-radius: 999px;
    font-size: 9px;
    font-weight: 900;
}

.available {
    color: #86efac;
    background: rgba(34,197,94,.09);
}

.unavailable {
    color: #fca5a5;
    background: rgba(239,68,68,.09);
}

.title {
    font-size: clamp(28px, 4vw, 44px);
    line-height: 1.1;
    letter-spacing: -1.5px;
    overflow-wrap: anywhere;
}

.description {
    margin-top: 15px;
    color: var(--muted);
    font-size: 13px;
    line-height: 1.85;
    overflow-wrap: anywhere;
}

.price-box {
    margin-top: 24px;
    padding: 19px;
    border-radius: 17px;
    background: linear-gradient(135deg, rgba(34,211,238,.07), rgba(99,102,241,.07));
    border: 1px solid rgba(34,211,238,.12);
}

.price-label {
    color: #64748b;
    font-size: 9px;
    font-weight: 900;
    letter-spacing: 1px;
    text-transform: uppercase;
}

.price {
    margin-top: 6px;
    color: var(--cyan-light);
    font-size: 29px;
    font-weight: 900;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 10px;
    margin-top: 15px;
}

.info {
    min-width: 0;
    padding: 14px;
    border-radius: 13px;
    background: rgba(255,255,255,.025);
    border: 1px solid rgba(255,255,255,.055);
}

.info-label {
    margin-bottom: 6px;
    color: #64748b;
    font-size: 9px;
    font-weight: 800;
    letter-spacing: .6px;
    text-transform: uppercase;
}

.info-value {
    color: #cbd5e1;
    font-size: 11px;
    font-weight: 700;
    overflow-wrap: anywhere;
}

.provider {
    display: flex;
    align-items: center;
    gap: 13px;
    margin-top: 20px;
    padding: 16px 0;
    border-top: 1px solid var(--border);
    border-bottom: 1px solid var(--border);
}

.provider-avatar {
    width: 45px;
    height: 45px;
    flex-shrink: 0;
    display: grid;
    place-items: center;
    border-radius: 14px;
    background: linear-gradient(135deg, var(--cyan), #6366f1);
    font-weight: 900;
}

.provider-label {
    color: #64748b;
    font-size: 9px;
    font-weight: 800;
    text-transform: uppercase;
}

.provider-name {
    margin-top: 4px;
    font-size: 13px;
    font-weight: 900;
}

.provider-email {
    margin-top: 4px;
    color: var(--cyan-light);
    font-size: 10px;
    overflow-wrap: anywhere;
}

.actions {
    display: flex;
    flex-wrap: wrap;
    align-items: stretch;
    gap: 10px;
    margin-top: 22px;
}

.actions > * {
    min-width: 0;
}

.actions > a,
.actions > button,
.actions > form {
    flex: 1 1 130px;
}

.actions > form {
    display: flex;
}

.hire-btn,
.save-btn {
    min-height: 48px;
    padding: 12px 15px;
    border-radius: 13px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 900;
    transition: .22s;
    text-align: center;
}

.hire-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    border: 0;
    color: #04111c;
    background: linear-gradient(135deg, #67e8f9, #22d3ee, #818cf8);
    box-shadow: 0 12px 30px rgba(34,211,238,.12);
}

.hire-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 17px 35px rgba(34,211,238,.22);
}

.save-btn {
    width: 100%;
    color: #cbd5e1;
    background: rgba(255,255,255,.04);
    border: 1px solid var(--border);
}

.save-btn:hover {
    border-color: rgba(139,92,246,.4);
    color: white;
    transform: translateY(-2px);
}

.owner-message {
    margin-top: 22px;
    padding: 15px;
    border-radius: 13px;
    color: var(--muted);
    background: rgba(255,255,255,.025);
    border: 1px solid var(--border);
    font-size: 11px;
    line-height: 1.7;
}

/* HIRE MODAL */
.modal {
    position: fixed;
    inset: 0;
    z-index: 5000;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 18px;
    background: rgba(2,6,23,.84);
    backdrop-filter: blur(12px);
}

.modal.show {
    display: flex;
}

.modal-box {
    width: min(570px, 100%);
    max-height: calc(100vh - 36px);
    overflow-y: auto;
    padding: 27px;
    border-radius: 23px;
    background: linear-gradient(145deg, #101827, #080e1d);
    border: 1px solid var(--border);
    box-shadow: 0 40px 100px rgba(0,0,0,.45);
}

.modal-head {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 15px;
    margin-bottom: 22px;
}

.modal-title {
    font-size: 22px;
    font-weight: 900;
}

.modal-subtitle {
    margin-top: 7px;
    color: #64748b;
    font-size: 11px;
    line-height: 1.7;
}

.close {
    width: 36px;
    height: 36px;
    flex-shrink: 0;
    border: 0;
    border-radius: 10px;
    cursor: pointer;
    color: #94a3b8;
    background: rgba(255,255,255,.06);
    font-size: 21px;
}

.form-group {
    margin-bottom: 17px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    color: #cbd5e1;
    font-size: 10px;
    font-weight: 800;
}

.form-control {
    width: 100%;
    padding: 13px 14px;
    border-radius: 12px;
    border: 1px solid var(--border);
    outline: none;
    color: white;
    background: rgba(255,255,255,.035);
    font-size: 12px;
}

.form-control:focus {
    border-color: rgba(34,211,238,.5);
    box-shadow: 0 0 0 3px rgba(34,211,238,.06);
}

textarea.form-control {
    min-height: 120px;
    resize: vertical;
}

.form-hint {
    margin-top: 7px;
    color: #64748b;
    font-size: 10px;
    line-height: 1.6;
}

.contact-box {
    margin-bottom: 18px;
    padding: 14px;
    border-radius: 13px;
    background: rgba(34,211,238,.045);
    border: 1px solid rgba(34,211,238,.1);
}

.contact-heading {
    margin-bottom: 8px;
    color: #64748b;
    font-size: 9px;
    font-weight: 900;
    letter-spacing: .8px;
    text-transform: uppercase;
}

.contact-name {
    color: #cbd5e1;
    font-size: 11px;
    font-weight: 800;
}

.submit-btn {
    width: 100%;
    min-height: 50px;
    border: 0;
    border-radius: 13px;
    cursor: pointer;
    color: #04111c;
    background: linear-gradient(135deg, #67e8f9, #22d3ee, #818cf8);
    font-size: 12px;
    font-weight: 900;
}

@media (max-width: 900px) {
    .profile {
        grid-template-columns: 1fr;
    }

    .image-panel,
    .skill-image,
    .image-empty {
        min-height: 380px;
    }
}

@media (max-width: 600px) {
    .navbar {
        padding: 12px 16px;
        align-items: flex-start;
    }

    .brand-text {
        display: none;
    }

    .nav-actions {
        justify-content: flex-end;
    }

    .nav-btn {
        padding: 10px;
    }

    .container {
        width: calc(100% - 24px);
        padding-top: 25px;
    }

    .details-panel {
        padding: 20px;
        border-radius: 21px;
    }

    .image-panel {
        border-radius: 21px;
    }

    .image-panel,
    .skill-image,
    .image-empty {
        min-height: 280px;
    }

    .info-grid {
        grid-template-columns: 1fr 1fr;
    }

    .actions {
        flex-direction: column;
    }

    .actions > a,
    .actions > button,
    .actions > form {
        flex: 1 1 auto;
        width: 100%;
    }

    .modal-box {
        padding: 20px;
    }
}
</style>
</head>

<body>

<nav class="navbar">
    <a href="dashboard.php" class="brand">
        <div class="brand-icon">🎓</div>
        <div class="brand-text">Edu<span>Trade</span> PRO</div>
    </a>

    <div class="nav-actions">
        <a href="skills.php" class="nav-btn">← Skill Hub</a>
        <a href="dashboard.php" class="nav-btn">Dashboard</a>
    </div>
</nav>

<main class="container">

    <?php if ($hireAlert !== ''): ?>
        <div class="alert <?php echo clean($hireAlertType); ?>">
            <?php echo $hireAlertType === 'success' ? '✓ ' : '⚠ '; ?>
            <?php echo clean($hireAlert); ?>
        </div>
    <?php endif; ?>

    <div class="breadcrumb">
        <a href="skills.php">Skill Hub</a>
        <span>›</span>
        <span><?php echo clean($skill['title']); ?></span>
    </div>

    <section class="profile">

        <div class="image-panel">
            <?php if ($skillImage !== ''): ?>
                <img
                    src="<?php echo clean($skillImage); ?>"
                    alt="<?php echo clean($skill['title']); ?>"
                    class="skill-image"
                    onerror="this.style.display='none';document.getElementById('imageFallback').style.display='flex';"
                >

                <div id="imageFallback" class="image-empty" style="display:none;">
                    <div class="image-empty-icon">⚡</div>
                    <span>Skill Preview</span>
                </div>
            <?php else: ?>
                <div class="image-empty">
                    <div class="image-empty-icon">⚡</div>
                    <span>Skill Preview</span>
                </div>
            <?php endif; ?>

            <?php if ($isOwner): ?>
                <div class="owner-badge">Your Skill</div>
            <?php endif; ?>
        </div>

        <div class="details-panel">

            <div class="meta">
                <div class="category">
                    <?php
                    echo !empty($skill['category'])
                        ? clean($skill['category'])
                        : 'Student Skill';
                    ?>
                </div>

                <div class="availability <?php echo $isUnavailable ? 'unavailable' : 'available'; ?>">
                    <?php echo $isUnavailable ? 'Unavailable' : 'Available'; ?>
                </div>
            </div>

            <h1 class="title"><?php echo clean($skill['title']); ?></h1>

            <div class="description">
                <?php echo nl2br(clean($skill['description'])); ?>
            </div>

            <div class="price-box">
                <div class="price-label">Starting Price</div>
                <div class="price">
                    ₹<?php echo number_format((float)$skill['price'], 2); ?>
                </div>
            </div>

            <div class="info-grid">
                <div class="info">
                    <div class="info-label">Experience</div>
                    <div class="info-value">
                        <?php
                        echo !empty($skill['experience'])
                            ? clean($skill['experience'])
                            : 'Not specified';
                        ?>
                    </div>
                </div>

                <div class="info">
                    <div class="info-label">Availability</div>
                    <div class="info-value">
                        <?php echo $isUnavailable ? 'Currently unavailable' : 'Open for projects'; ?>
                    </div>
                </div>
            </div>

            <div class="provider">
                <div class="provider-avatar">
                    <?php echo clean(getInitial($skill['student_name'] ?? 'Student')); ?>
                </div>

                <div>
                    <div class="provider-label">Skill Provider</div>
                    <div class="provider-name">
                        <?php echo clean($skill['student_name'] ?: 'EduTrade Student'); ?>
                    </div>

                    <?php if (!empty($skill['student_email'])): ?>
                        <div class="provider-email">
                            <?php echo clean($skill['student_email']); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- ACTIONS: MESSAGE, HIRE AND SAVE -->
            <?php if (!$isOwner): ?>

                <div class="actions">

                    <a
                        href="messages.php?with=<?php echo $skillOwnerId; ?>"
                        class="hire-btn"
                    >
                        💬 Message Student
                    </a>

                    <?php if (!$isUnavailable): ?>

                        <button
                            type="button"
                            class="hire-btn"
                            onclick="openHireModal()"
                        >
                            🚀 Hire Me
                        </button>

                        <form method="POST" action="../api/bookmark_skill.php">
                            <input
                                type="hidden"
                                name="skill_id"
                                value="<?php echo (int)$skill['id']; ?>"
                            >

                            <button type="submit" class="save-btn">
                                ♡ Save Skill
                            </button>
                        </form>

                    <?php endif; ?>

                </div>

                <?php if ($isUnavailable): ?>
                    <div class="owner-message">
                        🔒 This student is currently unavailable for new projects,
                        but you can still send a message.
                    </div>
                <?php endif; ?>

            <?php else: ?>

                <div class="owner-message">
                    👤 This is your skill listing. Other students can view your
                    profile and send you project requests.
                </div>

            <?php endif; ?>

        </div>
    </section>
</main>

<!-- HIRE MODAL -->
<?php if (!$isOwner && !$isUnavailable): ?>

<div class="modal" id="hireModal">
    <div class="modal-box">

        <div class="modal-head">
            <div>
                <div class="modal-title">
                    Hire <?php echo clean($skill['student_name'] ?: 'Student'); ?>
                </div>

                <div class="modal-subtitle">
                    Send a new project request. You can hire this student again
                    even if you completed a previous project together.
                </div>
            </div>

            <button type="button" class="close" onclick="closeHireModal()">×</button>
        </div>

        <form method="POST" action="../api/hire_request.php">

            <input
                type="hidden"
                name="skill_id"
                value="<?php echo (int)$skill['id']; ?>"
            >

            <div class="form-group">
                <label class="form-label" for="project_title">Project Title</label>
                <input
                    id="project_title"
                    type="text"
                    name="project_title"
                    class="form-control"
                    maxlength="150"
                    placeholder="e.g. College Website Design"
                    required
                >
            </div>

            <div class="form-group">
                <label class="form-label" for="project_message">Project Details</label>
                <textarea
                    id="project_message"
                    name="message"
                    class="form-control"
                    maxlength="2000"
                    placeholder="Explain the requirements, deadline and other details."
                    required
                ></textarea>

                <div class="form-hint">
                    Provide enough information for the student to understand your project.
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="project_budget">Budget (₹)</label>
                <input
                    id="project_budget"
                    type="number"
                    name="budget"
                    class="form-control"
                    min="0"
                    step="0.01"
                    placeholder="Enter your project budget"
                    required
                >
            </div>

            <div class="contact-box">
                <div class="contact-heading">Provider Contact</div>
                <div class="contact-name">
                    <?php echo clean($skill['student_name'] ?: 'EduTrade Student'); ?>
                </div>

                <?php if (!empty($skill['student_email'])): ?>
                    <div class="provider-email">
                        <?php echo clean($skill['student_email']); ?>
                    </div>
                <?php endif; ?>
            </div>

            <button type="submit" class="submit-btn">
                🚀 Send New Hire Request
            </button>
        </form>
    </div>
</div>

<?php endif; ?>

<script>
function openHireModal() {
    const modal = document.getElementById("hireModal");

    if (!modal) {
        return;
    }

    modal.classList.add("show");
    document.body.style.overflow = "hidden";
}

function closeHireModal() {
    const modal = document.getElementById("hireModal");

    if (!modal) {
        return;
    }

    modal.classList.remove("show");
    document.body.style.overflow = "";
}

const hireModal = document.getElementById("hireModal");

if (hireModal) {
    hireModal.addEventListener("click", function(event) {
        if (event.target === hireModal) {
            closeHireModal();
        }
    });
}

document.addEventListener("keydown", function(event) {
    if (event.key === "Escape") {
        closeHireModal();
    }
});
</script>

</body>
</html>
