<?php
/* =========================================================
   EduTrade PRO — Student Dashboard
   File: pages/dashboard.php
   Compatible with existing EduTrade folder structure
========================================================= */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

/* AUTHENTICATION */
if (
    empty($_SESSION['logged_in']) ||
    $_SESSION['logged_in'] !== true ||
    empty($_SESSION['user_id'])
) {
    header('Location: ../includes/login.php');
    exit;
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    die('Database connection failed. Please check config/db.php.');
}

$userId = (int) $_SESSION['user_id'];
$userName = $_SESSION['name'] ?? $_SESSION['username'] ?? 'Student';
$userEmail = $_SESSION['email'] ?? '';

/* =========================================================
   HELPER FUNCTIONS
========================================================= */

function clean($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function getInitial($name): string
{
    $name = trim((string)$name);

    if ($name === '') {
        return 'S';
    }

    return strtoupper(substr($name, 0, 1));
}

function getCount(mysqli $conn, string $sql, string $types = '', array $params = []): int
{
    try {
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            return 0;
        }

        if ($types !== '' && !empty($params)) {
            $stmt->bind_param($types, ...$params);
        }

        if (!$stmt->execute()) {
            $stmt->close();
            return 0;
        }

        $result = $stmt->get_result();
        $row = $result ? $result->fetch_row() : [0];

        $stmt->close();

        return (int)($row[0] ?? 0);
    } catch (Throwable $e) {
        return 0;
    }
}

function getProductImage($image): string
{
    $image = trim((string)$image);

    if ($image === '') {
        return '';
    }

    // Support existing records storing a filename or relative path.
    $image = str_replace('\\', '/', $image);

    if (preg_match('~^https?://~i', $image)) {
        return $image;
    }

    $filename = basename($image);

    if ($filename === '' || $filename === '.' || $filename === '..') {
        return '';
    }

    $diskPath = __DIR__ . '/../uploads/products/' . $filename;

    if (is_file($diskPath)) {
        return '../uploads/products/' . rawurlencode($filename);
    }

    // Support older records that stored a path relative to the project.
    if (strpos($image, 'uploads/products/') === 0) {
        $oldPath = __DIR__ . '/../' . $image;

        if (is_file($oldPath)) {
            return '../' . implode(
                '/',
                array_map('rawurlencode', explode('/', $image))
            );
        }
    }

    return '';
}

function getSkillImage($image): string
{
    $image = trim((string)$image);

    if ($image === '') {
        return '';
    }

    if (preg_match('~^https?://~i', $image)) {
        return $image;
    }

    $filename = basename(str_replace('\\', '/', $image));

    if ($filename === '' || $filename === '.' || $filename === '..') {
        return '';
    }

    if (is_file(__DIR__ . '/../uploads/skills/' . $filename)) {
        return '../uploads/skills/' . rawurlencode($filename);
    }

    return '';
}

function getCategoryFromProduct($title, $description): string
{
    $text = strtolower((string)$title . ' ' . (string)$description);

    if (strpos($text, 'category: books') !== false ||
        strpos($text, 'book') !== false ||
        strpos($text, 'textbook') !== false) {
        return 'Books';
    }

    if (strpos($text, 'category: lab') !== false ||
        strpos($text, 'lab equipment') !== false ||
        strpos($text, 'laboratory') !== false ||
        strpos($text, 'practical kit') !== false) {
        return 'Lab';
    }

    if (strpos($text, 'category: electronics') !== false ||
        strpos($text, 'laptop') !== false ||
        strpos($text, 'calculator') !== false ||
        strpos($text, 'electronics') !== false ||
        strpos($text, 'keyboard') !== false) {
        return 'Electronics';
    }

    if (strpos($text, 'category: stationery') !== false ||
        strpos($text, 'stationery') !== false ||
        strpos($text, 'notebook') !== false ||
        strpos($text, 'bag') !== false ||
        strpos($text, 'pen set') !== false) {
        return 'Stationery';
    }

    return 'Other';
}

function getSkillIcon($title, $description = '', $category = ''): string
{
    $text = strtolower(
        (string)$title . ' ' .
        (string)$description . ' ' .
        (string)$category
    );

    if (strpos($text, 'photograph') !== false ||
        strpos($text, 'camera') !== false) {
        return 'fa-camera';
    }

    if (strpos($text, 'design') !== false ||
        strpos($text, 'ui/ux') !== false ||
        strpos($text, 'graphic') !== false) {
        return 'fa-pen-nib';
    }

    if (strpos($text, 'develop') !== false ||
        strpos($text, 'coding') !== false ||
        strpos($text, 'program') !== false ||
        strpos($text, 'web') !== false) {
        return 'fa-code';
    }

    if (strpos($text, 'video') !== false ||
        strpos($text, 'edit') !== false) {
        return 'fa-video';
    }

    if (strpos($text, 'teach') !== false ||
        strpos($text, 'tutor') !== false) {
        return 'fa-chalkboard-user';
    }

    if (strpos($text, 'write') !== false ||
        strpos($text, 'content') !== false) {
        return 'fa-pen';
    }

    if (strpos($text, 'market') !== false ||
        strpos($text, 'social media') !== false) {
        return 'fa-bullhorn';
    }

    return 'fa-wand-magic-sparkles';
}

/* =========================================================
   DATABASE COUNTS
========================================================= */

$totalStudents = getCount(
    $conn,
    'SELECT COUNT(*) FROM users'
);

$totalProducts = getCount(
    $conn,
    'SELECT COUNT(*) FROM products'
);

$totalSkills = getCount(
    $conn,
    'SELECT COUNT(*) FROM skills'
);

$myProducts = getCount(
    $conn,
    'SELECT COUNT(*) FROM products WHERE user_id = ?',
    'i',
    [$userId]
);

$mySkills = getCount(
    $conn,
    'SELECT COUNT(*) FROM skills WHERE user_id = ?',
    'i',
    [$userId]
);

/*
 * These counts use the existing table/column names.
 * If your installation does not yet have one of these tables,
 * the helper safely returns zero.
 */
$incomingRequests = getCount(
    $conn,
    'SELECT COUNT(*) FROM hire_requests
     WHERE provider_id = ? OR receiver_id = ?',
    'ii',
    [$userId, $userId]
);

$savedProducts = getCount(
    $conn,
    'SELECT COUNT(*) FROM saved_products WHERE user_id = ?',
    'i',
    [$userId]
);

/* =========================================================
   RECENT PRODUCTS
========================================================= */

$productsResult = false;

$productSql = "
    SELECT
        p.id,
        p.title,
        p.description,
        p.price,
        p.product_condition,
        p.image,
        p.product_age,
        p.created_at,
        p.user_id,
        u.name AS seller_name
    FROM products p
    LEFT JOIN users u ON u.id = p.user_id
    ORDER BY p.id DESC
    LIMIT 6
";

try {
    $productsResult = $conn->query($productSql);
} catch (Throwable $e) {
    $productsResult = false;
}

/* =========================================================
   RECENT SKILLS
========================================================= */

$skillsResult = false;

$skillSql = "
    SELECT
        s.id,
        s.user_id,
        s.title,
        s.category,
        s.description,
        s.experience,
        s.availability,
        s.image,
        s.price,
        s.created_at,
        u.name AS student_name
    FROM skills s
    LEFT JOIN users u ON u.id = s.user_id
    ORDER BY s.id DESC
    LIMIT 6
";

try {
    $skillsResult = $conn->query($skillSql);
} catch (Throwable $e) {
    $skillsResult = false;
}

$initial = getInitial($userName);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Dashboard | EduTrade PRO</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>
:root {
    --bg: #030712;
    --panel: #0b1220;
    --sidebar: 260px;
    --border: rgba(255,255,255,.075);
    --muted: #8492a9;
    --text: #f1f5f9;
    --cyan: #22d3ee;
    --purple: #a78bfa;
    --pink: #f472b6;
    --green: #4ade80;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
    scroll-padding-top: 25px;
}

body {
    min-height: 100vh;
    overflow-x: hidden;
    color: var(--text);
    background:
        radial-gradient(ellipse at 80% 0%, rgba(79,70,229,.12), transparent 35%),
        radial-gradient(ellipse at 10% 45%, rgba(6,182,212,.06), transparent 35%),
        var(--bg);
    font-family: 'Inter', sans-serif;
    font-size: 13px;
}

a {
    color: inherit;
}

button,
input {
    font: inherit;
}

button,
a {
    -webkit-tap-highlight-color: transparent;
}

button:focus-visible,
a:focus-visible,
input:focus-visible {
    outline: 2px solid var(--cyan);
    outline-offset: 3px;
}

.app {
    min-height: 100vh;
}

.sidebar {
    position: fixed;
    z-index: 1600;
    inset: 0 auto 0 0;
    width: var(--sidebar);
    padding: 22px 15px;
    overflow-y: auto;
    background: rgba(7,13,25,.96);
    border-right: 1px solid var(--border);
    backdrop-filter: blur(24px);
    transition: transform .3s ease;
}

.brand {
    display: flex;
    align-items: center;
    gap: 11px;
    padding: 5px 8px 26px;
}

.brand-icon {
    width: 41px;
    height: 41px;
    display: grid;
    place-items: center;
    border-radius: 13px;
    color: white;
    font-size: 18px;
    background: linear-gradient(135deg,#06b6d4,#6366f1 65%,#a855f7);
    box-shadow: 0 8px 26px rgba(99,102,241,.24);
}

.brand-name {
    font-family: 'Poppins', sans-serif;
    font-size: 19px;
    font-weight: 900;
    letter-spacing: -.7px;
}

.brand-pro {
    margin-left: 4px;
    padding: 3px 5px;
    border-radius: 5px;
    color: #67e8f9;
    background: rgba(34,211,238,.10);
    font-size: 8px;
    letter-spacing: .5px;
    vertical-align: middle;
}

.nav-section-title {
    margin: 20px 10px 8px;
    color: #526078;
    font-size: 9px;
    font-weight: 800;
    letter-spacing: 1.4px;
    text-transform: uppercase;
}

.nav-link {
    position: relative;
    display: flex;
    align-items: center;
    gap: 12px;
    min-height: 43px;
    margin: 3px 0;
    padding: 11px 12px;
    border: 1px solid transparent;
    border-radius: 11px;
    color: #93a1b7;
    text-decoration: none;
    font-size: 11px;
    font-weight: 600;
    transition: .22s ease;
}

.nav-link > i {
    width: 17px;
    text-align: center;
    color: #64748b;
    font-size: 13px;
}

.nav-link:hover {
    color: white;
    background: rgba(255,255,255,.045);
    border-color: var(--border);
}

.nav-link:hover > i {
    color: var(--cyan);
}

.nav-link.active {
    color: white;
    border-color: rgba(34,211,238,.13);
    background: linear-gradient(100deg,rgba(6,182,212,.15),rgba(99,102,241,.09));
}

.nav-link.active > i {
    color: var(--cyan);
}

.nav-badge {
    min-width: 20px;
    margin-left: auto;
    padding: 4px 6px;
    border-radius: 7px;
    color: #67e8f9;
    background: rgba(34,211,238,.10);
    font-size: 9px;
    text-align: center;
}

.sidebar-profile {
    margin-top: 24px;
    padding: 13px 8px;
    border-top: 1px solid var(--border);
}

.sidebar-profile-inner {
    display: flex;
    align-items: center;
    gap: 10px;
    min-width: 0;
}

.avatar,
.seller-avatar,
.profile-avatar {
    display: grid;
    flex-shrink: 0;
    place-items: center;
    color: white;
    background: linear-gradient(135deg,#06b6d4,#6366f1,#a855f7);
    font-weight: 900;
}

.avatar {
    width: 37px;
    height: 37px;
    border-radius: 12px;
}

.sidebar-profile strong {
    display: block;
    max-width: 145px;
    overflow: hidden;
    color: #e2e8f0;
    font-size: 11px;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.sidebar-profile span {
    display: block;
    margin-top: 4px;
    color: #64748b;
    font-size: 9px;
}

.main {
    width: calc(100% - var(--sidebar));
    min-width: 0;
    margin-left: var(--sidebar);
    padding: 25px 30px 28px;
}

.topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 27px;
}

.top-left {
    display: flex;
    align-items: center;
    gap: 13px;
    min-width: 0;
}

.page-title {
    font-family: 'Poppins', sans-serif;
    font-size: 22px;
    font-weight: 800;
    letter-spacing: -.7px;
}

.page-subtitle {
    margin-top: 5px;
    color: #738198;
    font-size: 10px;
}

.mobile-menu {
    display: none;
    width: 39px;
    height: 39px;
    border: 1px solid var(--border);
    border-radius: 11px;
    color: white;
    background: #101827;
    cursor: pointer;
}

.search-wrapper {
    width: min(320px,32%);
}

.search {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 11px 14px;
    border: 1px solid var(--border);
    border-radius: 12px;
    background: rgba(255,255,255,.025);
}

.search i {
    color: #64748b;
}

.search input {
    width: 100%;
    border: 0;
    outline: 0;
    color: white;
    background: transparent;
    font-size: 10px;
}

.search input::placeholder {
    color: #64748b;
}

.top-actions {
    display: flex;
    gap: 9px;
}

.top-btn {
    position: relative;
    display: grid;
    width: 39px;
    height: 39px;
    place-items: center;
    border: 1px solid var(--border);
    border-radius: 12px;
    color: #aab6c8;
    background: rgba(255,255,255,.03);
    text-decoration: none;
    cursor: pointer;
    transition: .2s;
}

.top-btn:hover {
    color: white;
    border-color: rgba(34,211,238,.25);
    background: rgba(34,211,238,.08);
}

.notification-dot {
    position: absolute;
    top: 8px;
    right: 8px;
    width: 7px;
    height: 7px;
    border: 1px solid var(--bg);
    border-radius: 50%;
    background: #fb7185;
}

.hero {
    position: relative;
    isolation: isolate;
    overflow: hidden;
    padding: 35px;
    border: 1px solid rgba(129,140,248,.18);
    border-radius: 24px;
    background:
        radial-gradient(ellipse at 85% 20%,rgba(168,85,247,.20),transparent 35%),
        radial-gradient(ellipse at 65% 110%,rgba(6,182,212,.15),transparent 42%),
        linear-gradient(115deg,#101b31,#101326 60%,#15132a);
    box-shadow: 0 20px 60px rgba(0,0,0,.16);
}

.hero::after {
    position: absolute;
    z-index: -1;
    top: -120px;
    right: -70px;
    width: 320px;
    height: 320px;
    border: 1px solid rgba(165,180,252,.10);
    border-radius: 50%;
    box-shadow: 0 0 0 30px rgba(165,180,252,.025),0 0 0 70px rgba(165,180,252,.02);
    content: "";
}

.hero-content {
    position: relative;
    z-index: 1;
    max-width: 680px;
}

.hero-tag {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 7px 11px;
    border: 1px solid rgba(103,232,249,.16);
    border-radius: 20px;
    color: #67e8f9;
    background: rgba(34,211,238,.07);
    font-size: 9px;
    font-weight: 800;
}

.hero h1 {
    margin-top: 20px;
    font-family: 'Poppins', sans-serif;
    font-size: clamp(27px,3vw,40px);
    font-weight: 900;
    line-height: 1.25;
    letter-spacing: -1.5px;
}

.gradient {
    color: transparent;
    background: linear-gradient(90deg,#67e8f9,#a5b4fc,#e879f9);
    -webkit-background-clip: text;
    background-clip: text;
}

.hero-description {
    max-width: 590px;
    margin-top: 13px;
    color: #9aa8bf;
    font-size: 11px;
    line-height: 1.9;
}

.hero-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 24px;
}

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 9px;
    min-height: 41px;
    padding: 11px 15px;
    border: 1px solid transparent;
    border-radius: 11px;
    text-decoration: none;
    font-size: 10px;
    font-weight: 800;
    transition: .22s ease;
    cursor: pointer;
}

.btn:hover {
    transform: translateY(-2px);
}

.btn-primary {
    color: #04121a;
    background: linear-gradient(110deg,#67e8f9,#22d3ee);
    box-shadow: 0 8px 25px rgba(34,211,238,.13);
}

.btn-primary:hover {
    box-shadow: 0 12px 30px rgba(34,211,238,.23);
}

.btn-secondary {
    color: #e2e8f0;
    border-color: var(--border);
    background: rgba(255,255,255,.045);
}

.btn-secondary:hover {
    border-color: rgba(165,180,252,.25);
    background: rgba(255,255,255,.08);
}

.stats {
    display: grid;
    grid-template-columns: repeat(4,minmax(0,1fr));
    gap: 14px;
    margin-top: 20px;
}

.stat {
    min-width: 0;
    padding: 18px;
    border: 1px solid var(--border);
    border-radius: 17px;
    background: linear-gradient(145deg,rgba(255,255,255,.045),rgba(255,255,255,.018));
    transition: .25s;
}

.stat:hover {
    transform: translateY(-3px);
    border-color: rgba(34,211,238,.18);
}

.stat-top {
    display: flex;
    justify-content: space-between;
}

.stat-icon {
    display: grid;
    width: 39px;
    height: 39px;
    place-items: center;
    border-radius: 12px;
    font-size: 15px;
}

.stat-icon.blue {
    color: #67e8f9;
    background: rgba(34,211,238,.11);
}

.stat-icon.purple {
    color: #c4b5fd;
    background: rgba(167,139,250,.12);
}

.stat-icon.pink {
    color: #f9a8d4;
    background: rgba(244,114,182,.11);
}

.stat-icon.green {
    color: #86efac;
    background: rgba(74,222,128,.10);
}

.stat-number {
    margin-top: 17px;
    font-family: 'Poppins',sans-serif;
    font-size: 27px;
    font-weight: 900;
    letter-spacing: -1px;
}

.stat-label {
    margin-top: 3px;
    color: #cbd5e1;
    font-size: 10px;
    font-weight: 700;
}

.stat-note {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-top: 11px;
    color: #718096;
    font-size: 9px;
}

.stat-note i {
    color: var(--green);
}

.section {
    margin-top: 31px;
}

.section-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 16px;
}

.section-title {
    font-family: 'Poppins',sans-serif;
    font-size: 17px;
    font-weight: 800;
    letter-spacing: -.3px;
}

.section-description {
    margin-top: 5px;
    color: #718096;
    font-size: 10px;
    line-height: 1.7;
}

.view-all {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
    color: #67e8f9;
    text-decoration: none;
    font-size: 10px;
    font-weight: 800;
}

.view-all:hover {
    color: white;
}

.quick-grid {
    display: grid;
    grid-template-columns: repeat(4,minmax(0,1fr));
    gap: 12px;
}

.quick-card {
    display: flex;
    align-items: center;
    gap: 12px;
    min-width: 0;
    padding: 16px 13px;
    border: 1px solid var(--border);
    border-radius: 15px;
    background: rgba(255,255,255,.025);
    text-decoration: none;
    transition: .25s ease;
}

.quick-card:hover {
    transform: translateY(-4px);
    border-color: rgba(34,211,238,.23);
    background: rgba(34,211,238,.045);
}

.quick-icon {
    display: grid;
    width: 40px;
    height: 40px;
    flex-shrink: 0;
    place-items: center;
    border-radius: 12px;
    color: #67e8f9;
    background: rgba(34,211,238,.10);
    font-size: 14px;
}

.quick-card:nth-child(2) .quick-icon {
    color: #c4b5fd;
    background: rgba(167,139,250,.12);
}

.quick-card:nth-child(3) .quick-icon {
    color: #f9a8d4;
    background: rgba(244,114,182,.10);
}

.quick-card:nth-child(4) .quick-icon {
    color: #86efac;
    background: rgba(74,222,128,.10);
}

.quick-card strong {
    display: block;
    color: #e2e8f0;
    font-size: 10px;
    line-height: 1.5;
}

.quick-card span {
    display: block;
    margin-top: 4px;
    color: #718096;
    font-size: 9px;
    line-height: 1.5;
}

.filter-bar {
    display: flex;
    flex-wrap: wrap;
    gap: 7px;
    margin-bottom: 15px;
}

.filter-btn {
    padding: 8px 12px;
    border: 1px solid var(--border);
    border-radius: 9px;
    color: #8b9ab0;
    background: rgba(255,255,255,.025);
    font-size: 9px;
    font-weight: 700;
    cursor: pointer;
    transition: .2s;
}

.filter-btn:hover,
.filter-btn.active {
    color: #67e8f9;
    border-color: rgba(34,211,238,.22);
    background: rgba(34,211,238,.09);
}

.product-grid {
    display: grid;
    grid-template-columns: repeat(3,minmax(0,1fr));
    gap: 14px;
}

.product-card {
    min-width: 0;
    overflow: hidden;
    border: 1px solid var(--border);
    border-radius: 17px;
    background: linear-gradient(155deg,rgba(255,255,255,.045),rgba(255,255,255,.018));
    text-decoration: none;
    transition: .3s ease;
}

.product-card:hover {
    transform: translateY(-5px);
    border-color: rgba(34,211,238,.23);
    box-shadow: 0 18px 40px rgba(0,0,0,.2);
}

.product-image {
    position: relative;
    display: grid;
    height: 170px;
    overflow: hidden;
    place-items: center;
    background:
        radial-gradient(circle at 50% 20%,rgba(99,102,241,.13),transparent 65%),
        #0c1424;
}

.product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform .5s ease;
}

.product-card:hover .product-image img {
    transform: scale(1.045);
}

.no-image {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    color: #334155;
    font-size: 34px;
}

.condition-badge,
.category-badge {
    position: absolute;
    top: 10px;
    padding: 6px 8px;
    border: 1px solid rgba(255,255,255,.10);
    border-radius: 7px;
    background: rgba(3,7,18,.78);
    backdrop-filter: blur(10px);
    font-size: 8px;
    font-weight: 800;
}

.condition-badge {
    left: 10px;
    color: #a7f3d0;
}

.category-badge {
    right: 10px;
    color: #a5b4fc;
}

.product-body {
    padding: 14px;
}

.product-title {
    overflow: hidden;
    color: #e5edf7;
    font-size: 12px;
    font-weight: 800;
    line-height: 1.6;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.product-description {
    display: -webkit-box;
    min-height: 32px;
    margin-top: 6px;
    overflow: hidden;
    color: #7e8ca3;
    font-size: 9px;
    line-height: 1.7;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
}

.product-bottom {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    margin-top: 12px;
}

.price {
    color: #67e8f9;
    font-family: 'Poppins',sans-serif;
    font-size: 16px;
    font-weight: 900;
}

.age {
    color: #64748b;
    font-size: 8px;
}

.seller {
    display: flex;
    align-items: center;
    gap: 7px;
    margin-top: 12px;
    padding-top: 11px;
    border-top: 1px solid rgba(255,255,255,.055);
}

.seller-avatar {
    width: 25px;
    height: 25px;
    border-radius: 8px;
    font-size: 9px;
}

.seller-name {
    overflow: hidden;
    color: #94a3b8;
    font-size: 9px;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.skill-grid {
    display: grid;
    grid-template-columns: repeat(3,minmax(0,1fr));
    gap: 14px;
}

.skill-card {
    position: relative;
    min-width: 0;
    overflow: hidden;
    padding: 18px;
    border: 1px solid var(--border);
    border-radius: 18px;
    background: linear-gradient(145deg,rgba(255,255,255,.055),rgba(255,255,255,.025));
    transition: .3s ease;
}

.skill-card:hover {
    transform: translateY(-5px);
    border-color: rgba(192,132,252,.25);
    box-shadow: 0 20px 45px rgba(0,0,0,.25);
}

.skill-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
}

.skill-icon {
    display: grid;
    width: 42px;
    height: 42px;
    flex-shrink: 0;
    place-items: center;
    border-radius: 12px;
    color: #c084fc;
    background: linear-gradient(135deg,rgba(168,85,247,.20),rgba(99,102,241,.12));
    font-size: 15px;
}

.available {
    max-width: 65%;
    padding: 5px 8px;
    overflow: hidden;
    border: 1px solid rgba(34,197,94,.12);
    border-radius: 20px;
    color: #4ade80;
    background: rgba(34,197,94,.07);
    font-size: 8px;
    font-weight: 800;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.skill-name {
    margin-top: 14px;
    overflow-wrap: anywhere;
    color: #e2e8f0;
    font-size: 13px;
    font-weight: 800;
}

.skill-description {
    display: -webkit-box;
    min-height: 44px;
    margin-top: 6px;
    overflow: hidden;
    color: #8492a9;
    font-size: 9px;
    line-height: 1.8;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 3;
}

.skill-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-top: 15px;
    padding-top: 12px;
    border-top: 1px solid rgba(255,255,255,.055);
}

.rating {
    overflow: hidden;
    color: #c4b5fd;
    font-size: 9px;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.hire-btn {
    flex-shrink: 0;
    padding: 8px 10px;
    border-radius: 8px;
    color: white;
    background: linear-gradient(135deg,#7c3aed,#6366f1);
    font-size: 9px;
    font-weight: 800;
    text-decoration: none;
    transition: .2s;
}

.hire-btn:hover {
    filter: brightness(1.15);
    transform: translateY(-1px);
}

.skill-message {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    margin-top: 10px;
    padding: 8px 10px;
    border: 1px solid rgba(34,211,238,.16);
    border-radius: 8px;
    color: #67e8f9;
    background: rgba(34,211,238,.06);
    font-size: 9px;
    font-weight: 700;
    text-decoration: none;
}

.bottom-grid {
    display: grid;
    grid-template-columns: 1.35fr .65fr;
    gap: 14px;
}

.info-card {
    min-width: 0;
    padding: 19px;
    border: 1px solid var(--border);
    border-radius: 18px;
    background: rgba(255,255,255,.035);
}

.info-card-title {
    font-size: 14px;
    font-weight: 900;
}

.info-card-subtitle {
    margin-top: 4px;
    color: #8492a9;
    font-size: 9px;
}

.activity {
    margin-top: 14px;
}

.activity-item {
    display: flex;
    gap: 11px;
    padding: 12px 0;
    border-bottom: 1px solid rgba(255,255,255,.055);
}

.activity-item:last-child {
    border-bottom: 0;
}

.activity-icon {
    display: grid;
    width: 34px;
    height: 34px;
    flex-shrink: 0;
    place-items: center;
    border-radius: 10px;
    color: #818cf8;
    background: rgba(99,102,241,.10);
    font-size: 11px;
}

.activity-item strong {
    display: block;
    color: #dbe5f2;
    font-size: 10px;
}

.activity-item span {
    display: block;
    margin-top: 4px;
    color: #8492a9;
    font-size: 9px;
    line-height: 1.7;
}

.profile-user {
    display: flex;
    align-items: center;
    gap: 12px;
    min-width: 0;
}

.profile-avatar {
    width: 48px;
    height: 48px;
    border-radius: 15px;
    font-size: 17px;
}

.profile-user strong {
    display: block;
    overflow-wrap: anywhere;
    font-size: 12px;
}

.profile-user span {
    display: block;
    margin-top: 4px;
    overflow-wrap: anywhere;
    color: #8492a9;
    font-size: 9px;
}

.profile-divider {
    height: 1px;
    margin: 18px 0;
    background: rgba(255,255,255,.055);
}

.profile-stat {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 9px 0;
}

.profile-stat span {
    color: #8492a9;
    font-size: 9px;
}

.profile-stat strong {
    color: #e2e8f0;
    font-size: 10px;
}

.empty {
    grid-column: 1 / -1;
    padding: 38px 20px;
    border: 1px dashed rgba(255,255,255,.12);
    border-radius: 18px;
    background: rgba(255,255,255,.02);
    text-align: center;
}

.empty i {
    display: block;
    margin-bottom: 12px;
    color: #475569;
    font-size: 30px;
}

.empty p {
    margin-bottom: 18px;
    color: #8492a9;
    font-size: 10px;
    line-height: 1.7;
}

.footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-top: 38px;
    padding-top: 18px;
    border-top: 1px solid rgba(255,255,255,.05);
    color: #64748b;
    font-size: 9px;
}

.sidebar-overlay {
    display: none;
    position: fixed;
    z-index: 1500;
    inset: 0;
    background: rgba(0,0,0,.60);
    backdrop-filter: blur(4px);
}

.sidebar-overlay.show {
    display: block;
}

.reveal {
    animation: reveal .6s ease both;
}

.delay-1 { animation-delay: .08s; }
.delay-2 { animation-delay: .16s; }
.delay-3 { animation-delay: .24s; }
.delay-4 { animation-delay: .32s; }

@keyframes reveal {
    from {
        opacity: 0;
        transform: translateY(15px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (max-width: 1250px) {
    .main {
        padding-right: 22px;
        padding-left: 22px;
    }

    .stats {
        grid-template-columns: repeat(2,minmax(0,1fr));
    }

    .quick-grid {
        grid-template-columns: repeat(2,minmax(0,1fr));
    }

    .product-grid,
    .skill-grid {
        grid-template-columns: repeat(2,minmax(0,1fr));
    }
}

@media (max-width: 950px) {
    .sidebar {
        transform: translateX(-100%);
    }

    .sidebar.open {
        transform: translateX(0);
        box-shadow: 20px 0 60px rgba(0,0,0,.45);
    }

    .main {
        width: 100%;
        margin-left: 0;
        padding: 20px;
    }

    .mobile-menu {
        display: grid;
    }

    .bottom-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 700px) {
    .topbar {
        align-items: flex-start;
    }

    .search-wrapper,
    .top-actions {
        display: none;
    }

    .hero {
        padding: 25px;
    }

    .hero h1 {
        font-size: 28px;
    }

    .product-grid,
    .skill-grid {
        grid-template-columns: repeat(2,minmax(0,1fr));
    }

    .product-image {
        height: 145px;
    }
}

@media (max-width: 520px) {
    .main {
        padding: 15px;
    }

    .page-title {
        font-size: 18px;
    }

    .page-subtitle {
        max-width: 250px;
        font-size: 9px;
        line-height: 1.6;
    }

    .stats,
    .quick-grid,
    .product-grid,
    .skill-grid {
        grid-template-columns: 1fr;
    }

    .hero {
        padding: 22px;
    }

    .hero h1 {
        font-size: 25px;
    }

    .hero-description {
        font-size: 10px;
    }

    .hero-actions {
        flex-direction: column;
    }

    .hero-actions .btn {
        width: 100%;
    }

    .section-head {
        align-items: flex-start;
        flex-direction: column;
    }

    .product-image {
        height: 195px;
    }

    .footer {
        align-items: flex-start;
        flex-direction: column;
    }
}

@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        scroll-behavior: auto !important;
        animation-duration: .01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: .01ms !important;
    }
}
</style>
</head>

<body>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<div class="app">

<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">

    <div class="brand">
        <div class="brand-icon">
            <i class="fa-solid fa-graduation-cap"></i>
        </div>
        <div class="brand-name">
            EduTrade <span class="brand-pro">PRO</span>
        </div>
    </div>

    <div class="nav-section-title">Main</div>

    <a href="dashboard.php" class="nav-link active">
        <i class="fa-solid fa-house"></i>
        <span>Overview</span>
    </a>

    <a href="marketplace.php" class="nav-link">
        <i class="fa-solid fa-store"></i>
        <span>Marketplace</span>
    </a>

    <a href="skills.php" class="nav-link">
        <i class="fa-solid fa-wand-magic-sparkles"></i>
        <span>Skill Hub</span>
    </a>

    <div class="nav-section-title">Campus Marketplace</div>

    <a href="marketplace.php" class="nav-link">
        <i class="fa-solid fa-book"></i>
        <span>Books</span>
    </a>

    <a href="marketplace.php" class="nav-link">
        <i class="fa-solid fa-flask"></i>
        <span>Lab Equipment</span>
    </a>

    <a href="marketplace.php" class="nav-link">
        <i class="fa-solid fa-laptop"></i>
        <span>Electronics</span>
    </a>

    <a href="marketplace.php" class="nav-link">
        <i class="fa-solid fa-briefcase"></i>
        <span>Bags &amp; Stationery</span>
    </a>

    <div class="nav-section-title">Create</div>

    <a href="add_product.php" class="nav-link">
        <i class="fa-solid fa-plus"></i>
        <span>Sell Product</span>
    </a>

    <a href="add_skills.php" class="nav-link">
        <i class="fa-solid fa-star"></i>
        <span>Add Your Skill</span>
    </a>

    <div class="nav-section-title">My Space</div>

    <a href="wishlist.php" class="nav-link">
        <i class="fa-regular fa-heart"></i>
        <span>Wishlist</span>
        <?php if ($savedProducts > 0): ?>
            <span class="nav-badge"><?= number_format($savedProducts) ?></span>
        <?php endif; ?>
    </a>

    <a href="hire_requests.php" class="nav-link">
        <i class="fa-solid fa-paper-plane"></i>
        <span>Hire / Requests</span>
        <?php if ($incomingRequests > 0): ?>
            <span class="nav-badge"><?= number_format($incomingRequests) ?></span>
        <?php endif; ?>
    </a>

    <!-- Messages page: conversations open with messages.php?with=USER_ID -->
    <a href="messages.php" class="nav-link">
        <i class="fa-regular fa-comments"></i>
        <span>Messages</span>
    </a>

    <div class="sidebar-profile">
        <div class="sidebar-profile-inner">
            <div class="avatar"><?= clean($initial) ?></div>
            <div>
                <strong><?= clean($userName) ?></strong>
                <span>Student Account</span>
            </div>
        </div>
    </div>

    <a href="../includes/auth.php?logout=true"
       class="nav-link"
       style="color:#fb7185;margin-top:8px;">
        <i class="fa-solid fa-right-from-bracket"></i>
        <span>Logout</span>
    </a>

</aside>

<!-- MAIN -->
<main class="main">

    <!-- TOPBAR -->
    <header class="topbar">

        <div class="top-left">
            <button class="mobile-menu"
                    id="mobileMenu"
                    aria-label="Open menu"
                    type="button">
                <i class="fa-solid fa-bars"></i>
            </button>

            <div>
                <div class="page-title">Student Dashboard</div>
                <div class="page-subtitle">
                    Your campus marketplace &amp; student skill network
                </div>
            </div>
        </div>

        <div class="search-wrapper">
            <div class="search">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text"
                       id="globalSearch"
                       placeholder="Search products..."
                       autocomplete="off">
            </div>
        </div>

        <div class="top-actions">
            <a href="hire_requests.php" class="top-btn" title="Hire Requests">
                <i class="fa-regular fa-bell"></i>
                <?php if ($incomingRequests > 0): ?>
                    <span class="notification-dot"></span>
                <?php endif; ?>
            </a>

            <a href="messages.php" class="top-btn" title="Messages">
                <i class="fa-regular fa-comments"></i>
            </a>

            <button class="top-btn"
                    title="My Profile"
                    type="button"
                    id="profileButton">
                <i class="fa-regular fa-user"></i>
            </button>
        </div>

    </header>

    <!-- HERO -->
    <section class="hero reveal">
        <div class="hero-content">

            <span class="hero-tag">
                <i class="fa-solid fa-sparkles"></i>
                EduTrade Campus Network
            </span>

            <h1>
                Welcome back,
                <span class="gradient"><?= clean($userName) ?></span>
                👋
            </h1>

            <p class="hero-description">
                Buy what you need, sell what you no longer use,
                showcase your skills and connect with students
                across your campus — all in one place.
            </p>

            <div class="hero-actions">
                <a href="marketplace.php" class="btn btn-primary">
                    <i class="fa-solid fa-store"></i>
                    Explore Marketplace
                </a>

                <a href="skills.php" class="btn btn-secondary">
                    <i class="fa-solid fa-wand-magic-sparkles"></i>
                    Explore Skill Hub
                </a>

                <a href="add_product.php" class="btn btn-secondary">
                    <i class="fa-solid fa-plus"></i>
                    Sell Something
                </a>
            </div>

        </div>
    </section>

    <!-- STATISTICS -->
    <section class="stats">

        <div class="stat reveal delay-1">
            <div class="stat-top">
                <div class="stat-icon blue">
                    <i class="fa-solid fa-box-open"></i>
                </div>
            </div>
            <div class="stat-number"><?= number_format($myProducts) ?></div>
            <div class="stat-label">My Products</div>
            <div class="stat-note">
                <i class="fa-solid fa-arrow-up"></i>
                Your listings
            </div>
        </div>

        <div class="stat reveal delay-2">
            <div class="stat-top">
                <div class="stat-icon purple">
                    <i class="fa-solid fa-wand-magic-sparkles"></i>
                </div>
            </div>
            <div class="stat-number"><?= number_format($totalSkills) ?></div>
            <div class="stat-label">Skills Available</div>
            <div class="stat-note">
                <i class="fa-solid fa-bolt"></i>
                Skill Hub
            </div>
        </div>

        <div class="stat reveal delay-3">
            <div class="stat-top">
                <div class="stat-icon pink">
                    <i class="fa-solid fa-store"></i>
                </div>
            </div>
            <div class="stat-number"><?= number_format($totalProducts) ?></div>
            <div class="stat-label">Marketplace Products</div>
            <div class="stat-note">
                <i class="fa-solid fa-chart-line"></i>
                Campus listings
            </div>
        </div>

        <div class="stat reveal delay-4">
            <div class="stat-top">
                <div class="stat-icon green">
                    <i class="fa-solid fa-users"></i>
                </div>
            </div>
            <div class="stat-number"><?= number_format($totalStudents) ?></div>
            <div class="stat-label">Student Community</div>
            <div class="stat-note">
                <i class="fa-solid fa-circle-check"></i>
                Connected
            </div>
        </div>

    </section>

    <!-- QUICK ACTIONS -->
    <section class="section">

        <div class="section-head">
            <div>
                <div class="section-title">Quick Actions</div>
                <div class="section-description">
                    Everything important is one click away
                </div>
            </div>
        </div>

        <div class="quick-grid">

            <a href="add_product.php" class="quick-card">
                <div class="quick-icon"><i class="fa-solid fa-plus"></i></div>
                <div>
                    <strong>Sell a Product</strong>
                    <span>Create a campus listing</span>
                </div>
            </a>

            <a href="add_skills.php" class="quick-card">
                <div class="quick-icon"><i class="fa-solid fa-star"></i></div>
                <div>
                    <strong>Add Your Skill</strong>
                    <span>Showcase your talent</span>
                </div>
            </a>

            <a href="marketplace.php" class="quick-card">
                <div class="quick-icon"><i class="fa-solid fa-magnifying-glass"></i></div>
                <div>
                    <strong>Find Products</strong>
                    <span>Browse campus items</span>
                </div>
            </a>

            <a href="skills.php" class="quick-card">
                <div class="quick-icon"><i class="fa-solid fa-user-group"></i></div>
                <div>
                    <strong>Find Talent</strong>
                    <span>Hire a student</span>
                </div>
            </a>

            <a href="messages.php" class="quick-card">
                <div class="quick-icon"><i class="fa-regular fa-comments"></i></div>
                <div>
                    <strong>Messages</strong>
                    <span>Chat with other students</span>
                </div>
            </a>

        </div>
    </section>

    <!-- MARKETPLACE -->
    <section class="section">

        <div class="section-head">
            <div>
                <div class="section-title">🛒 Marketplace</div>
                <div class="section-description">
                    Latest products listed by students
                </div>
            </div>

            <a href="marketplace.php" class="view-all">
                View Marketplace
                <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>

        <div class="filter-bar">
            <button type="button" class="filter-btn active" data-filter="all">Latest</button>
            <button type="button" class="filter-btn" data-filter="Books">Books</button>
            <button type="button" class="filter-btn" data-filter="Lab">Lab</button>
            <button type="button" class="filter-btn" data-filter="Electronics">Electronics</button>
            <button type="button" class="filter-btn" data-filter="Stationery">Bags &amp; Stationery</button>
            <button type="button" class="filter-btn" data-filter="Other">Other</button>
        </div>

        <div class="product-grid" id="productGrid">

            <?php if ($productsResult && $productsResult->num_rows > 0): ?>

                <?php while ($product = $productsResult->fetch_assoc()): ?>

                    <?php
                    $productId = (int)($product['id'] ?? 0);
                    $productTitle = $product['title'] ?? 'Untitled Product';
                    $description = $product['description'] ?? 'No description available.';
                    $price = (float)($product['price'] ?? 0);
                    $condition = $product['product_condition'] ?? 'Used';
                    $age = $product['product_age'] ?? '';
                    $imagePath = getProductImage($product['image'] ?? '');
                    $seller = $product['seller_name'] ?? 'Student';
                    $sellerId = (int)($product['user_id'] ?? 0);
                    $category = getCategoryFromProduct($productTitle, $description);
                    ?>

                    <a href="product_details.php?id=<?= $productId ?>"
                       class="product-card"
                       data-category="<?= clean($category) ?>">

                        <div class="product-image">

                            <?php if ($imagePath !== ''): ?>
                                <img src="<?= clean($imagePath) ?>"
                                     alt="<?= clean($productTitle) ?>"
                                     loading="lazy">
                                <div class="no-image" style="display:none;">
                                    <i class="fa-solid fa-box-open"></i>
                                </div>
                            <?php else: ?>
                                <div class="no-image">
                                    <i class="fa-solid fa-box-open"></i>
                                </div>
                            <?php endif; ?>

                            <span class="condition-badge"><?= clean($condition) ?></span>
                            <span class="category-badge"><?= clean($category) ?></span>

                        </div>

                        <div class="product-body">

                            <div class="product-title"><?= clean($productTitle) ?></div>

                            <div class="product-description">
                                <?= clean($description) ?>
                            </div>

                            <div class="product-bottom">
                                <div class="price">
                                    ₹<?= number_format($price, 0) ?>
                                </div>

                                <?php if (trim((string)$age) !== ''): ?>
                                    <div class="age">
                                        <i class="fa-regular fa-clock"></i>
                                        <?= clean($age) ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="seller">
                                <div class="seller-avatar"><?= clean(getInitial($seller)) ?></div>
                                <div class="seller-name"><?= clean($seller) ?></div>
                            </div>

                        </div>
                    </a>

                <?php endwhile; ?>

            <?php else: ?>

                <div class="empty">
                    <i class="fa-solid fa-box-open"></i>
                    <p>No marketplace products have been listed yet.</p>
                    <a href="add_product.php" class="btn btn-primary">
                        <i class="fa-solid fa-plus"></i>
                        Add First Product
                    </a>
                </div>

            <?php endif; ?>

        </div>
    </section>

    <!-- SKILL HUB -->
    <section class="section">

        <div class="section-head">
            <div>
                <div class="section-title">🎯 Skill Hub</div>
                <div class="section-description">
                    Discover students who can help with your projects
                </div>
            </div>

            <a href="skills.php" class="view-all">
                Explore Skill Hub
                <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>

        <div class="skill-grid">

            <?php if ($skillsResult && $skillsResult->num_rows > 0): ?>

                <?php while ($skill = $skillsResult->fetch_assoc()): ?>

                    <?php
                    $skillId = (int)($skill['id'] ?? 0);
                    $skillName = $skill['title'] ?? 'Student Skill';
                    $skillDescription = $skill['description'] ?? 'Student offering this skill.';
                    $skillCategory = $skill['category'] ?? 'Other';
                    $skillAvailability = $skill['availability'] ?? 'Available';
                    $skillProvider = $skill['student_name'] ?? 'Student';
                    $skillProviderId = (int)($skill['user_id'] ?? 0);
                    $skillIcon = getSkillIcon($skillName, $skillDescription, $skillCategory);
                    ?>

                    <article class="skill-card">

                        <div class="skill-top">
                            <div class="skill-icon">
                                <i class="fa-solid <?= clean($skillIcon) ?>"></i>
                            </div>

                            <span class="available"
                                  style="<?= strtolower(trim((string)$skillAvailability)) !== 'available'
                                      ? 'color:#fbbf24;background:rgba(245,158,11,.08);border-color:rgba(245,158,11,.15);'
                                      : '' ?>">
                                <i class="fa-solid fa-circle"></i>
                                <?= clean($skillAvailability) ?>
                            </span>
                        </div>

                        <div class="skill-name"><?= clean($skillName) ?></div>

                        <div class="skill-description">
                            <?= clean($skillDescription) ?>
                        </div>

                        <div class="skill-footer">
                            <div class="rating">
                                <i class="fa-solid fa-tag"></i>
                                <?= clean($skillCategory) ?>
                            </div>

                            <a href="skill_profile.php?id=<?= $skillId ?>"
                               class="hire-btn">
                                View / Hire
                            </a>
                        </div>

                        <?php if ($skillProviderId > 0 && $skillProviderId !== $userId): ?>
                            <a class="skill-message"
                               href="messages.php?with=<?= $skillProviderId ?>">
                                <i class="fa-regular fa-comments"></i>
                                Message <?= clean($skillProvider) ?>
                            </a>
                        <?php endif; ?>

                    </article>

                <?php endwhile; ?>

            <?php else: ?>

                <div class="empty">
                    <i class="fa-solid fa-wand-magic-sparkles"></i>
                    <p>No student skills have been added yet.</p>
                    <a href="add_skills.php" class="btn btn-primary">
                        <i class="fa-solid fa-star"></i>
                        Add Your First Skill
                    </a>
                </div>

            <?php endif; ?>

        </div>
    </section>

    <!-- ACTIVITY + PROFILE -->
    <section class="section" id="profile">

        <div class="bottom-grid">

            <div class="info-card">

                <div class="info-card-title">Recent Activity</div>
                <div class="info-card-subtitle">Your EduTrade activity center</div>

                <div class="activity">

                    <div class="activity-item">
                        <div class="activity-icon"><i class="fa-solid fa-store"></i></div>
                        <div>
                            <strong>Marketplace is ready</strong>
                            <span>Browse books, lab equipment, electronics and stationery.</span>
                        </div>
                    </div>

                    <div class="activity-item">
                        <div class="activity-icon"><i class="fa-solid fa-wand-magic-sparkles"></i></div>
                        <div>
                            <strong>Skill Hub is active</strong>
                            <span>Discover talented students and hire them for your work.</span>
                        </div>
                    </div>

                    <div class="activity-item">
                        <div class="activity-icon"><i class="fa-solid fa-heart"></i></div>
                        <div>
                            <strong>Your saved items</strong>
                            <span>
                                You currently have <?= number_format($savedProducts) ?>
                                saved products.
                            </span>
                        </div>
                    </div>

                    <div class="activity-item">
                        <div class="activity-icon"><i class="fa-solid fa-paper-plane"></i></div>
                        <div>
                            <strong>Hire &amp; Requests</strong>
                            <span>Manage your student project requests from the Hire / Requests page.</span>
                        </div>
                    </div>

                    <div class="activity-item">
                        <div class="activity-icon"><i class="fa-regular fa-comments"></i></div>
                        <div>
                            <strong>Student Messages</strong>
                            <span>Open Messages to continue conversations with other students.</span>
                            <a href="messages.php" class="skill-message">
                                <i class="fa-regular fa-comments"></i>
                                Open Messages
                            </a>
                        </div>
                    </div>

                </div>
            </div>

            <div class="info-card">

                <div class="profile-user">
                    <div class="profile-avatar"><?= clean($initial) ?></div>
                    <div>
                        <strong><?= clean($userName) ?></strong>
                        <span><?= clean($userEmail !== '' ? $userEmail : 'Student Account') ?></span>
                    </div>
                </div>

                <div class="profile-divider"></div>

                <div class="profile-stat">
                    <span>My Products</span>
                    <strong><?= number_format($myProducts) ?></strong>
                </div>

                <div class="profile-stat">
                    <span>My Skills</span>
                    <strong><?= number_format($mySkills) ?></strong>
                </div>

                <div class="profile-stat">
                    <span>Saved Products</span>
                    <strong><?= number_format($savedProducts) ?></strong>
                </div>

                <div class="profile-stat">
                    <span>Hire / Requests</span>
                    <strong><?= number_format($incomingRequests) ?></strong>
                </div>

                <div class="profile-stat">
                    <span>Marketplace</span>
                    <strong><?= number_format($totalProducts) ?></strong>
                </div>

                <div class="profile-stat">
                    <span>Student Community</span>
                    <strong><?= number_format($totalStudents) ?></strong>
                </div>

                <div style="margin-top:15px;">
                    <a href="#profile" class="btn btn-secondary" style="width:100%;">
                        <i class="fa-regular fa-user"></i>
                        My Profile
                    </a>
                </div>

            </div>

        </div>
    </section>

    <footer class="footer">
        <span>© <?= date('Y') ?> EduTrade PRO</span>
        <span>Learn • Trade • Grow 🚀</span>
    </footer>

</main>
</div>

<script>
/* =========================================================
   MOBILE SIDEBAR
========================================================= */
const sidebar = document.getElementById('sidebar');
const sidebarOverlay = document.getElementById('sidebarOverlay');
const mobileMenu = document.getElementById('mobileMenu');

function toggleSidebar() {
    sidebar.classList.toggle('open');
    sidebarOverlay.classList.toggle('show');
}

function closeSidebar() {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('show');
}

if (mobileMenu) {
    mobileMenu.addEventListener('click', toggleSidebar);
}

if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', closeSidebar);
}

document.querySelectorAll('.sidebar .nav-link').forEach(link => {
    link.addEventListener('click', () => {
        if (window.innerWidth <= 950) {
            closeSidebar();
        }
    });
});

document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
        closeSidebar();
    }
});

window.addEventListener('resize', () => {
    if (window.innerWidth > 950) {
        closeSidebar();
    }
});

/* =========================================================
   PROFILE BUTTON
========================================================= */
const profileButton = document.getElementById('profileButton');

if (profileButton) {
    profileButton.addEventListener('click', () => {
        const profile = document.getElementById('profile');

        if (profile) {
            profile.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
}

/* =========================================================
   PRODUCT FILTERS
========================================================= */
const filterButtons = document.querySelectorAll('.filter-btn');
const productCards = document.querySelectorAll('.product-card');
const searchInput = document.getElementById('globalSearch');

let activeCategory = 'all';
let searchValue = '';

function filterProducts() {
    productCards.forEach(card => {
        const category = card.dataset.category || 'Other';
        const content = card.innerText.toLowerCase();

        const categoryMatches =
            activeCategory === 'all' || category === activeCategory;

        const searchMatches = content.includes(searchValue);

        card.style.display =
            categoryMatches && searchMatches ? '' : 'none';
    });
}

filterButtons.forEach(button => {
    button.addEventListener('click', () => {
        filterButtons.forEach(item => item.classList.remove('active'));

        button.classList.add('active');
        activeCategory = button.dataset.filter || 'all';

        filterProducts();
    });
});

/* =========================================================
   GLOBAL SEARCH
========================================================= */
if (searchInput) {
    searchInput.addEventListener('input', () => {
        searchValue = searchInput.value.toLowerCase().trim();
        filterProducts();
    });
}

/* =========================================================
   PRODUCT IMAGE FALLBACK
========================================================= */
function showProductFallback(image) {
    image.style.display = 'none';

    const fallback = image.nextElementSibling;

    if (fallback && fallback.classList.contains('no-image')) {
        fallback.style.display = 'flex';
    }
}

document.querySelectorAll('.product-image img').forEach(image => {
    image.addEventListener('error', function () {
        showProductFallback(this);
    });

    // Handle images that already failed before listeners were attached.
    if (image.complete && image.naturalWidth === 0) {
        showProductFallback(image);
    }
});

/* =========================================================
   REVEAL ON SCROLL
========================================================= */
const revealElements = document.querySelectorAll(
    '.section, .stat, .quick-card, .product-card, .skill-card'
);

if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                revealObserver.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.08
    });

    revealElements.forEach(element => {
        revealObserver.observe(element);
    });
}
</script>

</body>
</html>