<?php
/* =========================================================
   EDU TRADE PRO
   ADD SKILL / STUDENT SKILL HUB
   File: pages/add_skills.php
========================================================= */

session_start();

/* ---------------------------------------------------------
   DATABASE
   Since this file is inside /pages/
--------------------------------------------------------- */

require_once "../config/db.php";


/* ---------------------------------------------------------
   LOGIN CHECK
--------------------------------------------------------- */

if (!isset($_SESSION['user_id'])) {
    header("Location: ../includes/login.php");
    exit();
}


/* ---------------------------------------------------------
   USER INFORMATION
--------------------------------------------------------- */

$userId = (int)($_SESSION['user_id'] ?? 0);

$userName = $_SESSION['name'] ?? '';
$userEmail = $_SESSION['email'] ?? ($_SESSION['user'] ?? '');


/* ---------------------------------------------------------
   GET USER DATA FROM DATABASE
--------------------------------------------------------- */

if ($userId > 0) {

    $userStmt = mysqli_prepare(
        $conn,
        "SELECT * FROM users WHERE id = ? LIMIT 1"
    );

    if ($userStmt) {

        mysqli_stmt_bind_param(
            $userStmt,
            "i",
            $userId
        );

        mysqli_stmt_execute($userStmt);

        $userResult = mysqli_stmt_get_result($userStmt);

        if ($userResult && mysqli_num_rows($userResult) > 0) {

            $userData = mysqli_fetch_assoc($userResult);

            if (!empty($userData['name'])) {
                $userName = $userData['name'];
            }

            if (!empty($userData['email'])) {
                $userEmail = $userData['email'];
            }
        }

        mysqli_stmt_close($userStmt);
    }
}


/* ---------------------------------------------------------
   HELPER
--------------------------------------------------------- */

function clean($value)
{
    return trim((string)$value);
}


/* ---------------------------------------------------------
   FORM VARIABLES
--------------------------------------------------------- */

$skillName       = '';
$category        = '';
$description     = '';
$experience      = '';
$skillLevel      = '';
$price           = '';
$serviceType     = '';
$availability    = '';

$contactMethod   = '';
$contactInfo     = '';

$portfolio       = '';
$linkedin        = '';
$github          = '';
$instagram       = '';

$successMessage  = '';
$errorMessage    = '';

$uploadedImage   = '';


/* ---------------------------------------------------------
   FORM SUBMISSION
--------------------------------------------------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    /* -----------------------------------------------------
       REQUIRED BASIC INFORMATION
    ----------------------------------------------------- */

    $skillName = clean($_POST['skill_name'] ?? '');
    $category = clean($_POST['category'] ?? '');
    $description = clean($_POST['description'] ?? '');

    $experience = clean($_POST['experience'] ?? '');
    $skillLevel = clean($_POST['skill_level'] ?? '');

    $price = clean($_POST['price'] ?? '');

    $serviceType = clean($_POST['service_type'] ?? '');
    $availability = clean($_POST['availability'] ?? '');


    /* -----------------------------------------------------
       CONTACT
    ----------------------------------------------------- */

    $contactMethod = clean($_POST['contact_method'] ?? '');
    $contactInfo = clean($_POST['contact_info'] ?? '');


    /* -----------------------------------------------------
       OPTIONAL SOCIAL / PORTFOLIO
    ----------------------------------------------------- */

    $portfolio = clean($_POST['portfolio'] ?? '');
    $linkedin = clean($_POST['linkedin'] ?? '');
    $github = clean($_POST['github'] ?? '');
    $instagram = clean($_POST['instagram'] ?? '');


    /* -----------------------------------------------------
       VALIDATION
    ----------------------------------------------------- */

    $errors = [];


    /* Skill Name */

    if ($skillName === '') {
        $errors[] = "Skill name is required.";
    } elseif (strlen($skillName) < 2) {
        $errors[] = "Skill name must contain at least 2 characters.";
    }


    /* Category */

    if ($category === '') {
        $errors[] = "Please select a skill category.";
    }


    /* Description */

    if ($description === '') {
        $errors[] = "Skill description is required.";
    } elseif (strlen($description) < 20) {
        $errors[] = "Skill description should contain at least 20 characters.";
    }


    /* Experience */

    if ($experience === '') {
        $errors[] = "Experience is required.";
    }


    /* Skill Level */

    $allowedLevels = [
        'Beginner',
        'Intermediate',
        'Advanced'
    ];

    if ($skillLevel === '') {
        $errors[] = "Please select your skill level.";
    } elseif (!in_array($skillLevel, $allowedLevels, true)) {
        $errors[] = "Invalid skill level selected.";
    }


    /* Price */

    if ($price === '') {
        $errors[] = "Expected price is required.";
    } elseif (!is_numeric($price) || (float)$price < 0) {
        $errors[] = "Please enter a valid price.";
    }


    /* Service Type */

    $allowedServices = [
        'Freelance',
        'Project Based',
        'Part Time',
        'One Time',
        'Free Help'
    ];

    if ($serviceType === '') {
        $errors[] = "Please select a service type.";
    } elseif (!in_array($serviceType, $allowedServices, true)) {
        $errors[] = "Invalid service type selected.";
    }


    /* Availability */

    $allowedAvailability = [
        'Available',
        'Busy',
        'Unavailable'
    ];

    if ($availability === '') {
        $errors[] = "Please select your availability.";
    } elseif (!in_array($availability, $allowedAvailability, true)) {
        $errors[] = "Invalid availability selected.";
    }


    /* -----------------------------------------------------
       CONTACT VALIDATION
    ----------------------------------------------------- */

    $allowedContacts = [
        'Phone',
        'Email',
        'WhatsApp'
    ];

    if ($contactMethod === '') {

        $errors[] = "Please select at least one contact method.";

    } elseif (!in_array($contactMethod, $allowedContacts, true)) {

        $errors[] = "Invalid contact method selected.";

    }


    if ($contactInfo === '') {

        $errors[] = "Contact information is required.";

    } else {

        /* PHONE */

        if ($contactMethod === 'Phone') {

            $phoneDigits = preg_replace('/[^0-9]/', '', $contactInfo);

            if (strlen($phoneDigits) < 10) {
                $errors[] = "Please enter a valid phone number.";
            }
        }


        /* WHATSAPP */

        if ($contactMethod === 'WhatsApp') {

            $phoneDigits = preg_replace('/[^0-9]/', '', $contactInfo);

            if (strlen($phoneDigits) < 10) {
                $errors[] = "Please enter a valid WhatsApp number.";
            }
        }


        /* EMAIL */

        if ($contactMethod === 'Email') {

            if (!filter_var($contactInfo, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Please enter a valid email address.";
            }
        }
    }


    /* -----------------------------------------------------
       OPTIONAL URL VALIDATION
    ----------------------------------------------------- */

    $optionalLinks = [
        'Portfolio' => $portfolio,
        'LinkedIn' => $linkedin,
        'GitHub' => $github,
        'Instagram' => $instagram
    ];


    foreach ($optionalLinks as $label => $url) {

        if ($url !== '') {

            if (!filter_var($url, FILTER_VALIDATE_URL)) {

                $errors[] =
                    $label .
                    " link is invalid. Please enter a complete URL.";
            }
        }
    }


    /* -----------------------------------------------------
       OPTIONAL IMAGE UPLOAD
    ----------------------------------------------------- */

    if (
        isset($_FILES['skill_image']) &&
        $_FILES['skill_image']['error'] !== UPLOAD_ERR_NO_FILE
    ) {

        if ($_FILES['skill_image']['error'] !== UPLOAD_ERR_OK) {

            $errors[] = "There was a problem uploading the skill image.";

        } else {

            $file = $_FILES['skill_image'];

            $maxSize = 5 * 1024 * 1024;

            if ($file['size'] > $maxSize) {

                $errors[] =
                    "Skill image must be smaller than 5 MB.";

            } else {

                $allowedMimeTypes = [
                    'image/jpeg',
                    'image/png',
                    'image/webp'
                ];

                $fileInfo = finfo_open(FILEINFO_MIME_TYPE);

                $mimeType = finfo_file(
                    $fileInfo,
                    $file['tmp_name']
                );

                finfo_close($fileInfo);

                if (!in_array($mimeType, $allowedMimeTypes, true)) {

                    $errors[] =
                        "Only JPG, PNG and WEBP images are allowed.";

                } else {

                    $extensionMap = [
                        'image/jpeg' => 'jpg',
                        'image/png' => 'png',
                        'image/webp' => 'webp'
                    ];

                    $extension = $extensionMap[$mimeType];

                    /*
                     * Upload folder:
                     *
                     * EduTrade/
                     * ├── pages/
                     * ├── config/
                     * └── uploads/
                     *     └── skills/
                     */

                    $uploadDirectory =
                        dirname(__DIR__) .
                        DIRECTORY_SEPARATOR .
                        "uploads" .
                        DIRECTORY_SEPARATOR .
                        "skills" .
                        DIRECTORY_SEPARATOR;


                    if (!is_dir($uploadDirectory)) {

                        if (!mkdir($uploadDirectory, 0777, true)) {

                            $errors[] =
                                "Unable to create the skill upload folder.";
                        }
                    }


                    if (empty($errors)) {

                        $safeName =
                            preg_replace(
                                '/[^a-zA-Z0-9_-]/',
                                '_',
                                $skillName
                            );

                        $uniqueName =
                            $safeName .
                            '_' .
                            $userId .
                            '_' .
                            time() .
                            '_' .
                            bin2hex(random_bytes(4)) .
                            '.' .
                            $extension;

                        $destination =
                            $uploadDirectory .
                            $uniqueName;


                        if (
                            move_uploaded_file(
                                $file['tmp_name'],
                                $destination
                            )
                        ) {

                            /*
                             * Relative path stored in database
                             */

                            $uploadedImage =
                                "uploads/skills/" .
                                $uniqueName;

                        } else {

                            $errors[] =
                                "Unable to save the uploaded image.";
                        }
                    }
                }
            }
        }
    }


    /* -----------------------------------------------------
       DATABASE INSERT
    ----------------------------------------------------- */

    if (empty($errors)) {


        /*
         * We support the EduTrade skill structure used
         * by the Skill Hub.
         *
         * Main fields:
         * user_id
         * title
         * category
         * description
         * experience
         * price
         * availability
         * image
         * contact_method
         * contact_info
         * portfolio
         * linkedin
         * github
         * instagram
         * service_type
         */


        /* -------------------------------------------------
           CHECK SKILLS TABLE
        ------------------------------------------------- */

        $tableCheck = mysqli_query(
            $conn,
            "SHOW TABLES LIKE 'skills'"
        );


        if (!$tableCheck || mysqli_num_rows($tableCheck) === 0) {

            $errors[] =
                "The 'skills' table does not exist in the EduTrade database.";

        } else {


            /* ---------------------------------------------
               GET EXISTING COLUMNS
            --------------------------------------------- */

            $columnResult = mysqli_query(
                $conn,
                "SHOW COLUMNS FROM skills"
            );

            $existingColumns = [];

            if ($columnResult) {

                while ($column = mysqli_fetch_assoc($columnResult)) {

                    $existingColumns[] =
                        $column['Field'];
                }
            }


            /*
             * Helper for choosing the column name that
             * already exists in your database.
             *
             * Example:
             *
             * New database -> title
             *
             * Older database -> skill_name
             */

            function firstExistingColumn(
                $existingColumns,
                $possibleColumns
            ) {

                foreach ($possibleColumns as $column) {

                    if (
                        in_array(
                            $column,
                            $existingColumns,
                            true
                        )
                    ) {
                        return $column;
                    }
                }

                return null;
            }


            /* ---------------------------------------------
               MAP YOUR EXISTING DATABASE
            --------------------------------------------- */

            $userColumn = firstExistingColumn(
                $existingColumns,
                [
                    'user_id',
                    'user_email'
                ]
            );


            $titleColumn = firstExistingColumn(
                $existingColumns,
                [
                    'title',
                    'skill_name',
                    'skill'
                ]
            );


            $categoryColumn = firstExistingColumn(
                $existingColumns,
                [
                    'category'
                ]
            );


            $descriptionColumn = firstExistingColumn(
                $existingColumns,
                [
                    'description'
                ]
            );


            $experienceColumn = firstExistingColumn(
                $existingColumns,
                [
                    'experience'
                ]
            );


            $priceColumn = firstExistingColumn(
                $existingColumns,
                [
                    'price'
                ]
            );


            $availabilityColumn = firstExistingColumn(
                $existingColumns,
                [
                    'availability'
                ]
            );


            $imageColumn = firstExistingColumn(
                $existingColumns,
                [
                    'image',
                    'skill_image'
                ]
            );


            $contactColumn = firstExistingColumn(
                $existingColumns,
                [
                    'contact'
                ]
            );


            $contactMethodColumn = firstExistingColumn(
                $existingColumns,
                [
                    'contact_method'
                ]
            );


            $contactInfoColumn = firstExistingColumn(
                $existingColumns,
                [
                    'contact_info'
                ]
            );


            $portfolioColumn = firstExistingColumn(
                $existingColumns,
                [
                    'portfolio'
                ]
            );


            $linkedinColumn = firstExistingColumn(
                $existingColumns,
                [
                    'linkedin'
                ]
            );


            $githubColumn = firstExistingColumn(
                $existingColumns,
                [
                    'github'
                ]
            );


            $instagramColumn = firstExistingColumn(
                $existingColumns,
                [
                    'instagram'
                ]
            );


            $serviceTypeColumn = firstExistingColumn(
                $existingColumns,
                [
                    'service_type'
                ]
            );


            /* ---------------------------------------------
               REQUIRED DATABASE FIELDS
            --------------------------------------------- */

            if (!$userColumn) {

                $errors[] =
                    "Your skills table does not contain a user identification column.";

            }


            if (!$titleColumn) {

                $errors[] =
                    "Your skills table does not contain a skill title column.";

            }


            if (!$descriptionColumn) {

                $errors[] =
                    "Your skills table does not contain a description column.";

            }


            if (!$priceColumn) {

                $errors[] =
                    "Your skills table does not contain a price column.";

            }


            /* ---------------------------------------------
               INSERT
            --------------------------------------------- */

            if (empty($errors)) {


                $columns = [];
                $values = [];
                $types = [];
                $params = [];


                /* USER */

                $columns[] = $userColumn;

                if ($userColumn === 'user_id') {

                    $values[] = '?';
                    $types[] = 'i';
                    $params[] = $userId;

                } else {

                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $userEmail;
                }


                /* TITLE */

                $columns[] = $titleColumn;
                $values[] = '?';
                $types[] = 's';
                $params[] = $skillName;


                /* CATEGORY */

                if ($categoryColumn) {

                    $columns[] = $categoryColumn;
                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $category;
                }


                /* DESCRIPTION */

                $columns[] = $descriptionColumn;
                $values[] = '?';
                $types[] = 's';
                $params[] = $description;


                /* EXPERIENCE */

                if ($experienceColumn) {

                    $columns[] = $experienceColumn;
                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $experience;
                }


                /* PRICE */

                $columns[] = $priceColumn;
                $values[] = '?';
                $types[] = 'd';
                $params[] = (float)$price;


                /* AVAILABILITY */

                if ($availabilityColumn) {

                    $columns[] = $availabilityColumn;
                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $availability;
                }


                /* IMAGE */

                if ($imageColumn) {

                    $columns[] = $imageColumn;
                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $uploadedImage;
                }


                /* CONTACT METHOD */

                if ($contactMethodColumn) {

                    $columns[] = $contactMethodColumn;
                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $contactMethod;
                }


                /* CONTACT INFO */

                if ($contactInfoColumn) {

                    $columns[] = $contactInfoColumn;
                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $contactInfo;
                }


                /*
                 * OLD DATABASE CONTACT COLUMN
                 *
                 * If your database only has "contact",
                 * save the selected contact information there.
                 */

                if (
                    !$contactInfoColumn &&
                    $contactColumn
                ) {

                    $columns[] = $contactColumn;
                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $contactInfo;
                }


                /* SERVICE TYPE */

                if ($serviceTypeColumn) {

                    $columns[] = $serviceTypeColumn;
                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $serviceType;
                }


                /* PORTFOLIO */

                if ($portfolioColumn) {

                    $columns[] = $portfolioColumn;
                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $portfolio;
                }


                /* LINKEDIN */

                if ($linkedinColumn) {

                    $columns[] = $linkedinColumn;
                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $linkedin;
                }


                /* GITHUB */

                if ($githubColumn) {

                    $columns[] = $githubColumn;
                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $github;
                }


                /* INSTAGRAM */

                if ($instagramColumn) {

                    $columns[] = $instagramColumn;
                    $values[] = '?';
                    $types[] = 's';
                    $params[] = $instagram;
                }


                /* -----------------------------------------
                   BUILD QUERY
                ----------------------------------------- */

                $columnString =
                    implode(
                        ', ',
                        array_map(
                            function ($column) {
                                return "`" . $column . "`";
                            },
                            $columns
                        )
                    );


                $valueString =
                    implode(
                        ', ',
                        $values
                    );


                $insertSQL =
                    "INSERT INTO skills
                    ($columnString)
                    VALUES
                    ($valueString)";


                $stmt = mysqli_prepare(
                    $conn,
                    $insertSQL
                );


                if (!$stmt) {

                    $errors[] =
                        "Database error: " .
                        mysqli_error($conn);

                } else {


                    $typeString =
                        implode(
                            '',
                            $types
                        );


                    /*
                     * mysqli_stmt_bind_param requires
                     * references, therefore create
                     * reference array.
                     */

                    $bindParams = [];

                    $bindParams[] = $typeString;

                    foreach ($params as $key => $value) {

                        $bindParams[] = &$params[$key];
                    }


                    call_user_func_array(
                        [
                            $stmt,
                            'bind_param'
                        ],
                        $bindParams
                    );


                    if (
                        mysqli_stmt_execute($stmt)
                    ) {

                        $successMessage =
                            "Your skill has been added successfully to EduTrade Skill Hub!";


                        /*
                         * Clear form
                         */

                        $skillName = '';
                        $category = '';
                        $description = '';
                        $experience = '';
                        $skillLevel = '';
                        $price = '';
                        $serviceType = '';
                        $availability = '';
                        $contactMethod = '';
                        $contactInfo = '';
                        $portfolio = '';
                        $linkedin = '';
                        $github = '';
                        $instagram = '';


                    } else {

                        $errors[] =
                            "Unable to add your skill: " .
                            mysqli_stmt_error($stmt);
                    }


                    mysqli_stmt_close($stmt);
                }
            }
        }
    }


    /* -----------------------------------------------------
       ERROR MESSAGE
    ----------------------------------------------------- */

    if (!empty($errors)) {

        $errorMessage =
            implode(
                '<br>',
                array_map(
                    'htmlspecialchars',
                    $errors
                )
            );
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Add Skill | EduTrade PRO</title>


<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap"
    rel="stylesheet"
>


<style>

/* =========================================================
   RESET
========================================================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}


html{
    scroll-behavior:smooth;
}


body{

    font-family:'Poppins',sans-serif;

    color:#f8fafc;

    min-height:100vh;

    background:

        radial-gradient(
            circle at 10% 10%,
            rgba(0,245,255,.13),
            transparent 25%
        ),

        radial-gradient(
            circle at 90% 15%,
            rgba(139,92,246,.16),
            transparent 28%
        ),

        radial-gradient(
            circle at 50% 100%,
            rgba(236,72,153,.08),
            transparent 30%
        ),

        #020617;

    overflow-x:hidden;
}


/* =========================================================
   BACKGROUND ORBS
========================================================= */

.orb{

    position:fixed;

    border-radius:50%;

    filter:blur(90px);

    pointer-events:none;

    opacity:.2;

    z-index:-1;

    animation:floatOrb 8s ease-in-out infinite;
}


.orb.one{

    width:280px;
    height:280px;

    background:#00e5ff;

    top:5%;
    left:-120px;
}


.orb.two{

    width:330px;
    height:330px;

    background:#8b5cf6;

    right:-140px;
    top:45%;

    animation-delay:2s;
}


.orb.three{

    width:240px;
    height:240px;

    background:#ec4899;

    bottom:-120px;
    left:45%;

    animation-delay:4s;
}


@keyframes floatOrb{

    0%,100%{
        transform:translateY(0) scale(1);
    }

    50%{
        transform:translateY(-30px) scale(1.08);
    }
}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar{

    position:fixed;

    top:0;
    left:0;

    width:250px;
    height:100vh;

    padding:25px 18px;

    background:rgba(2,6,23,.78);

    border-right:1px solid rgba(255,255,255,.08);

    backdrop-filter:blur(25px);

    z-index:1000;
}


.logo{

    text-align:center;

    font-size:24px;

    font-weight:800;

    margin-bottom:38px;

    background:
        linear-gradient(
            90deg,
            #00f5ff,
            #8b5cf6,
            #ec4899
        );

    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}


.logo span{

    display:block;

    font-size:9px;

    letter-spacing:3px;

    margin-top:3px;

    color:#64748b;

    -webkit-text-fill-color:#64748b;
}


.nav{

    display:flex;

    flex-direction:column;

    gap:8px;
}


.nav a{

    display:flex;

    align-items:center;

    gap:12px;

    padding:13px 15px;

    border-radius:13px;

    text-decoration:none;

    color:#94a3b8;

    font-size:13px;

    border:1px solid transparent;

    transition:.3s;
}


.nav a:hover{

    color:#fff;

    background:
        linear-gradient(
            90deg,
            rgba(0,245,255,.1),
            rgba(139,92,246,.1)
        );

    border-color:rgba(0,245,255,.15);

    transform:translateX(4px);
}


.nav a.active{

    color:white;

    background:
        linear-gradient(
            135deg,
            rgba(0,245,255,.16),
            rgba(139,92,246,.18)
        );

    border-color:rgba(0,245,255,.2);
}


.nav-icon{

    width:28px;
    height:28px;

    display:flex;

    align-items:center;
    justify-content:center;

    border-radius:8px;

    background:rgba(255,255,255,.06);
}


/* =========================================================
   MAIN
========================================================= */

.main{

    margin-left:250px;

    padding:35px 45px 70px;
}


.container{

    max-width:1050px;

    margin:0 auto;
}


/* =========================================================
   TOPBAR
========================================================= */

.topbar{

    display:flex;

    align-items:center;

    justify-content:space-between;

    margin-bottom:28px;
}


.back-btn{

    display:inline-flex;

    align-items:center;

    gap:8px;

    color:#94a3b8;

    text-decoration:none;

    font-size:13px;

    transition:.3s;
}


.back-btn:hover{

    color:#67e8f9;

    transform:translateX(-3px);
}


.profile{

    display:flex;

    align-items:center;

    gap:10px;

    padding:8px 12px;

    border-radius:13px;

    background:rgba(255,255,255,.045);

    border:1px solid rgba(255,255,255,.08);
}


.avatar{

    width:36px;
    height:36px;

    border-radius:11px;

    display:flex;

    align-items:center;
    justify-content:center;

    font-weight:700;

    background:
        linear-gradient(
            135deg,
            #00f5ff,
            #8b5cf6
        );
}


.profile small{

    color:#64748b;

    font-size:10px;
}


/* =========================================================
   PAGE HEADER
========================================================= */

.page-header{

    padding:35px;

    border-radius:25px;

    background:
        linear-gradient(
            135deg,
            rgba(0,245,255,.08),
            rgba(139,92,246,.1),
            rgba(236,72,153,.06)
        ),
        rgba(255,255,255,.035);

    border:1px solid rgba(255,255,255,.08);

    backdrop-filter:blur(25px);

    margin-bottom:25px;
}


.badge{

    display:inline-flex;

    padding:7px 13px;

    border-radius:30px;

    color:#67e8f9;

    background:rgba(0,245,255,.08);

    border:1px solid rgba(0,245,255,.16);

    font-size:10px;

    font-weight:600;

    margin-bottom:13px;
}


.page-header h1{

    font-size:34px;

    line-height:1.2;
}


.gradient{

    background:
        linear-gradient(
            90deg,
            #00f5ff,
            #8b5cf6,
            #ec4899
        );

    -webkit-background-clip:text;

    -webkit-text-fill-color:transparent;
}


.page-header p{

    color:#94a3b8;

    font-size:13px;

    line-height:1.7;

    margin-top:10px;

    max-width:750px;
}


/* =========================================================
   ALERTS
========================================================= */

.alert{

    padding:15px 18px;

    border-radius:14px;

    margin-bottom:20px;

    font-size:12px;

    line-height:1.7;
}


.alert-success{

    background:rgba(34,197,94,.1);

    border:1px solid rgba(34,197,94,.25);

    color:#86efac;
}


.alert-error{

    background:rgba(239,68,68,.1);

    border:1px solid rgba(239,68,68,.25);

    color:#fca5a5;
}


/* =========================================================
   FORM
========================================================= */

.form-card{

    padding:30px;

    border-radius:25px;

    background:rgba(255,255,255,.035);

    border:1px solid rgba(255,255,255,.08);

    backdrop-filter:blur(25px);
}


.form-section{

    margin-bottom:32px;

    padding-bottom:28px;

    border-bottom:1px solid rgba(255,255,255,.06);
}


.form-section:last-child{

    border-bottom:0;

    margin-bottom:0;

    padding-bottom:0;
}


.section-title{

    display:flex;

    align-items:center;

    gap:12px;

    margin-bottom:20px;
}


.section-number{

    width:34px;
    height:34px;

    display:flex;

    align-items:center;
    justify-content:center;

    border-radius:10px;

    background:
        linear-gradient(
            135deg,
            rgba(0,245,255,.16),
            rgba(139,92,246,.18)
        );

    border:1px solid rgba(0,245,255,.18);

    color:#67e8f9;

    font-size:12px;

    font-weight:700;
}


.section-title h2{

    font-size:17px;
}


.section-title p{

    color:#64748b;

    font-size:10px;

    margin-top:2px;
}


.grid{

    display:grid;

    grid-template-columns:repeat(2,1fr);

    gap:18px;
}


.field{

    display:flex;

    flex-direction:column;

    gap:7px;
}


.field.full{

    grid-column:1/-1;
}


label{

    color:#cbd5e1;

    font-size:11px;

    font-weight:600;
}


.required{

    color:#f87171;
}


.optional{

    color:#64748b;

    font-size:9px;

    font-weight:400;

    margin-left:4px;
}


input,
select,
textarea{

    width:100%;

    border:1px solid rgba(255,255,255,.09);

    background:#0b1224;

    color:#fff;

    outline:none;

    border-radius:12px;

    padding:13px 14px;

    font-family:inherit;

    font-size:12px;

    transition:.3s;
}


input::placeholder,
textarea::placeholder{

    color:#475569;
}


input:focus,
select:focus,
textarea:focus{

    border-color:#00d9f5;

    box-shadow:
        0 0 0 3px rgba(0,245,255,.07);
}


textarea{

    min-height:130px;

    resize:vertical;

    line-height:1.6;
}


select{

    cursor:pointer;
}


select option{

    background:#0b1224;

    color:#fff;
}


.help{

    color:#64748b;

    font-size:9px;

    line-height:1.5;
}


/* =========================================================
   CONTACT METHODS
========================================================= */

.contact-methods{

    display:grid;

    grid-template-columns:repeat(3,1fr);

    gap:12px;

    margin-bottom:17px;
}


.contact-option{

    position:relative;
}


.contact-option input{

    position:absolute;

    opacity:0;

    pointer-events:none;
}


.contact-option label{

    display:flex;

    flex-direction:column;

    align-items:center;

    justify-content:center;

    gap:6px;

    min-height:85px;

    border-radius:15px;

    border:1px solid rgba(255,255,255,.08);

    background:rgba(255,255,255,.025);

    cursor:pointer;

    transition:.3s;

    color:#94a3b8;

}


.contact-option label .icon{

    font-size:22px;
}


.contact-option input:checked + label{

    color:#fff;

    border-color:#00d9f5;

    background:
        linear-gradient(
            135deg,
            rgba(0,245,255,.1),
            rgba(139,92,246,.12)
        );

    box-shadow:
        0 10px 30px rgba(0,245,255,.08);
}


.contact-option label:hover{

    border-color:rgba(0,245,255,.25);

    transform:translateY(-2px);
}


/* =========================================================
   DYNAMIC CONTACT
========================================================= */

.contact-input{

    display:none;
}


.contact-input.show{

    display:flex;

    animation:slideDown .3s ease;
}


@keyframes slideDown{

    from{

        opacity:0;

        transform:translateY(-5px);
    }

    to{

        opacity:1;

        transform:translateY(0);
    }
}


/* =========================================================
   SOCIAL LINKS
========================================================= */

.optional-box{

    padding:20px;

    border-radius:17px;

    background:rgba(255,255,255,.025);

    border:1px solid rgba(255,255,255,.06);

    margin-bottom:18px;
}


.optional-title{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-bottom:17px;
}


.optional-title strong{

    font-size:12px;
}


.optional-title span{

    color:#64748b;

    font-size:9px;
}


.social-grid{

    display:grid;

    grid-template-columns:repeat(2,1fr);

    gap:15px;
}


/* =========================================================
   IMAGE UPLOAD
========================================================= */

.upload-box{

    border:1px dashed rgba(0,245,255,.2);

    border-radius:18px;

    padding:25px;

    text-align:center;

    background:rgba(0,245,255,.025);

    transition:.3s;
}


.upload-box:hover{

    border-color:rgba(0,245,255,.45);

    background:rgba(0,245,255,.045);
}


.upload-icon{

    font-size:38px;

    margin-bottom:8px;
}


.upload-box strong{

    display:block;

    font-size:13px;

    margin-bottom:5px;
}


.upload-box p{

    color:#64748b;

    font-size:10px;

    margin-bottom:15px;
}


.file-label{

    display:inline-block;

    padding:10px 17px;

    border-radius:10px;

    background:
        linear-gradient(
            135deg,
            #00cfe8,
            #7c3aed
        );

    color:#fff;

    cursor:pointer;

    font-size:11px;

    font-weight:600;
}


#skill_image{

    display:none;
}


.file-name{

    margin-top:12px;

    color:#67e8f9;

    font-size:10px;
}


/* =========================================================
   SUBMIT
========================================================= */

.submit-area{

    margin-top:28px;

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:15px;
}


.cancel{

    text-decoration:none;

    color:#94a3b8;

    font-size:12px;

    padding:13px 18px;

    border-radius:12px;

    border:1px solid rgba(255,255,255,.08);

    transition:.3s;
}


.cancel:hover{

    color:#fff;

    background:rgba(255,255,255,.05);
}


.submit{

    border:0;

    padding:14px 28px;

    border-radius:13px;

    color:#fff;

    font-family:inherit;

    font-size:12px;

    font-weight:700;

    cursor:pointer;

    background:
        linear-gradient(
            135deg,
            #00cfe8,
            #7c3aed
        );

    transition:.3s;
}


.submit:hover{

    transform:translateY(-3px);

    box-shadow:
        0 15px 35px rgba(124,58,237,.25);
}


/* =========================================================
   REQUIRED NOTE
========================================================= */

.required-note{

    color:#64748b;

    font-size:10px;

    margin-top:18px;

    line-height:1.6;
}


.required-note b{

    color:#f87171;
}


/* =========================================================
   FOOTER
========================================================= */

footer{

    text-align:center;

    margin-top:35px;

    color:#475569;

    font-size:10px;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:900px){

    .sidebar{

        width:80px;

        padding:20px 10px;
    }


    .logo{

        font-size:0;
    }


    .logo::before{

        content:"E";

        font-size:25px;
    }


    .logo span{

        display:none;
    }


    .nav a{

        justify-content:center;

        padding:13px;
    }


    .nav a span:not(.nav-icon){

        display:none;
    }


    .main{

        margin-left:80px;

        padding:25px;
    }

}


@media(max-width:650px){

    .main{

        padding:18px;
    }


    .topbar{

        align-items:flex-start;

        gap:15px;

        flex-direction:column;
    }


    .page-header{

        padding:25px;
    }


    .page-header h1{

        font-size:27px;
    }


    .form-card{

        padding:20px;
    }


    .grid{

        grid-template-columns:1fr;
    }


    .field.full{

        grid-column:auto;
    }


    .contact-methods{

        grid-template-columns:1fr;
    }


    .social-grid{

        grid-template-columns:1fr;
    }


    .submit-area{

        flex-direction:column-reverse;

        align-items:stretch;
    }


    .submit,
    .cancel{

        width:100%;

        text-align:center;
    }

}

</style>

</head>


<body>


<!-- BACKGROUND -->

<div class="orb one"></div>
<div class="orb two"></div>
<div class="orb three"></div>


<!-- =======================================================
     SIDEBAR
======================================================== -->

<aside class="sidebar">

    <div class="logo">

        EduTrade PRO

        <span>
            SKILL HUB
        </span>

    </div>


    <nav class="nav">

        <a href="dashboard.php">

            <span class="nav-icon">
                🏠
            </span>

            <span>
                Dashboard
            </span>

        </a>


        <a href="marketplace.php">

            <span class="nav-icon">
                🛒
            </span>

            <span>
                Marketplace
            </span>

        </a>


        <a href="skills.php">

            <span class="nav-icon">
                🎯
            </span>

            <span>
                Skill Hub
            </span>

        </a>


        <a href="add_product.php">

            <span class="nav-icon">
                ➕
            </span>

            <span>
                Add Product
            </span>

        </a>


        <a
            href="add_skills.php"
            class="active"
        >

            <span class="nav-icon">
                ✨
            </span>

            <span>
                Add Skill
            </span>

        </a>


        <a href="wishlist.php">

            <span class="nav-icon">
                ❤️
            </span>

            <span>
                Wishlist
            </span>

        </a>


        <a href="../includes/auth.php?logout=true">

            <span class="nav-icon">
                🚪
            </span>

            <span>
                Logout
            </span>

        </a>

    </nav>

</aside>


<!-- =======================================================
     MAIN
======================================================== -->

<main class="main">

<div class="container">


    <!-- TOPBAR -->

    <div class="topbar">

        <a
            href="skills.php"
            class="back-btn"
        >
            ← Back to Skill Hub
        </a>


        <div class="profile">

            <div class="avatar">

                <?php

                echo strtoupper(
                    substr(
                        $userName ?: 'S',
                        0,
                        1
                    )
                );

                ?>

            </div>


            <div>

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $userName ?: 'Student'
                    );
                    ?>
                </strong>

                <br>

                <small>
                    Student
                </small>

            </div>

        </div>

    </div>


    <!-- HEADER -->

    <section class="page-header">

        <div class="badge">
            ✦ EDU TRADE SKILL HUB
        </div>


        <h1>

            Showcase your
            <span class="gradient">
                skills.
            </span>

        </h1>


        <p>

            Tell your campus community what you're good at.
            Students can discover your skills and contact you
            for projects, freelance work, or collaboration.

        </p>

    </section>


    <!-- SUCCESS -->

    <?php if ($successMessage !== ''): ?>

        <div class="alert alert-success">

            ✅

            <?php
            echo htmlspecialchars(
                $successMessage
            );
            ?>

            <br><br>

            <a
                href="skills.php"
                style="color:#86efac;font-weight:700;"
            >
                View Skill Hub →
            </a>

        </div>

    <?php endif; ?>


    <!-- ERROR -->

    <?php if ($errorMessage !== ''): ?>

        <div class="alert alert-error">

            ⚠️

            <?php
            echo $errorMessage;
            ?>

        </div>

    <?php endif; ?>


    <!-- FORM -->

    <form
        method="POST"
        enctype="multipart/form-data"
        class="form-card"
        id="skillForm"
    >


        <!-- =================================================
             BASIC INFORMATION
        ================================================== -->

        <section class="form-section">

            <div class="section-title">

                <div class="section-number">
                    01
                </div>

                <div>

                    <h2>
                        Skill Information
                    </h2>

                    <p>
                        Tell students what you can do.
                    </p>

                </div>

            </div>


            <div class="grid">


                <!-- NAME -->

                <div class="field">

                    <label>
                        Student Name
                        <span class="required">*</span>
                    </label>

                    <input
                        type="text"
                        value="<?php
                            echo htmlspecialchars(
                                $userName
                            );
                        ?>"
                        readonly
                    >

                </div>


                <!-- SKILL -->

                <div class="field">

                    <label>
                        Skill Name
                        <span class="required">*</span>
                    </label>

                    <input
                        type="text"
                        name="skill_name"
                        value="<?php
                            echo htmlspecialchars(
                                $skillName
                            );
                        ?>"
                        placeholder="e.g. Web Designing"
                        required
                    >

                </div>


                <!-- CATEGORY -->

                <div class="field">

                    <label>
                        Skill Category
                        <span class="required">*</span>
                    </label>

                    <select
                        name="category"
                        required
                    >

                        <option value="">
                            Select Category
                        </option>

                        <option
                            value="Programming"
                            <?php
                            echo $category === 'Programming'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            💻 Programming
                        </option>

                        <option
                            value="Web Development"
                            <?php
                            echo $category === 'Web Development'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            🌐 Web Development
                        </option>

                        <option
                            value="Graphic Design"
                            <?php
                            echo $category === 'Graphic Design'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            🎨 Graphic Design
                        </option>

                        <option
                            value="Video Editing"
                            <?php
                            echo $category === 'Video Editing'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            🎬 Video Editing
                        </option>

                        <option
                            value="Photography"
                            <?php
                            echo $category === 'Photography'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            📸 Photography
                        </option>

                        <option
                            value="Writing"
                            <?php
                            echo $category === 'Writing'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            ✍️ Writing
                        </option>

                        <option
                            value="Marketing"
                            <?php
                            echo $category === 'Marketing'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            📢 Marketing
                        </option>

                        <option
                            value="Tutoring"
                            <?php
                            echo $category === 'Tutoring'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            📚 Tutoring
                        </option>

                        <option
                            value="Presentation"
                            <?php
                            echo $category === 'Presentation'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            🎤 Presentation
                        </option>

                        <option
                            value="Other"
                            <?php
                            echo $category === 'Other'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            ✨ Other
                        </option>

                    </select>

                </div>


                <!-- LEVEL -->

                <div class="field">

                    <label>
                        Skill Level
                        <span class="required">*</span>
                    </label>

                    <select
                        name="skill_level"
                        required
                    >

                        <option value="">
                            Select Level
                        </option>

                        <option
                            value="Beginner"
                            <?php
                            echo $skillLevel === 'Beginner'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            🌱 Beginner
                        </option>

                        <option
                            value="Intermediate"
                            <?php
                            echo $skillLevel === 'Intermediate'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            ⚡ Intermediate
                        </option>

                        <option
                            value="Advanced"
                            <?php
                            echo $skillLevel === 'Advanced'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            🚀 Advanced
                        </option>

                    </select>

                </div>


                <!-- EXPERIENCE -->

                <div class="field">

                    <label>
                        Experience
                        <span class="required">*</span>
                    </label>

                    <input
                        type="text"
                        name="experience"
                        value="<?php
                            echo htmlspecialchars(
                                $experience
                            );
                        ?>"
                        placeholder="e.g. 1 year / 6 months / College projects"
                        required
                    >

                </div>


                <!-- SERVICE -->

                <div class="field">

                    <label>
                        Service Type
                        <span class="required">*</span>
                    </label>

                    <select
                        name="service_type"
                        required
                    >

                        <option value="">
                            Select Service Type
                        </option>

                        <option
                            value="Freelance"
                            <?php
                            echo $serviceType === 'Freelance'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            💼 Freelance
                        </option>

                        <option
                            value="Project Based"
                            <?php
                            echo $serviceType === 'Project Based'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            📁 Project Based
                        </option>

                        <option
                            value="Part Time"
                            <?php
                            echo $serviceType === 'Part Time'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            ⏰ Part Time
                        </option>

                        <option
                            value="One Time"
                            <?php
                            echo $serviceType === 'One Time'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            🎯 One Time
                        </option>

                        <option
                            value="Free Help"
                            <?php
                            echo $serviceType === 'Free Help'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            🤝 Free Student Help
                        </option>

                    </select>

                </div>


                <!-- PRICE -->

                <div class="field">

                    <label>
                        Expected Price / Rate
                        <span class="required">*</span>
                    </label>

                    <input
                        type="number"
                        name="price"
                        value="<?php
                            echo htmlspecialchars(
                                $price
                            );
                        ?>"
                        min="0"
                        step="0.01"
                        placeholder="₹ 500"
                        required
                    >

                    <span class="help">
                        Enter 0 if you are offering free student help.
                    </span>

                </div>


                <!-- AVAILABILITY -->

                <div class="field">

                    <label>
                        Availability
                        <span class="required">*</span>
                    </label>

                    <select
                        name="availability"
                        required
                    >

                        <option value="">
                            Select Availability
                        </option>

                        <option
                            value="Available"
                            <?php
                            echo $availability === 'Available'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            🟢 Available
                        </option>

                        <option
                            value="Busy"
                            <?php
                            echo $availability === 'Busy'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            🟡 Busy
                        </option>

                        <option
                            value="Unavailable"
                            <?php
                            echo $availability === 'Unavailable'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            🔴 Unavailable
                        </option>

                    </select>

                </div>


                <!-- DESCRIPTION -->

                <div class="field full">

                    <label>
                        Skill Description
                        <span class="required">*</span>
                    </label>

                    <textarea
                        name="description"
                        placeholder="Explain what you can do, what tools you use, what type of projects you accept, etc."
                        required
                    ><?php
                        echo htmlspecialchars(
                            $description
                        );
                    ?></textarea>

                    <span class="help">
                        Minimum 20 characters. Give students enough information to understand your skill.
                    </span>

                </div>

            </div>

        </section>


        <!-- =================================================
             CONTACT
        ================================================== -->

        <section class="form-section">

            <div class="section-title">

                <div class="section-number">
                    02
                </div>

                <div>

                    <h2>
                        Contact Information
                    </h2>

                    <p>
                        Required so interested students can contact you.
                    </p>

                </div>

            </div>


            <div class="field">

                <label>
                    Preferred Contact Method
                    <span class="required">*</span>
                </label>

            </div>


            <div class="contact-methods">


                <!-- PHONE -->

                <div class="contact-option">

                    <input
                        type="radio"
                        name="contact_method"
                        id="contact_phone"
                        value="Phone"
                        <?php
                        echo $contactMethod === 'Phone'
                            ? 'checked'
                            : '';
                        ?>
                        required
                    >

                    <label for="contact_phone">

                        <span class="icon">
                            📞
                        </span>

                        Phone

                    </label>

                </div>


                <!-- EMAIL -->

                <div class="contact-option">

                    <input
                        type="radio"
                        name="contact_method"
                        id="contact_email"
                        value="Email"
                        <?php
                        echo $contactMethod === 'Email'
                            ? 'checked'
                            : '';
                        ?>
                    >

                    <label for="contact_email">

                        <span class="icon">
                            📧
                        </span>

                        Email

                    </label>

                </div>


                <!-- WHATSAPP -->

                <div class="contact-option">

                    <input
                        type="radio"
                        name="contact_method"
                        id="contact_whatsapp"
                        value="WhatsApp"
                        <?php
                        echo $contactMethod === 'WhatsApp'
                            ? 'checked'
                            : '';
                        ?>
                    >

                    <label for="contact_whatsapp">

                        <span class="icon">
                            💬
                        </span>

                        WhatsApp

                    </label>

                </div>

            </div>


            <!-- DYNAMIC CONTACT -->

            <div
                class="field contact-input <?php
                    echo $contactMethod !== ''
                        ? 'show'
                        : '';
                ?>"
                id="contactInputContainer"
            >

                <label id="contactLabel">

                    Contact Information

                    <span class="required">
                        *
                    </span>

                </label>


                <input
                    type="text"
                    name="contact_info"
                    id="contactInfo"
                    value="<?php
                        echo htmlspecialchars(
                            $contactInfo
                        );
                    ?>"
                    placeholder="Enter your contact information"
                >


                <span
                    class="help"
                    id="contactHelp"
                >
                    Your selected contact information will be used by interested students.
                </span>

            </div>

        </section>


        <!-- =================================================
             WORK PHOTO
        ================================================== -->

        <section class="form-section">

            <div class="section-title">

                <div class="section-number">
                    03
                </div>

                <div>

                    <h2>
                        Showcase Your Work
                    </h2>

                    <p>
                        Give students a visual idea of your ability.
                    </p>

                </div>

            </div>


            <div class="upload-box">

                <div class="upload-icon">
                    🖼️
                </div>


                <strong>
                    Add a Skill / Work Photo
                </strong>


                <p>
                    Optional — beginners can skip this.
                    JPG, PNG or WEBP • Maximum 5 MB
                </p>


                <label
                    for="skill_image"
                    class="file-label"
                >
                    Choose Image
                </label>


                <input
                    type="file"
                    name="skill_image"
                    id="skill_image"
                    accept="image/jpeg,image/png,image/webp"
                >


                <div
                    class="file-name"
                    id="fileName"
                >
                </div>

            </div>

        </section>


        <!-- =================================================
             SOCIAL LINKS
        ================================================== -->

        <section class="form-section">

            <div class="section-title">

                <div class="section-number">
                    04
                </div>

                <div>

                    <h2>
                        Portfolio & Social Links
                    </h2>

                    <p>
                        Completely optional — don't have them? No problem.
                    </p>

                </div>

            </div>


            <div class="optional-box">


                <div class="optional-title">

                    <strong>
                        🔗 Online Presence
                    </strong>

                    <span>
                        ALL OPTIONAL
                    </span>

                </div>


                <div class="social-grid">


                    <!-- PORTFOLIO -->

                    <div class="field">

                        <label>
                            Portfolio Website
                            <span class="optional">
                                Optional
                            </span>
                        </label>

                        <input
                            type="url"
                            name="portfolio"
                            value="<?php
                                echo htmlspecialchars(
                                    $portfolio
                                );
                            ?>"
                            placeholder="https://yourportfolio.com"
                        >

                    </div>


                    <!-- LINKEDIN -->

                    <div class="field">

                        <label>
                            LinkedIn
                            <span class="optional">
                                Optional
                            </span>
                        </label>

                        <input
                            type="url"
                            name="linkedin"
                            value="<?php
                                echo htmlspecialchars(
                                    $linkedin
                                );
                            ?>"
                            placeholder="https://linkedin.com/in/username"
                        >

                    </div>


                    <!-- GITHUB -->

                    <div class="field">

                        <label>
                            GitHub
                            <span class="optional">
                                Optional
                            </span>
                        </label>

                        <input
                            type="url"
                            name="github"
                            value="<?php
                                echo htmlspecialchars(
                                    $github
                                );
                            ?>"
                            placeholder="https://github.com/username"
                        >

                    </div>


                    <!-- INSTAGRAM -->

                    <div class="field">

                        <label>
                            Instagram
                            <span class="optional">
                                Optional
                            </span>
                        </label>

                        <input
                            type="url"
                            name="instagram"
                            value="<?php
                                echo htmlspecialchars(
                                    $instagram
                                );
                            ?>"
                            placeholder="https://instagram.com/username"
                        >

                    </div>

                </div>

            </div>


            <div class="required-note">

                <b>*</b>
                Required fields must be completed.

                Portfolio, LinkedIn, GitHub, Instagram and
                skill photo are completely optional.

            </div>

        </section>


        <!-- =================================================
             SUBMIT
        ================================================== -->

        <div class="submit-area">


            <a
                href="skills.php"
                class="cancel"
            >
                Cancel
            </a>


            <button
                type="submit"
                class="submit"
                id="submitButton"
            >
                ✨ Publish My Skill
            </button>

        </div>

    </form>


    <footer>

        EduTrade PRO • Student Skill Hub
        • Learn. Create. Earn. 🚀

    </footer>


</div>

</main>


<script>

/* =========================================================
   CONTACT METHOD
========================================================= */

const contactInputs =
    document.querySelectorAll(
        'input[name="contact_method"]'
    );


const contactContainer =
    document.getElementById(
        'contactInputContainer'
    );


const contactInput =
    document.getElementById(
        'contactInfo'
    );


const contactLabel =
    document.getElementById(
        'contactLabel'
    );


const contactHelp =
    document.getElementById(
        'contactHelp'
    );


function updateContactField(){

    const selected =
        document.querySelector(
            'input[name="contact_method"]:checked'
        );


    if(!selected){

        contactContainer.classList.remove('show');

        contactInput.required = false;

        return;
    }


    contactContainer.classList.add('show');

    contactInput.required = true;


    if(selected.value === 'Phone'){

        contactLabel.innerHTML =
            'Phone Number <span class="required">*</span>';

        contactInput.type = 'tel';

        contactInput.placeholder =
            '+91 98765 43210';

        contactInput.setAttribute(
            'pattern',
            '[0-9+()\\-\\s]{10,}'
        );

        contactHelp.textContent =
            'Enter a phone number where students can contact you.';
    }


    else if(selected.value === 'Email'){

        contactLabel.innerHTML =
            'Email Address <span class="required">*</span>';

        contactInput.type = 'email';

        contactInput.placeholder =
            'student@example.com';

        contactInput.removeAttribute(
            'pattern'
        );

        contactHelp.textContent =
            'Enter an email address where students can contact you.';
    }


    else if(selected.value === 'WhatsApp'){

        contactLabel.innerHTML =
            'WhatsApp Number <span class="required">*</span>';

        contactInput.type = 'tel';

        contactInput.placeholder =
            '+91 98765 43210';

        contactInput.setAttribute(
            'pattern',
            '[0-9+()\\-\\s]{10,}'
        );

        contactHelp.textContent =
            'Enter the WhatsApp number students should use.';
    }

}


contactInputs.forEach(
    function(input){

        input.addEventListener(
            'change',
            updateContactField
        );

    }
);


updateContactField();


/* =========================================================
   IMAGE FILE NAME
========================================================= */

const imageInput =
    document.getElementById(
        'skill_image'
    );


const fileName =
    document.getElementById(
        'fileName'
    );


imageInput.addEventListener(
    'change',
    function(){

        if(this.files.length > 0){

            fileName.textContent =
                '✓ ' +
                this.files[0].name;

        }else{

            fileName.textContent =
                '';

        }

    }
);


/* =========================================================
   FORM SUBMIT LOADING
========================================================= */

const form =
    document.getElementById(
        'skillForm'
    );


const submitButton =
    document.getElementById(
        'submitButton'
    );


form.addEventListener(
    'submit',
    function(){

        submitButton.disabled = true;

        submitButton.innerHTML =
            '⏳ Publishing Skill...';

    }
);


/* =========================================================
   DESCRIPTION COUNTER / USER EXPERIENCE
========================================================= */

const description =
    document.querySelector(
        'textarea[name="description"]'
    );


if(description){

    description.addEventListener(
        'input',
        function(){

            const minimum = 20;

            if(
                this.value.trim().length > 0 &&
                this.value.trim().length < minimum
            ){

                this.style.borderColor =
                    'rgba(248,113,113,.5)';

            }else{

                this.style.borderColor =
                    '';

            }

        }
    );

}

</script>


</body>

</html>