
<?php
session_start();

require_once "../config/db.php";

/* =========================================================
   AUTHENTICATION
========================================================= */

if (!isset($_SESSION['user_id'])) {
    header("Location: ../includes/login.php");
    exit();
}

$userId = (int) $_SESSION['user_id'];

/* =========================================================
   GET PRODUCT ID
========================================================= */

$productId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($productId <= 0) {
    header("Location: marketplace.php");
    exit();
}

/* =========================================================
   FETCH PRODUCT
========================================================= */

$sql = "
    SELECT 
        p.*,
        u.name AS seller_name
    FROM products p
    LEFT JOIN users u 
        ON p.user_id = u.id
    WHERE p.id = ?
    LIMIT 1
";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("Database query preparation failed.");
}

mysqli_stmt_bind_param($stmt, "i", $productId);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$product = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

/* =========================================================
   PRODUCT NOT FOUND
========================================================= */

if (!$product) {
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Product Not Found | EduTrade PRO</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    min-height: 100vh;

    font-family: Arial, sans-serif;

    background:
        radial-gradient(
            circle at 10% 10%,
            rgba(34,197,94,.12),
            transparent 30%
        ),
        radial-gradient(
            circle at 90% 90%,
            rgba(168,85,247,.12),
            transparent 30%
        ),
        #060b16;

    color: white;

    display: flex;
    align-items: center;
    justify-content: center;

    padding: 25px;
}

.not-found {
    width: 100%;
    max-width: 520px;

    padding: 50px 35px;

    text-align: center;

    border-radius: 28px;

    background: rgba(15,23,42,.78);

    border:
        1px solid rgba(255,255,255,.08);

    backdrop-filter: blur(20px);

    box-shadow:
        0 25px 80px rgba(0,0,0,.45);
}

.icon {
    width: 90px;
    height: 90px;

    margin: 0 auto 25px;

    border-radius: 50%;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 42px;

    background:
        rgba(248,113,113,.1);

    border:
        1px solid rgba(248,113,113,.25);
}

h1 {
    font-size: 30px;
    margin-bottom: 12px;
}

p {
    color: #94a3b8;
    margin-bottom: 28px;
    line-height: 1.7;
}

a {
    display: inline-flex;

    padding: 13px 22px;

    border-radius: 12px;

    text-decoration: none;

    color: white;

    background:
        linear-gradient(
            135deg,
            #22c55e,
            #16a34a
        );

    font-weight: 700;
}

</style>

</head>

<body>

<div class="not-found">

    <div class="icon">
        🔍
    </div>

    <h1>
        Product Not Found
    </h1>

    <p>
        This product may have been removed,
        deleted, or is no longer available.
    </p>

    <a href="marketplace.php">
        ← Back to Marketplace
    </a>

</div>

</body>
</html>

<?php
exit();
}

/* =========================================================
   PRODUCT DATA
========================================================= */

$title = trim(
    (string)($product['title'] ?? 'Untitled Product')
);

$description = trim(
    (string)($product['description'] ?? '')
);

$price = (float)(
    $product['price'] ?? 0
);

$condition = trim(
    (string)(
        $product['product_condition']
        ?? 'Not specified'
    )
);

$productAge = trim(
    (string)(
        $product['product_age']
        ?? ''
    )
);

$quantity = isset($product['quantity'])
    ? (int)$product['quantity']
    : 1;

$negotiable = isset($product['negotiable'])
    ? (int)$product['negotiable']
    : 0;

$location = trim(
    (string)(
        $product['location']
        ?? ''
    )
);

$sellerName = trim(
    (string)(
        $product['seller_name']
        ?? 'EduTrade Student'
    )
);
/* =========================================================
   SELLER CHAT
========================================================= */

$sellerId = (int)($product['user_id'] ?? 0);
$isOwnProduct = ($sellerId === $userId);

$contactMethod = trim(
    (string)(
        $product['contact_method']
        ?? ''
    )
);

$contactValue = trim(
    (string)(
        $product['contact_value']
        ?? ''
    )
);

$additionalContact = trim(
    (string)(
        $product['additional_contact']
        ?? ''
    )
);

$createdAt = $product['created_at'] ?? '';

/* =========================================================
   CHECK WHETHER PRODUCT IS ALREADY SAVED
========================================================= */

$isSaved = false;

$saveStmt = mysqli_prepare(
    $conn,
    "SELECT id
     FROM saved_products
     WHERE user_id = ?
     AND product_id = ?
     LIMIT 1"
);

if ($saveStmt) {

    mysqli_stmt_bind_param(
        $saveStmt,
        "ii",
        $userId,
        $productId
    );

    mysqli_stmt_execute($saveStmt);

    $saveResult =
        mysqli_stmt_get_result($saveStmt);

    if ($saveResult) {

        $isSaved =
            (bool)mysqli_fetch_assoc($saveResult);

    }

    mysqli_stmt_close($saveStmt);
}

/* =========================================================
   SAVE/UNSAVE MESSAGE
========================================================= */

$saveMessage = '';
$saveMessageClass = '';

if (isset($_GET['save'])) {

    $saveStatus =
        (string)$_GET['save'];

    if ($saveStatus === 'saved') {

        $saveMessage =
            '✓ Product saved to your wishlist.';

        $saveMessageClass = 'success';

    } elseif ($saveStatus === 'removed') {

        $saveMessage =
            '♡ Product removed from your wishlist.';

        $saveMessageClass = 'removed';

    } elseif ($saveStatus === 'error') {

        $saveMessage =
            '⚠ Unable to update your wishlist. Please try again.';

        $saveMessageClass = 'error';
    }
}

/* =========================================================
   IMAGE HANDLING
========================================================= */

$image = trim(
    (string)(
        $product['image']
        ?? ''
    )
);

$imageUrl = '';

if ($image !== '') {

    $filename = basename($image);

    if (
        $filename !== '' &&
        $filename !== '.' &&
        $filename !== '..'
    ) {

        $physicalPath =
            __DIR__ .
            DIRECTORY_SEPARATOR .
            '..' .
            DIRECTORY_SEPARATOR .
            'uploads' .
            DIRECTORY_SEPARATOR .
            'products' .
            DIRECTORY_SEPARATOR .
            $filename;

        $browserPath =
            '../uploads/products/' .
            rawurlencode($filename);

        if (file_exists($physicalPath)) {
            $imageUrl = $browserPath;
        }
    }
}

/* =========================================================
   DATE
========================================================= */

$formattedDate = 'Recently';

if (!empty($createdAt)) {

    $timestamp = strtotime($createdAt);

    if ($timestamp !== false) {
        $formattedDate =
            date("d M Y", $timestamp);
    }
}

/* =========================================================
   CONDITION STYLE
========================================================= */

$conditionLower =
    strtolower($condition);

if (
    strpos($conditionLower, 'new') !== false
) {

    $conditionClass = 'new';
    $conditionIcon = '✨';

} elseif (
    strpos($conditionLower, 'used') !== false
) {

    $conditionClass = 'used';
    $conditionIcon = '♻️';

} else {

    $conditionClass = 'normal';
    $conditionIcon = '📦';
}

/* =========================================================
   CONTACT AVAILABILITY
========================================================= */

$hasContact =
    $contactValue !== '' ||
    $additionalContact !== '';

/* =========================================================
   ESCAPE FUNCTION
========================================================= */

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="description"
    content="Product details on EduTrade PRO"
>

<title>
    <?php echo e($title); ?> | EduTrade PRO
</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
    rel="stylesheet"
>

<style>

/* =========================================================
   RESET
========================================================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {

    font-family: "Inter", sans-serif;

    background:
        radial-gradient(
            circle at 10% 10%,
            rgba(34,197,94,.08),
            transparent 28%
        ),
        radial-gradient(
            circle at 90% 20%,
            rgba(168,85,247,.10),
            transparent 30%
        ),
        radial-gradient(
            circle at 50% 100%,
            rgba(6,182,212,.07),
            transparent 30%
        ),
        #060b16;

    color: #f8fafc;

    min-height: 100vh;

    overflow-x: hidden;
}

body::before {

    content: "";

    position: fixed;

    inset: 0;

    pointer-events: none;

    background:
        linear-gradient(
            rgba(255,255,255,.012) 1px,
            transparent 1px
        ),
        linear-gradient(
            90deg,
            rgba(255,255,255,.012) 1px,
            transparent 1px
        );

    background-size: 45px 45px;

    mask-image:
        linear-gradient(
            to bottom,
            black,
            transparent
        );

    z-index: -1;
}

a {
    color: inherit;
    text-decoration: none;
}

button {
    font-family: inherit;
}

/* =========================================================
   NAVBAR
========================================================= */

.topbar {

    position: sticky;

    top: 0;

    z-index: 100;

    height: 76px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 42px;

    background:
        rgba(6,11,22,.78);

    backdrop-filter:
        blur(22px);

    border-bottom:
        1px solid rgba(255,255,255,.07);
}

.brand {

    display: flex;

    align-items: center;

    gap: 12px;
}

.brand-logo {

    width: 42px;
    height: 42px;

    border-radius: 13px;

    display: flex;

    align-items: center;
    justify-content: center;

    font-size: 20px;

    font-weight: 800;

    background:
        linear-gradient(
            135deg,
            #22c55e,
            #06b6d4
        );

    box-shadow:
        0 10px 30px
        rgba(34,197,94,.20);
}

.brand-name {

    font-size: 20px;

    font-weight: 800;

    letter-spacing: -.5px;
}

.brand-name span {
    color: #22c55e;
}

.top-actions {

    display: flex;

    align-items: center;

    gap: 12px;
}

.nav-btn {

    display: inline-flex;

    align-items: center;

    gap: 8px;

    padding: 10px 15px;

    border-radius: 12px;

    border:
        1px solid rgba(255,255,255,.08);

    background:
        rgba(255,255,255,.035);

    color: #cbd5e1;

    font-size: 13px;

    font-weight: 600;

    transition: .25s ease;
}

.nav-btn:hover {

    transform:
        translateY(-2px);

    background:
        rgba(34,197,94,.10);

    border-color:
        rgba(34,197,94,.25);

    color: white;
}

/* =========================================================
   SAVE NOTIFICATION
========================================================= */

.save-toast {

    position: fixed;

    top: 92px;

    right: 25px;

    z-index: 1500;

    min-width: 290px;

    max-width: 420px;

    padding: 15px 18px;

    border-radius: 15px;

    font-size: 13px;

    font-weight: 700;

    backdrop-filter: blur(18px);

    box-shadow:
        0 20px 60px
        rgba(0,0,0,.35);

    animation:
        toastIn .45s ease both;
}

.save-toast.success {

    color: #86efac;

    background:
        rgba(20,83,45,.78);

    border:
        1px solid rgba(34,197,94,.30);
}

.save-toast.removed {

    color: #67e8f9;

    background:
        rgba(8,47,73,.78);

    border:
        1px solid rgba(6,182,212,.28);
}

.save-toast.error {

    color: #fda4af;

    background:
        rgba(127,29,29,.78);

    border:
        1px solid rgba(248,113,113,.28);
}

/* =========================================================
   PAGE
========================================================= */

.page {

    width:
        min(
            1250px,
            calc(100% - 40px)
        );

    margin: 0 auto;

    padding:
        35px 0 70px;
}

/* =========================================================
   BREADCRUMB
========================================================= */

.breadcrumb {

    display: flex;

    align-items: center;

    gap: 8px;

    color: #64748b;

    font-size: 13px;

    margin-bottom: 24px;
}

.breadcrumb a {

    color: #94a3b8;

    transition: .2s;
}

.breadcrumb a:hover {
    color: #22c55e;
}

/* =========================================================
   PRODUCT LAYOUT
========================================================= */

.product-layout {

    display: grid;

    grid-template-columns:
        minmax(0,1.05fr)
        minmax(380px,.95fr);

    gap: 28px;

    align-items: start;
}

/* =========================================================
   IMAGE
========================================================= */

.image-card {

    position: relative;

    min-height: 560px;

    border-radius: 28px;

    overflow: hidden;

    background:
        linear-gradient(
            145deg,
            rgba(15,23,42,.92),
            rgba(9,15,28,.88)
        );

    border:
        1px solid rgba(255,255,255,.08);

    box-shadow:
        0 30px 80px
        rgba(0,0,0,.35);

    animation:
        fadeUp .7s ease both;
}

.image-card::after {

    content: "";

    position: absolute;

    inset: 0;

    pointer-events: none;

    background:
        linear-gradient(
            135deg,
            rgba(255,255,255,.06),
            transparent 35%
        );
}

.product-image {

    width: 100%;

    height: 560px;

    object-fit: cover;

    display: block;

    transition:
        transform .6s ease;
}

.image-card:hover
.product-image {

    transform:
        scale(1.025);
}

.no-image {

    height: 560px;

    display: flex;

    align-items: center;

    justify-content: center;

    flex-direction: column;

    gap: 15px;

    color: #64748b;
}

.no-image-icon {

    width: 80px;
    height: 80px;

    border-radius: 22px;

    display: flex;

    align-items: center;
    justify-content: center;

    font-size: 35px;

    background:
        rgba(255,255,255,.04);

    border:
        1px solid rgba(255,255,255,.07);
}

.image-badge {

    position: absolute;

    top: 20px;
    left: 20px;

    z-index: 5;

    padding: 9px 13px;

    border-radius: 999px;

    font-size: 12px;

    font-weight: 700;

    background:
        rgba(6,11,22,.72);

    border:
        1px solid rgba(255,255,255,.12);

    backdrop-filter:
        blur(12px);
}

/* =========================================================
   DETAILS
========================================================= */

.details {

    animation:
        fadeUp .7s ease .08s both;
}

.condition-row {

    display: flex;

    align-items: center;

    gap: 10px;

    margin-bottom: 16px;
}

.condition {

    display: inline-flex;

    align-items: center;

    gap: 7px;

    padding: 8px 12px;

    border-radius: 999px;

    font-size: 12px;

    font-weight: 700;

    border: 1px solid;
}

.condition.new {

    color: #22c55e;

    background:
        rgba(34,197,94,.09);

    border-color:
        rgba(34,197,94,.22);
}

.condition.used {

    color: #38bdf8;

    background:
        rgba(56,189,248,.09);

    border-color:
        rgba(56,189,248,.22);
}

.condition.normal {

    color: #c084fc;

    background:
        rgba(192,132,252,.09);

    border-color:
        rgba(192,132,252,.22);
}

.product-id {

    color: #64748b;

    font-size: 12px;
}

.title {

    font-size:
        clamp(30px,4vw,48px);

    line-height: 1.08;

    letter-spacing: -1.5px;

    margin-bottom: 18px;
}

.description {

    color: #94a3b8;

    font-size: 15px;

    line-height: 1.8;

    margin-bottom: 25px;

    white-space: pre-line;
}

/* =========================================================
   PRICE
========================================================= */

.price-box {

    position: relative;

    padding: 21px;

    border-radius: 20px;

    margin-bottom: 22px;

    background:
        linear-gradient(
            135deg,
            rgba(34,197,94,.08),
            rgba(6,182,212,.05)
        );

    border:
        1px solid rgba(34,197,94,.16);

    overflow: hidden;
}

.price-box::before {

    content: "";

    position: absolute;

    width: 180px;
    height: 180px;

    right: -90px;
    top: -100px;

    border-radius: 50%;

    background:
        rgba(34,197,94,.08);

    filter: blur(10px);
}

.price-label {

    color: #64748b;

    font-size: 11px;

    font-weight: 700;

    text-transform: uppercase;

    letter-spacing: 1px;

    margin-bottom: 5px;
}

.price-row {

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;
}

.price {

    font-size: 38px;

    font-weight: 800;

    letter-spacing: -1px;

    color: #22c55e;
}

/* =========================================================
   NEGOTIABLE
========================================================= */

.price-status {

    display: inline-flex;

    align-items: center;

    gap: 8px;

    padding: 10px 14px;

    border-radius: 999px;

    font-size: 12px;

    font-weight: 800;

    white-space: nowrap;
}

.price-status.negotiable {

    color: #22c55e;

    background:
        rgba(34,197,94,.12);

    border:
        1px solid rgba(34,197,94,.25);

    box-shadow:
        0 0 25px
        rgba(34,197,94,.08);
}

.price-status.fixed {

    color: #fb7185;

    background:
        rgba(251,113,133,.10);

    border:
        1px solid rgba(251,113,133,.22);
}

.status-dot {

    width: 8px;
    height: 8px;

    border-radius: 50%;

    background:
        currentColor;

    box-shadow:
        0 0 10px
        currentColor;
}

.negotiable-note {

    margin-top: 10px;

    color: #94a3b8;

    font-size: 12px;
}

/* =========================================================
   INFO
========================================================= */

.info-grid {

    display: grid;

    grid-template-columns:
        repeat(2,minmax(0,1fr));

    gap: 11px;

    margin-bottom: 23px;
}

.info-item {

    padding: 15px;

    border-radius: 15px;

    background:
        rgba(255,255,255,.025);

    border:
        1px solid rgba(255,255,255,.07);

    transition: .25s ease;
}

.info-item:hover {

    transform:
        translateY(-2px);

    border-color:
        rgba(34,197,94,.18);

    background:
        rgba(34,197,94,.035);
}

.info-label {

    display: flex;

    align-items: center;

    gap: 7px;

    color: #64748b;

    font-size: 11px;

    font-weight: 700;

    text-transform: uppercase;

    letter-spacing: .5px;

    margin-bottom: 7px;
}

.info-value {

    color: #e2e8f0;

    font-size: 13px;

    font-weight: 600;

    word-break: break-word;
}

/* =========================================================
   SELLER
========================================================= */

.seller-card {

    display: flex;

    align-items: center;

    gap: 14px;

    padding: 17px;

    border-radius: 18px;

    margin-bottom: 20px;

    background:
        rgba(255,255,255,.025);

    border:
        1px solid rgba(255,255,255,.07);
}

.seller-avatar {

    width: 48px;
    height: 48px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 15px;

    background:
        linear-gradient(
            135deg,
            #22c55e,
            #06b6d4
        );

    font-size: 18px;

    font-weight: 800;
}

.seller-label {

    color: #64748b;

    font-size: 11px;

    margin-bottom: 4px;
}

.seller-name {

    font-size: 14px;

    font-weight: 700;
}

/* =========================================================
   BUTTONS
========================================================= */

.actions {

    display: grid;

    grid-template-columns:
        1fr 1fr;

    gap: 11px;

    margin-bottom: 13px;
}

.btn {

    min-height: 50px;

    border-radius: 14px;

    border:
        1px solid rgba(255,255,255,.08);

    display: flex;

    align-items: center;

    justify-content: center;

    gap: 8px;

    font-size: 13px;

    font-weight: 800;

    cursor: pointer;

    transition: .25s ease;
}

.btn-primary {

    color: white;

    background:
        linear-gradient(
            135deg,
            #22c55e,
            #16a34a
        );

    border-color:
        rgba(34,197,94,.4);

    box-shadow:
        0 10px 30px
        rgba(34,197,94,.14);
}

.btn-primary:hover {

    transform:
        translateY(-2px);

    box-shadow:
        0 15px 35px
        rgba(34,197,94,.22);
}

.btn-secondary {

    color: #cbd5e1;

    background:
        rgba(255,255,255,.035);
}

.btn-secondary:hover {

    transform:
        translateY(-2px);

    color: white;

    border-color:
        rgba(255,255,255,.16);

    background:
        rgba(255,255,255,.06);
}

.btn-wishlist.active {

    color: #fb7185;

    border-color:
        rgba(251,113,133,.25);

    background:
        rgba(251,113,133,.08);

    box-shadow:
        0 10px 30px
        rgba(251,113,133,.07);
}

.wishlist-form {

    margin: 0;

    padding: 0;

    width: 100%;
}

.wishlist-form .btn {

    width: 100%;
}

.wishlist-form .btn:disabled {

    cursor: wait;

    opacity: .65;

    transform: none;
}

.contact-note {

    text-align: center;

    color: #64748b;

    font-size: 11px;

    line-height: 1.6;
}

/* =========================================================
   LOCATION
========================================================= */

.location-card {

    display: flex;

    align-items: center;

    gap: 11px;

    margin-top: 15px;

    padding: 14px 16px;

    border-radius: 15px;

    background:
        rgba(168,85,247,.045);

    border:
        1px solid rgba(168,85,247,.12);
}

.location-icon {

    width: 36px;
    height: 36px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 11px;

    background:
        rgba(168,85,247,.10);

    color: #c084fc;
}

.location-text small {

    display: block;

    color: #64748b;

    font-size: 10px;

    margin-bottom: 3px;
}

.location-text strong {

    font-size: 12px;

    color: #cbd5e1;
}

/* =========================================================
   FOOTER
========================================================= */

.footer {

    margin-top: 55px;

    padding-top: 25px;

    border-top:
        1px solid rgba(255,255,255,.06);

    text-align: center;

    color: #475569;

    font-size: 11px;
}

.footer strong {
    color: #64748b;
}

/* =========================================================
   CONTACT MODAL
========================================================= */

.modal-overlay {

    position: fixed;

    inset: 0;

    z-index: 1000;

    display: none;

    align-items: center;

    justify-content: center;

    padding: 20px;

    background:
        rgba(0,0,0,.72);

    backdrop-filter:
        blur(12px);

    opacity: 0;

    transition:
        opacity .25s ease;
}

.modal-overlay.show {

    display: flex;

    opacity: 1;
}

.contact-modal {

    width: 100%;

    max-width: 470px;

    border-radius: 25px;

    padding: 28px;

    background:
        linear-gradient(
            145deg,
            #101827,
            #0a111e
        );

    border:
        1px solid rgba(255,255,255,.10);

    box-shadow:
        0 30px 100px
        rgba(0,0,0,.55);

    transform:
        translateY(20px)
        scale(.97);

    transition:
        transform .3s ease;
}

.modal-overlay.show
.contact-modal {

    transform:
        translateY(0)
        scale(1);
}

.modal-header {

    display: flex;

    align-items: center;

    justify-content: space-between;

    margin-bottom: 23px;
}

.modal-title {

    display: flex;

    align-items: center;

    gap: 12px;
}

.modal-icon {

    width: 45px;
    height: 45px;

    border-radius: 14px;

    display: flex;

    align-items: center;
    justify-content: center;

    background:
        rgba(34,197,94,.10);

    border:
        1px solid rgba(34,197,94,.20);

    font-size: 20px;
}

.modal-title h2 {

    font-size: 19px;

    margin-bottom: 3px;
}

.modal-title p {

    color: #64748b;

    font-size: 11px;
}

.close-modal {

    width: 36px;
    height: 36px;

    border-radius: 10px;

    border:
        1px solid rgba(255,255,255,.08);

    background:
        rgba(255,255,255,.04);

    color: #94a3b8;

    font-size: 18px;

    cursor: pointer;

    transition: .2s;
}

.close-modal:hover {

    color: white;

    background:
        rgba(255,255,255,.08);
}

/* =========================================================
   SELLER MODAL PROFILE
========================================================= */

.modal-seller {

    display: flex;

    align-items: center;

    gap: 13px;

    padding: 15px;

    border-radius: 16px;

    background:
        rgba(255,255,255,.035);

    border:
        1px solid rgba(255,255,255,.06);

    margin-bottom: 15px;
}

.modal-avatar {

    width: 44px;
    height: 44px;

    border-radius: 13px;

    display: flex;

    align-items: center;
    justify-content: center;

    background:
        linear-gradient(
            135deg,
            #22c55e,
            #06b6d4
        );

    font-weight: 800;
}

.modal-seller small {

    color: #64748b;

    display: block;

    font-size: 10px;

    margin-bottom: 3px;
}

.modal-seller strong {

    font-size: 13px;
}

/* =========================================================
   CONTACT ITEMS
========================================================= */

.contact-list {

    display: flex;

    flex-direction: column;

    gap: 10px;
}

.contact-item {

    display: flex;

    align-items: center;

    gap: 13px;

    padding: 15px;

    border-radius: 15px;

    background:
        rgba(255,255,255,.025);

    border:
        1px solid rgba(255,255,255,.07);
}

.contact-item-icon {

    width: 38px;
    height: 38px;

    border-radius: 11px;

    display: flex;

    align-items: center;
    justify-content: center;

    background:
        rgba(6,182,212,.08);

    color: #38bdf8;

    font-size: 16px;
}

.contact-item-content {

    min-width: 0;
}

.contact-item-content small {

    display: block;

    color: #64748b;

    font-size: 10px;

    margin-bottom: 4px;
}

.contact-item-content strong {

    color: #e2e8f0;

    font-size: 13px;

    word-break: break-word;
}

.no-contact {

    padding: 25px 15px;

    text-align: center;

    color: #64748b;

    font-size: 13px;

    line-height: 1.7;
}

.modal-footer {

    margin-top: 18px;

    padding-top: 16px;

    border-top:
        1px solid rgba(255,255,255,.06);

    color: #475569;

    font-size: 10px;

    text-align: center;

    line-height: 1.6;
}

/* =========================================================
   ANIMATIONS
========================================================= */

@keyframes fadeUp {

    from {
        opacity: 0;
        transform: translateY(20px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }

}

@keyframes toastIn {

    from {
        opacity: 0;
        transform:
            translateY(-15px)
            scale(.97);
    }

    to {
        opacity: 1;
        transform:
            translateY(0)
            scale(1);
    }

}

/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 900px) {

    .topbar {
        padding: 0 20px;
    }

    .page {

        width:
            min(
                100% - 28px,
                700px
            );
    }

    .product-layout {

        grid-template-columns: 1fr;
    }

    .image-card,
    .product-image,
    .no-image {

        min-height: 480px;

        height: 480px;
    }

}

@media (max-width: 600px) {

    .topbar {
        height: 68px;
    }

    .brand-name {
        font-size: 17px;
    }

    .brand-logo {

        width: 38px;

        height: 38px;
    }

    .nav-btn span {
        display: none;
    }

    .page {

        width:
            calc(100% - 22px);

        padding-top: 22px;
    }

    .image-card,
    .product-image,
    .no-image {

        min-height: 330px;

        height: 330px;

        border-radius: 22px;
    }

    .title {
        font-size: 31px;
    }

    .price-row {

        align-items: flex-start;

        flex-direction: column;
    }

    .price {
        font-size: 34px;
    }

    .info-grid {
        grid-template-columns: 1fr;
    }

    .actions {
        grid-template-columns: 1fr;
    }

    .seller-card {
        padding: 14px;
    }

    .contact-modal {
        padding: 22px;
        border-radius: 21px;
    }

    .save-toast {

        left: 15px;

        right: 15px;

        top: 82px;

        min-width: 0;

        max-width: none;
    }

}

/* =========================================================
   PREVENT BODY SCROLL WHEN MODAL OPEN
========================================================= */

body.modal-open {
    overflow: hidden;
}

</style>

</head>

<body>

<?php if ($saveMessage !== ''): ?>

<div
    class="save-toast <?php echo e($saveMessageClass); ?>"
    id="saveToast"
>
    <?php echo e($saveMessage); ?>
</div>

<?php endif; ?>


<!-- =========================================================
     NAVBAR
========================================================= -->

<header class="topbar">

    <a
        href="dashboard.php"
        class="brand"
    >

        <div class="brand-logo">
            E
        </div>

        <div class="brand-name">
            Edu<span>Trade</span> PRO
        </div>

    </a>


    <div class="top-actions">

        <a
            href="marketplace.php"
            class="nav-btn"
        >
            ←
            <span>Marketplace</span>
        </a>

        <a
            href="dashboard.php"
            class="nav-btn"
        >
            🏠
            <span>Dashboard</span>
        </a>

    </div>

</header>


<!-- =========================================================
     MAIN PAGE
========================================================= -->

<main class="page">


    <!-- BREADCRUMB -->

    <div class="breadcrumb">

        <a href="marketplace.php">
            Marketplace
        </a>

        <span>›</span>

        <span>
            Product Details
        </span>

    </div>


    <!-- PRODUCT -->

    <section class="product-layout">


        <!-- =================================================
             PRODUCT IMAGE
        ================================================== -->

        <div class="image-card">

            <div class="image-badge">
                🎓 Campus Marketplace
            </div>


            <?php if ($imageUrl !== ''): ?>

                <img
                    src="<?php echo e($imageUrl); ?>"
                    alt="<?php echo e($title); ?>"
                    class="product-image"
                >

                <div
                    class="no-image"
                    style="display:none;"
                >

                    <div class="no-image-icon">
                        📦
                    </div>

                    <span>
                        Image unavailable
                    </span>

                </div>

            <?php else: ?>

                <div class="no-image">

                    <div class="no-image-icon">
                        📦
                    </div>

                    <span>
                        No image uploaded
                    </span>

                </div>

            <?php endif; ?>

        </div>


        <!-- =================================================
             PRODUCT DETAILS
        ================================================== -->

        <div class="details">


            <!-- CONDITION -->

            <div class="condition-row">

                <div
                    class="condition <?php echo e($conditionClass); ?>"
                >

                    <?php echo $conditionIcon; ?>

                    <?php echo e($condition); ?>

                </div>

                <div class="product-id">

                    Product #
                    <?php echo $productId; ?>

                </div>

            </div>


            <!-- TITLE -->

            <h1 class="title">

                <?php echo e($title); ?>

            </h1>


            <!-- DESCRIPTION -->

            <?php if ($description !== ''): ?>

                <div class="description">

                    <?php echo e($description); ?>

                </div>

            <?php else: ?>

                <div class="description">

                    No description has been provided
                    by the seller.

                </div>

            <?php endif; ?>


            <!-- =================================================
                 PRICE
            ================================================== -->

            <div class="price-box">

                <div class="price-label">
                    Asking Price
                </div>


                <div class="price-row">


                    <div class="price">

                        ₹<?php
                        echo number_format(
                            $price,
                            2
                        );
                        ?>

                    </div>


                    <?php if ($negotiable === 1): ?>

                        <div
                            class="price-status negotiable"
                        >

                            <span
                                class="status-dot"
                            ></span>

                            💬 Price Negotiable

                        </div>

                    <?php else: ?>

                        <div
                            class="price-status fixed"
                        >

                            <span
                                class="status-dot"
                            ></span>

                            🔒 Fixed Price

                        </div>

                    <?php endif; ?>


                </div>


                <?php if ($negotiable === 1): ?>

                    <div class="negotiable-note">

                        The seller is open to
                        reasonable price discussions.

                    </div>

                <?php else: ?>

                    <div class="negotiable-note">

                        The displayed price is fixed
                        by the seller.

                    </div>

                <?php endif; ?>


            </div>


            <!-- =================================================
                 PRODUCT INFORMATION
            ================================================== -->

            <div class="info-grid">


                <div class="info-item">

                    <div class="info-label">
                        ✨ Condition
                    </div>

                    <div class="info-value">

                        <?php echo e($condition); ?>

                    </div>

                </div>


                <div class="info-item">

                    <div class="info-label">
                        ⏳ Product Age
                    </div>

                    <div class="info-value">

                        <?php

                        echo $productAge !== ''
                            ? e($productAge)
                            : 'Not specified';

                        ?>

                    </div>

                </div>


                <div class="info-item">

                    <div class="info-label">
                        📦 Quantity
                    </div>

                    <div class="info-value">

                        <?php

                        echo $quantity > 0
                            ? $quantity . ' available'
                            : 'Out of stock';

                        ?>

                    </div>

                </div>


                <div class="info-item">

                    <div class="info-label">
                        📅 Listed
                    </div>

                    <div class="info-value">

                        <?php
                        echo e($formattedDate);
                        ?>

                    </div>

                </div>


            </div>


            <!-- =================================================
                 SELLER
            ================================================== -->

            <div class="seller-card">

                <div class="seller-avatar">

                    <?php

                    echo strtoupper(
                        substr(
                            $sellerName,
                            0,
                            1
                        )
                    );

                    ?>

                </div>


                <div>

                    <div class="seller-label">
                        Sold by
                    </div>

                    <div class="seller-name">

                        <?php
                        echo e($sellerName);
                        ?>

                    </div>

                </div>

            </div>


            <!-- =================================================
                 ACTIONS
            ================================================== -->

            <div class="actions">



   <!-- MESSAGE SELLER -->

<?php if (!$isOwnProduct && $sellerId > 0): ?>

    <a
        href="messages.php?with=<?php echo $sellerId; ?>"
        class="btn btn-primary"
    >
        💬 Message Seller
    </a>

<?php elseif ($isOwnProduct): ?>

    <div
        class="btn btn-secondary"
        aria-disabled="true"
    >
        🏷️ Your Listing
    </div>

<?php else: ?>

    <div
        class="btn btn-secondary"
        aria-disabled="true"
    >
        Seller Unavailable
    </div>

<?php endif; ?>


<!-- KEEP CONTACT DETAILS MODAL -->

<button
    type="button"
    class="btn btn-secondary"
    onclick="openContactModal()"
>
    📞 Contact Details
</button>

                </button>


                <!-- REAL DATABASE WISHLIST -->

                <form
                    action="../api/save_products.php"
                    method="POST"
                    class="wishlist-form"
                >

                    <input
                        type="hidden"
                        name="product_id"
                        value="<?php echo $productId; ?>"
                    >

                    <button
                        type="submit"
                        class="btn btn-secondary btn-wishlist <?php echo $isSaved ? 'active' : ''; ?>"
                        id="wishlistBtn"
                        title="<?php echo $isSaved ? 'Remove from Wishlist' : 'Save to Wishlist'; ?>"
                    >

                        <?php if ($isSaved): ?>

                            ♥
                            <span>
                                Saved
                            </span>

                        <?php else: ?>

                            ♡
                            <span>
                                Save Product
                            </span>

                        <?php endif; ?>

                    </button>

                </form>


            </div>


            <div class="contact-note">

                Contact the seller to confirm
                availability and arrange the transaction.

            </div>


            <!-- =================================================
                 LOCATION
            ================================================== -->

            <?php if ($location !== ''): ?>

                <div class="location-card">

                    <div class="location-icon">
                        📍
                    </div>

                    <div class="location-text">

                        <small>
                            Seller Location
                        </small>

                        <strong>

                            <?php
                            echo e($location);
                            ?>

                        </strong>

                    </div>

                </div>

            <?php endif; ?>


        </div>

    </section>


    <!-- FOOTER -->

    <footer class="footer">

        <strong>
            EduTrade PRO
        </strong>

        · Campus Marketplace &
        Student Skills Platform

    </footer>


</main>


<!-- =========================================================
     CONTACT SELLER MODAL
========================================================= -->

<div
    class="modal-overlay"
    id="contactModal"
    onclick="outsideModalClick(event)"
>


    <div class="contact-modal">


        <!-- HEADER -->

        <div class="modal-header">


            <div class="modal-title">

                <div class="modal-icon">
                    💬
                </div>

                <div>

                    <h2>
                        Contact Seller
                    </h2>

                    <p>
                        Connect with the product owner
                    </p>

                </div>

            </div>


            <button
                type="button"
                class="close-modal"
                onclick="closeContactModal()"
            >

                ×

            </button>


        </div>


        <!-- SELLER -->

        <div class="modal-seller">

            <div class="modal-avatar">

                <?php

                echo strtoupper(
                    substr(
                        $sellerName,
                        0,
                        1
                    )
                );

                ?>

            </div>


            <div>

                <small>
                    Product Seller
                </small>

                <strong>

                    <?php
                    echo e($sellerName);
                    ?>

                </strong>

            </div>

        </div>


        <!-- CONTACT INFORMATION -->

        <?php if ($hasContact): ?>


            <div class="contact-list">


                <?php if ($contactValue !== ''): ?>

                    <div class="contact-item">

                        <div class="contact-item-icon">

                            <?php

                            if (
                                strtolower(
                                    $contactMethod
                                ) === 'whatsapp'
                            ) {

                                echo "💬";

                            } elseif (
                                strtolower(
                                    $contactMethod
                                ) === 'email'
                            ) {

                                echo "✉️";

                            } elseif (
                                strtolower(
                                    $contactMethod
                                ) === 'phone'
                            ) {

                                echo "📞";

                            } else {

                                echo "📱";

                            }

                            ?>

                        </div>


                        <div class="contact-item-content">

                            <small>

                                <?php

                                echo $contactMethod !== ''
                                    ? e($contactMethod)
                                    : 'Contact';

                                ?>

                            </small>

                            <strong>

                                <?php
                                echo e($contactValue);
                                ?>

                            </strong>

                        </div>

                    </div>

                <?php endif; ?>


                <?php if ($additionalContact !== ''): ?>

                    <div class="contact-item">

                        <div class="contact-item-icon">
                            📌
                        </div>

                        <div class="contact-item-content">

                            <small>
                                Additional Contact
                            </small>

                            <strong>

                                <?php
                                echo e(
                                    $additionalContact
                                );
                                ?>

                            </strong>

                        </div>

                    </div>

                <?php endif; ?>


            </div>


        <?php else: ?>


            <div class="no-contact">

                <div style="font-size:35px;margin-bottom:10px;">
                    📭
                </div>

                <strong
                    style="display:block;color:#cbd5e1;margin-bottom:7px;"
                >
                    No contact information available
                </strong>

                The seller has not provided
                contact information for this product.

            </div>


        <?php endif; ?>


        <!-- MODAL FOOTER -->

        <div class="modal-footer">

            🔐 For your safety, meet in a suitable
            campus/public location and verify the
            product before making payment.

        </div>


    </div>

</div>


<script>

/* =========================================================
   CONTACT MODAL
========================================================= */

function openContactModal() {

    const modal =
        document.getElementById(
            "contactModal"
        );

    modal.style.display = "flex";

    document.body.classList.add(
        "modal-open"
    );

    setTimeout(function() {

        modal.classList.add("show");

    }, 10);
}


function closeContactModal() {

    const modal =
        document.getElementById(
            "contactModal"
        );

    modal.classList.remove("show");

    document.body.classList.remove(
        "modal-open"
    );

    setTimeout(function() {

        modal.style.display = "none";

    }, 250);
}


function outsideModalClick(event) {

    if (
        event.target.id ===
        "contactModal"
    ) {

        closeContactModal();

    }

}


/* =========================================================
   ESC KEY
========================================================= */

document.addEventListener(
    "keydown",
    function(event) {

        if (
            event.key === "Escape"
        ) {

            closeContactModal();

        }

    }
);


/* =========================================================
   WISHLIST SUBMIT UX
========================================================= */

const wishlistForm =
    document.querySelector(
        ".wishlist-form"
    );

if (wishlistForm) {

    wishlistForm.addEventListener(
        "submit",
        function() {

            const button =
                wishlistForm.querySelector(
                    "#wishlistBtn"
                );

            if (button) {

                button.disabled = true;

                button.innerHTML =
                    "⏳ <span>Updating...</span>";

            }

        }
    );

}


/* =========================================================
   AUTO HIDE SAVE NOTIFICATION
========================================================= */

const saveToast =
    document.getElementById(
        "saveToast"
    );

if (saveToast) {

    setTimeout(function() {

        saveToast.style.transition =
            "opacity .35s ease, transform .35s ease";

        saveToast.style.opacity = "0";

        saveToast.style.transform =
            "translateY(-10px)";

        setTimeout(function() {

            saveToast.remove();

        }, 350);

    }, 3000);

}


/* =========================================================
   IMAGE FALLBACK
========================================================= */

document
    .querySelectorAll(".product-image")
    .forEach(function(image) {

        image.addEventListener(
            "error",
            function() {

                image.style.display =
                    "none";

                const fallback =
                    image.nextElementSibling;

                if (fallback) {

                    fallback.style.display =
                        "flex";

                }

            }
        );

    });

</script>


</body>
</html>