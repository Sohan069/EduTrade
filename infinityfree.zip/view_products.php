<?php
include 'auth.php';
include 'db.php';

$result = mysqli_query($conn, "SELECT * FROM products ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Marketplace</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<h2>📚 Student Marketplace</h2>

<div class="grid">
<?php while($row = mysqli_fetch_assoc($result)) { ?>
    <div class="card">
        <img src="uploads/<?php echo $row['image']; ?>" width="100%">
        <h3><?php echo $row['title']; ?></h3>
        <p><?php echo $row['description']; ?></p>
        <p><b>$<?php echo $row['price']; ?></b></p>
    </div>
<?php } ?>
</div>

</body>
</html>