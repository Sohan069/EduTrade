
<?php
/*
|--------------------------------------------------------------------------
| EduTrade PRO - Database Connection
|--------------------------------------------------------------------------
| InfinityFree production database configuration.
*/

$host = "sql101.infinityfree.com";
$user = "if0_43270902";
$pass = "Giere5xvWXYpzf9";
$db   = "if0_43270902_edutrade";
$port = 3306;

mysqli_report(MYSQLI_REPORT_OFF);

$conn = mysqli_connect(
    $host,
    $user,
    $pass,
    $db,
    $port
);

if (!$conn) {
    error_log("EduTrade database connection failed: " . mysqli_connect_error());

    http_response_code(500);
    exit("Unable to connect to the database. Please try again later.");
}

mysqli_set_charset($conn, "utf8mb4");
?>
