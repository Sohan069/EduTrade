
<?php
session_start();

/*
|--------------------------------------------------------------------------
| Existing auth.php handles the actual login.
| This page only displays the login interface.
|--------------------------------------------------------------------------
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Login | EduTrade</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

:root{
    --bg:#050816;
    --card:rgba(15,23,42,.74);

    --cyan:#22d3ee;
    --blue:#3b82f6;
    --purple:#8b5cf6;
    --pink:#ec4899;

    --text:#f8fafc;
    --muted:#94a3b8;

    --border:rgba(255,255,255,.10);
}

/* =========================
   BODY
========================= */

body{

    min-height:100vh;

    font-family:'Poppins',sans-serif;

    color:var(--text);

    display:flex;

    justify-content:center;
    align-items:center;

    overflow:hidden;

    background:
        radial-gradient(
            circle at 10% 15%,
            rgba(34,211,238,.16),
            transparent 30%
        ),
        radial-gradient(
            circle at 90% 10%,
            rgba(139,92,246,.18),
            transparent 30%
        ),
        radial-gradient(
            circle at 80% 90%,
            rgba(236,72,153,.12),
            transparent 30%
        ),
        #050816;

    position:relative;
}


/* =========================
   ANIMATED ORB
========================= */

body::before{

    content:"";

    position:absolute;

    width:650px;
    height:650px;

    border-radius:50%;

    background:
        linear-gradient(
            135deg,
            rgba(34,211,238,.10),
            rgba(59,130,246,.08),
            rgba(139,92,246,.10)
        );

    filter:blur(80px);

    animation:
        moveOrb 12s infinite alternate ease-in-out;

    pointer-events:none;
}

@keyframes moveOrb{

    0%{
        transform:
            translate(-300px,-180px)
            scale(1);
    }

    50%{
        transform:
            translate(150px,100px)
            scale(1.2);
    }

    100%{
        transform:
            translate(-50px,250px)
            scale(.9);
    }

}


/* =========================
   PARTICLES
========================= */

.particle{

    position:absolute;

    width:5px;
    height:5px;

    border-radius:50%;

    background:#22d3ee;

    opacity:.45;

    animation:
        particleFloat 7s infinite ease-in-out;

    pointer-events:none;
}

.p1{
    top:12%;
    left:10%;
}

.p2{
    top:72%;
    left:7%;
    animation-delay:2s;
}

.p3{
    top:20%;
    right:12%;
    animation-delay:4s;
}

.p4{
    bottom:12%;
    right:10%;
    animation-delay:1s;
}

.p5{
    top:50%;
    left:48%;
    animation-delay:3s;
}

@keyframes particleFloat{

    0%,100%{
        transform:translateY(0);
        opacity:.2;
    }

    50%{
        transform:translateY(-35px);
        opacity:.8;
    }

}


/* =========================
   MAIN WRAPPER
========================= */

.wrapper{

    width:100%;

    max-width:1080px;

    display:grid;

    grid-template-columns:
        1fr 430px;

    gap:70px;

    padding:30px;

    position:relative;

    z-index:2;
}


/* =========================
   LEFT INFORMATION
========================= */

.info{

    display:flex;

    flex-direction:column;

    justify-content:center;

    padding:30px;

    animation:
        slideLeft .9s ease;
}

@keyframes slideLeft{

    from{
        opacity:0;
        transform:translateX(-50px);
    }

    to{
        opacity:1;
        transform:translateX(0);
    }

}


/* =========================
   LOGO
========================= */

.logo{

    display:flex;

    align-items:center;

    gap:12px;

    font-size:25px;

    font-weight:800;

    margin-bottom:38px;
}

.logo-icon{

    width:48px;
    height:48px;

    display:flex;

    justify-content:center;
    align-items:center;

    border-radius:15px;

    background:
        linear-gradient(
            135deg,
            var(--cyan),
            var(--blue),
            var(--purple)
        );

    box-shadow:
        0 0 30px rgba(34,211,238,.25);

    font-size:22px;
}

.logo-text{

    background:
        linear-gradient(
            90deg,
            var(--cyan),
            var(--purple),
            var(--pink)
        );

    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}


/* =========================
   LEFT HEADING
========================= */

.info h1{

    font-size:52px;

    line-height:1.12;

    max-width:600px;

    margin-bottom:20px;
}

.gradient-text{

    background:
        linear-gradient(
            90deg,
            var(--cyan),
            var(--blue),
            var(--purple),
            var(--pink)
        );

    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.info-description{

    color:var(--muted);

    max-width:560px;

    font-size:16px;

    line-height:1.8;

    margin-bottom:30px;
}


/* =========================
   FEATURE PILLS
========================= */

.features{

    display:flex;

    flex-wrap:wrap;

    gap:12px;
}

.feature{

    padding:10px 15px;

    border-radius:30px;

    background:
        rgba(255,255,255,.04);

    border:
        1px solid rgba(255,255,255,.08);

    color:#cbd5e1;

    font-size:12px;

    backdrop-filter:blur(10px);

    transition:.3s;
}

.feature:hover{

    transform:translateY(-4px);

    background:
        rgba(34,211,238,.08);

    border-color:
        rgba(34,211,238,.4);

    color:white;
}


/* =========================
   LOGIN CARD
========================= */

.login-card{

    width:100%;

    padding:38px;

    background:var(--card);

    border:
        1px solid var(--border);

    border-radius:28px;

    backdrop-filter:blur(30px);

    -webkit-backdrop-filter:blur(30px);

    box-shadow:
        0 30px 80px rgba(0,0,0,.48),
        inset 0 1px 0 rgba(255,255,255,.08);

    position:relative;

    overflow:hidden;

    animation:
        cardEnter .9s ease;
}

@keyframes cardEnter{

    from{

        opacity:0;

        transform:
            translateY(40px)
            scale(.96);
    }

    to{

        opacity:1;

        transform:
            translateY(0)
            scale(1);
    }

}


/* CARD GLOW */

.login-card::before{

    content:"";

    position:absolute;

    width:240px;
    height:240px;

    top:-130px;
    right:-110px;

    border-radius:50%;

    background:
        rgba(34,211,238,.18);

    filter:blur(65px);
}

.login-card::after{

    content:"";

    position:absolute;

    width:200px;
    height:200px;

    bottom:-110px;
    left:-100px;

    border-radius:50%;

    background:
        rgba(139,92,246,.16);

    filter:blur(65px);
}


/* =========================
   HEADER
========================= */

.form-header{

    position:relative;

    z-index:2;

    margin-bottom:28px;
}

.form-header h2{

    font-size:30px;

    margin-bottom:7px;
}

.form-header p{

    color:var(--muted);

    font-size:13px;
}


/* =========================
   INPUT
========================= */

.input-group{

    position:relative;

    z-index:2;

    margin-bottom:20px;
}

.input-group label{

    display:block;

    color:#cbd5e1;

    font-size:12px;

    margin-bottom:7px;

    font-weight:500;
}

.input-wrapper{

    position:relative;
}

.input-icon{

    position:absolute;

    left:15px;

    top:50%;

    transform:
        translateY(-50%);

    color:#64748b;

    transition:.3s;

    pointer-events:none;
}

.input{

    width:100%;

    height:54px;

    padding:
        0 45px;

    border-radius:14px;

    border:
        1px solid
        rgba(255,255,255,.09);

    outline:none;

    background:
        rgba(2,6,23,.65);

    color:white;

    font-family:'Poppins',sans-serif;

    font-size:13px;

    transition:.3s;
}

.input::placeholder{

    color:#64748b;
}

.input:focus{

    border-color:
        rgba(34,211,238,.7);

    background:
        rgba(2,6,23,.85);

    box-shadow:
        0 0 0 4px
        rgba(34,211,238,.07),

        0 0 25px
        rgba(34,211,238,.08);
}

.input-wrapper:focus-within
.input-icon{

    color:
        var(--cyan);
}


/* =========================
   PASSWORD TOGGLE
========================= */

.password-toggle{

    position:absolute;

    right:14px;

    top:50%;

    transform:
        translateY(-50%);

    border:none;

    background:none;

    color:#64748b;

    cursor:pointer;

    font-size:16px;

    transition:.3s;
}

.password-toggle:hover{

    color:
        var(--cyan);
}


/* =========================
   OPTIONS
========================= */

.options{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-top:-4px;

    margin-bottom:22px;

    position:relative;

    z-index:2;
}

.remember{

    display:flex;

    align-items:center;

    gap:8px;

    color:#94a3b8;

    font-size:11px;
}

.remember input{

    accent-color:
        var(--purple);
}

.forgot{

    color:#22d3ee;

    text-decoration:none;

    font-size:11px;

    transition:.3s;
}

.forgot:hover{

    color:#a78bfa;
}


/* =========================
   LOGIN BUTTON
========================= */

.login-btn{

    width:100%;

    height:55px;

    border:none;

    border-radius:15px;

    background:
        linear-gradient(
            135deg,
            #22d3ee,
            #3b82f6,
            #8b5cf6
        );

    color:white;

    font-family:'Poppins',sans-serif;

    font-size:14px;

    font-weight:600;

    cursor:pointer;

    position:relative;

    overflow:hidden;

    transition:.35s;

    z-index:2;

    box-shadow:
        0 12px 35px
        rgba(59,130,246,.25);
}

.login-btn::before{

    content:"";

    position:absolute;

    top:0;

    left:-120%;

    width:100%;

    height:100%;

    background:
        linear-gradient(
            90deg,
            transparent,
            rgba(255,255,255,.35),
            transparent
        );

    transform:
        skewX(-20deg);

    transition:.6s;
}

.login-btn:hover::before{

    left:120%;
}

.login-btn:hover{

    transform:
        translateY(-3px);

    box-shadow:
        0 18px 45px
        rgba(59,130,246,.4);
}


/* =========================
   LOADING STATE
========================= */

.login-btn.loading{

    pointer-events:none;

    opacity:.85;
}

.spinner{

    width:18px;
    height:18px;

    border:
        2px solid
        rgba(255,255,255,.35);

    border-top-color:white;

    border-radius:50%;

    display:inline-block;

    animation:
        spin .7s linear infinite;

    vertical-align:middle;

    margin-right:8px;
}

@keyframes spin{

    to{
        transform:rotate(360deg);
    }

}


/* =========================
   REGISTER LINK
========================= */

.register-link{

    text-align:center;

    margin-top:23px;

    color:#64748b;

    font-size:12px;

    position:relative;

    z-index:2;
}

.register-link a{

    color:#22d3ee;

    text-decoration:none;

    font-weight:600;

    transition:.3s;
}

.register-link a:hover{

    color:#8b5cf6;
}


/* =========================
   SECURITY
========================= */

.security{

    margin-top:22px;

    padding:12px;

    border-radius:13px;

    background:
        rgba(34,211,238,.05);

    border:
        1px solid
        rgba(34,211,238,.08);

    text-align:center;

    color:#64748b;

    font-size:10px;

    position:relative;

    z-index:2;
}

.security span{

    color:#22d3ee;
}


/* =========================
   RESPONSIVE
========================= */

@media(max-width:850px){

    body{

        overflow:auto;
    }

    .wrapper{

        grid-template-columns:1fr;

        max-width:520px;

        gap:10px;

        padding:20px;
    }

    .info{

        text-align:center;

        padding:10px;
    }

    .info h1{

        font-size:38px;
    }

    .info-description{

        margin-left:auto;

        margin-right:auto;
    }

    .features{

        justify-content:center;
    }

}

@media(max-width:500px){

    .info{

        display:none;
    }

    .login-card{

        padding:25px;

        border-radius:22px;
    }

}

</style>
</head>


<body>


<!-- FLOATING PARTICLES -->

<div class="particle p1"></div>
<div class="particle p2"></div>
<div class="particle p3"></div>
<div class="particle p4"></div>
<div class="particle p5"></div>


<div class="wrapper">


    <!-- =========================
         BRANDING
    ========================== -->

    <section class="info">

        <div class="logo">

            <div class="logo-icon">
                E
            </div>

            <span class="logo-text">
                EduTrade
            </span>

        </div>


        <h1>

            Welcome
            <span class="gradient-text">
                Back.
            </span>

        </h1>


        <p class="info-description">

            Your campus marketplace is waiting.
            Login to discover student products,
            connect with talented students and
            explore the EduTrade Skill Hub.

        </p>


        <div class="features">

            <div class="feature">
                🛒 Marketplace
            </div>

            <div class="feature">
                🎯 Skill Hub
            </div>

            <div class="feature">
                💬 Student Connect
            </div>

            <div class="feature">
                🔐 Secure Access
            </div>

        </div>

    </section>


    <!-- =========================
         LOGIN CARD
    ========================== -->

    <section class="login-card">


        <div class="form-header">

            <h2>
                Welcome Back 👋
            </h2>

            <p>
                Login to continue to your EduTrade account
            </p>

        </div>


        <form
            action="auth.php"
            method="POST"
            id="loginForm"
        >


            <!-- EMAIL -->

            <div class="input-group">

                <label>
                    Email Address
                </label>

                <div class="input-wrapper">

                    <span class="input-icon">
                        ✉️
                    </span>

                    <input
                        type="email"
                        name="email"
                        class="input"
                        placeholder="Enter your email"
                        autocomplete="email"
                        required
                    >

                </div>

            </div>


            <!-- PASSWORD -->

            <div class="input-group">

                <label>
                    Password
                </label>

                <div class="input-wrapper">

                    <span class="input-icon">
                        🔒
                    </span>

                    <input
                        type="password"
                        name="password"
                        id="password"
                        class="input"
                        placeholder="Enter your password"
                        autocomplete="current-password"
                        required
                    >

                    <button
                        type="button"
                        class="password-toggle"
                        onclick="togglePassword()"
                        id="passwordToggle"
                    >
                        👁
                    </button>

                </div>

            </div>


            <!-- OPTIONS -->

            <div class="options">

                <label class="remember">

                    <input
                        type="checkbox"
                        name="remember"
                    >

                    Remember me

                </label>


                <a
                    href="forgot_password.php"
                    class="forgot"
                >
                    Forgot password?
                </a>

            </div>


            <!-- LOGIN BUTTON -->

            <button
                type="submit"
                name="login"
                class="login-btn"
                id="loginButton"
            >

                Login to EduTrade →

            </button>


        </form>


        <!-- REGISTER -->

        <div class="register-link">

            Don't have an account?

            <a href="register.php">
                Create Account
            </a>

        </div>


        <!-- SECURITY -->

        <div class="security">

            🔒
            <span>Secure Login</span>
            •
            Your account is protected

        </div>


    </section>

</div>


<script>

/* =========================
   SHOW / HIDE PASSWORD
========================= */

function togglePassword(){

    const password =
        document.getElementById("password");

    const button =
        document.getElementById("passwordToggle");


    if(password.type === "password"){

        password.type = "text";

        button.textContent = "🙈";

    }
    else{

        password.type = "password";

        button.textContent = "👁";

    }

}


/* =========================
   LOGIN LOADING EFFECT
========================= */

const form =
    document.getElementById("loginForm");

const button =
    document.getElementById("loginButton");


form.addEventListener("submit",function(){

    button.classList.add("loading");

    button.innerHTML =
        '<span class="spinner"></span> Signing in...';

});


/* =========================
   INPUT ANIMATION
========================= */

document
.querySelectorAll(".input")
.forEach(input => {

    input.addEventListener("focus",function(){

        this.parentElement
            .querySelector(".input-icon")
            .style.transform =
            "translateY(-50%) scale(1.1)";

    });

    input.addEventListener("blur",function(){

        this.parentElement
            .querySelector(".input-icon")
            .style.transform =
            "translateY(-50%) scale(1)";

    });

});

</script>


</body>
</html>
```
