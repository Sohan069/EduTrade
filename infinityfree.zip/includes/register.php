<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Register | EduTrade</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

:root{
    --bg:#050816;
    --card:rgba(15,23,42,.72);
    --border:rgba(255,255,255,.10);
    --text:#f8fafc;
    --muted:#94a3b8;
    --cyan:#22d3ee;
    --blue:#3b82f6;
    --purple:#8b5cf6;
    --pink:#ec4899;
}

/* BODY */

body{
    min-height:100vh;
    font-family:'Poppins',sans-serif;
    background:
        radial-gradient(circle at 10% 20%,rgba(34,211,238,.15),transparent 30%),
        radial-gradient(circle at 90% 10%,rgba(139,92,246,.18),transparent 30%),
        radial-gradient(circle at 80% 90%,rgba(236,72,153,.12),transparent 30%),
        #050816;

    color:var(--text);
    display:flex;
    justify-content:center;
    align-items:center;

    overflow:hidden;
    position:relative;
}

/* ANIMATED BACKGROUND */

body::before{
    content:"";
    position:absolute;
    width:600px;
    height:600px;

    background:linear-gradient(
        135deg,
        rgba(34,211,238,.10),
        rgba(139,92,246,.08),
        rgba(236,72,153,.08)
    );

    filter:blur(80px);
    border-radius:50%;

    animation:orbMove 12s infinite alternate ease-in-out;

    pointer-events:none;
}

@keyframes orbMove{

    0%{
        transform:translate(-250px,-150px) scale(1);
    }

    50%{
        transform:translate(150px,100px) scale(1.2);
    }

    100%{
        transform:translate(-50px,250px) scale(.9);
    }

}

/* FLOATING DOTS */

.particle{
    position:absolute;
    width:5px;
    height:5px;

    background:#22d3ee;

    border-radius:50%;

    opacity:.5;

    animation:float 8s infinite ease-in-out;
}

.p1{
    top:15%;
    left:12%;
}

.p2{
    top:70%;
    left:8%;
    animation-delay:2s;
}

.p3{
    top:25%;
    right:12%;
    animation-delay:4s;
}

.p4{
    bottom:12%;
    right:15%;
    animation-delay:1s;
}

@keyframes float{

    0%,100%{
        transform:translateY(0);
        opacity:.25;
    }

    50%{
        transform:translateY(-35px);
        opacity:.8;
    }

}

/* MAIN WRAPPER */

.wrapper{
    width:100%;
    max-width:1100px;

    display:grid;
    grid-template-columns:1fr 430px;

    gap:60px;

    padding:30px;

    position:relative;
    z-index:2;
}

/* LEFT SIDE */

.info{
    display:flex;
    flex-direction:column;
    justify-content:center;

    padding:30px;

    animation:slideLeft .9s ease;
}

@keyframes slideLeft{

    from{
        opacity:0;
        transform:translateX(-50px);
    }

    to{
        opacity:1;
        transform:translateX(0);
    }

}

/* LOGO */

.logo{
    display:flex;
    align-items:center;
    gap:12px;

    font-size:25px;
    font-weight:800;

    margin-bottom:35px;
}

.logo-icon{
    width:48px;
    height:48px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:15px;

    background:linear-gradient(
        135deg,
        var(--cyan),
        var(--blue),
        var(--purple)
    );

    box-shadow:
        0 0 25px rgba(34,211,238,.25);

    font-size:23px;
}

.logo span{
    background:linear-gradient(
        90deg,
        #22d3ee,
        #8b5cf6,
        #ec4899
    );

    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

/* LEFT HEADING */

.info h1{
    font-size:52px;
    line-height:1.12;

    max-width:600px;

    margin-bottom:20px;
}

.gradient-text{
    background:linear-gradient(
        90deg,
        #22d3ee,
        #3b82f6,
        #8b5cf6,
        #ec4899
    );

    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.info-description{
    color:var(--muted);

    max-width:570px;

    line-height:1.8;

    font-size:16px;

    margin-bottom:30px;
}

/* FEATURES */

.features{
    display:flex;
    flex-wrap:wrap;

    gap:12px;
}

.feature{
    padding:10px 15px;

    border:1px solid rgba(255,255,255,.08);

    background:rgba(255,255,255,.04);

    border-radius:30px;

    color:#cbd5e1;

    font-size:13px;

    backdrop-filter:blur(10px);

    transition:.3s;
}

.feature:hover{
    transform:translateY(-4px);

    border-color:rgba(34,211,238,.4);

    background:rgba(34,211,238,.08);

    color:white;
}

/* REGISTER CARD */

.register-card{

    width:100%;

    padding:38px;

    background:var(--card);

    border:1px solid var(--border);

    border-radius:28px;

    backdrop-filter:blur(30px);

    -webkit-backdrop-filter:blur(30px);

    box-shadow:
        0 30px 80px rgba(0,0,0,.45),
        inset 0 1px 0 rgba(255,255,255,.08);

    animation:cardEnter .9s ease;

    position:relative;

    overflow:hidden;
}

@keyframes cardEnter{

    from{
        opacity:0;
        transform:translateY(40px) scale(.96);
    }

    to{
        opacity:1;
        transform:translateY(0) scale(1);
    }

}

/* CARD GLOW */

.register-card::before{

    content:"";

    position:absolute;

    width:220px;
    height:220px;

    top:-120px;
    right:-100px;

    background:rgba(34,211,238,.18);

    filter:blur(60px);

    border-radius:50%;

}

.register-card::after{

    content:"";

    position:absolute;

    width:180px;
    height:180px;

    bottom:-100px;
    left:-80px;

    background:rgba(139,92,246,.15);

    filter:blur(60px);

    border-radius:50%;

}

/* HEADER */

.form-header{
    position:relative;
    z-index:2;

    margin-bottom:25px;
}

.form-header h2{
    font-size:29px;

    margin-bottom:7px;
}

.form-header p{
    color:var(--muted);

    font-size:13px;
}

/* INPUT GROUP */

.input-group{

    position:relative;

    margin-bottom:18px;

    z-index:2;
}

.input-group label{

    display:block;

    color:#cbd5e1;

    font-size:12px;

    margin-bottom:7px;

    font-weight:500;
}

.input-wrapper{
    position:relative;
}

.input-icon{

    position:absolute;

    left:15px;

    top:50%;

    transform:translateY(-50%);

    font-size:16px;

    color:#64748b;

    pointer-events:none;

    transition:.3s;
}

.input{

    width:100%;

    height:52px;

    padding:0 45px;

    border-radius:14px;

    border:1px solid rgba(255,255,255,.09);

    outline:none;

    background:rgba(2,6,23,.65);

    color:white;

    font-family:'Poppins',sans-serif;

    font-size:13px;

    transition:.3s;
}

.input::placeholder{
    color:#64748b;
}

.input:focus{

    border-color:rgba(34,211,238,.7);

    box-shadow:
        0 0 0 4px rgba(34,211,238,.08),
        0 0 25px rgba(34,211,238,.08);

    background:rgba(2,6,23,.85);
}

.input-wrapper:focus-within .input-icon{
    color:var(--cyan);
}

/* PASSWORD BUTTON */

.password-toggle{

    position:absolute;

    right:14px;

    top:50%;

    transform:translateY(-50%);

    border:none;

    background:none;

    color:#64748b;

    cursor:pointer;

    font-size:16px;

    transition:.3s;
}

.password-toggle:hover{
    color:#22d3ee;
}

/* PASSWORD STRENGTH */

.strength{

    height:4px;

    width:100%;

    background:rgba(255,255,255,.08);

    border-radius:10px;

    margin-top:8px;

    overflow:hidden;
}

.strength-bar{

    height:100%;

    width:0%;

    border-radius:10px;

    transition:.4s;
}

.strength-text{

    font-size:10px;

    color:#64748b;

    margin-top:5px;
}

/* CHECKBOX */

.terms{

    display:flex;

    gap:9px;

    align-items:flex-start;

    color:#94a3b8;

    font-size:11px;

    line-height:1.5;

    margin:18px 0;

    position:relative;

    z-index:2;
}

.terms input{

    margin-top:3px;

    accent-color:#8b5cf6;
}

/* REGISTER BUTTON */

.register-btn{

    width:100%;

    height:54px;

    border:none;

    border-radius:15px;

    background:linear-gradient(
        135deg,
        #22d3ee,
        #3b82f6,
        #8b5cf6
    );

    color:white;

    font-family:'Poppins',sans-serif;

    font-size:14px;

    font-weight:600;

    cursor:pointer;

    position:relative;

    overflow:hidden;

    transition:.35s;

    z-index:2;

    box-shadow:
        0 10px 30px rgba(59,130,246,.25);
}

.register-btn::before{

    content:"";

    position:absolute;

    top:0;
    left:-120%;

    width:100%;
    height:100%;

    background:linear-gradient(
        90deg,
        transparent,
        rgba(255,255,255,.35),
        transparent
    );

    transform:skewX(-20deg);

    transition:.6s;
}

.register-btn:hover::before{
    left:120%;
}

.register-btn:hover{

    transform:translateY(-3px);

    box-shadow:
        0 15px 40px rgba(59,130,246,.4);
}

/* LOGIN */

.login-link{

    text-align:center;

    margin-top:22px;

    color:#64748b;

    font-size:12px;

    position:relative;

    z-index:2;
}

.login-link a{

    color:#22d3ee;

    text-decoration:none;

    font-weight:600;

    transition:.3s;
}

.login-link a:hover{
    color:#8b5cf6;
}

/* SECURITY BADGE */

.security{

    margin-top:22px;

    padding:11px;

    border-radius:12px;

    background:rgba(34,211,238,.05);

    border:1px solid rgba(34,211,238,.08);

    text-align:center;

    color:#64748b;

    font-size:10px;

    position:relative;

    z-index:2;
}

.security span{
    color:#22d3ee;
}

/* MOBILE */

@media(max-width:850px){

    body{
        overflow:auto;
    }

    .wrapper{

        grid-template-columns:1fr;

        max-width:520px;

        gap:10px;

        padding:20px;
    }

    .info{
        text-align:center;

        padding:10px;
    }

    .info h1{
        font-size:38px;
    }

    .info-description{
        margin-left:auto;
        margin-right:auto;
    }

    .features{
        justify-content:center;
    }

}

@media(max-width:500px){

    .register-card{
        padding:25px;

        border-radius:22px;
    }

    .info{
        display:none;
    }

}

</style>
</head>

<body>

<!-- BACKGROUND PARTICLES -->

<div class="particle p1"></div>
<div class="particle p2"></div>
<div class="particle p3"></div>
<div class="particle p4"></div>


<div class="wrapper">

    <!-- LEFT BRANDING -->

    <section class="info">

        <div class="logo">
            <div class="logo-icon">E</div>
            <span>EduTrade</span>
        </div>

        <h1>
            Your Campus.
            <span class="gradient-text">
                Your Marketplace.
            </span>
        </h1>

        <p class="info-description">
            Join EduTrade and connect with students around your campus.
            Buy useful products, sell your old items and showcase your
            skills — all from one powerful student platform.
        </p>

        <div class="features">

            <div class="feature">
                🛒 Student Marketplace
            </div>

            <div class="feature">
                🎯 Skill Hub
            </div>

            <div class="feature">
                🔐 Secure Accounts
            </div>

            <div class="feature">
                🚀 Campus Community
            </div>

        </div>

    </section>


    <!-- REGISTER FORM -->

    <section class="register-card">

        <div class="form-header">

            <h2>Create Account ✨</h2>

            <p>
                Create your EduTrade student account
            </p>

        </div>


        <form action="auth.php" method="POST" id="registerForm">

            <!-- NAME -->

            <div class="input-group">

                <label>Full Name</label>

                <div class="input-wrapper">

                    <span class="input-icon">👤</span>

                    <input
                        type="text"
                        name="name"
                        class="input"
                        placeholder="Enter your full name"
                        autocomplete="name"
                        required
                    >

                </div>

            </div>


            <!-- EMAIL -->

            <div class="input-group">

                <label>College / Student Email</label>

                <div class="input-wrapper">

                    <span class="input-icon">✉️</span>

                    <input
                        type="email"
                        name="email"
                        class="input"
                        placeholder="Enter your email"
                        autocomplete="email"
                        required
                    >

                </div>

            </div>


            <!-- PASSWORD -->

            <div class="input-group">

                <label>Password</label>

                <div class="input-wrapper">

                    <span class="input-icon">🔒</span>

                    <input
                        type="password"
                        name="password"
                        id="password"
                        class="input"
                        placeholder="Create a strong password"
                        autocomplete="new-password"
                        required
                    >

                    <button
                        type="button"
                        class="password-toggle"
                        onclick="togglePassword('password',this)"
                    >
                        👁
                    </button>

                </div>

                <div class="strength">
                    <div
                        class="strength-bar"
                        id="strengthBar"
                    ></div>
                </div>

                <div
                    class="strength-text"
                    id="strengthText"
                >
                    Password strength
                </div>

            </div>


            <!-- CONFIRM PASSWORD -->

            <div class="input-group">

                <label>Confirm Password</label>

                <div class="input-wrapper">

                    <span class="input-icon">🔐</span>

                    <input
                        type="password"
                        name="confirm_password"
                        id="confirmPassword"
                        class="input"
                        placeholder="Confirm your password"
                        autocomplete="new-password"
                        required
                    >

                    <button
                        type="button"
                        class="password-toggle"
                        onclick="togglePassword('confirmPassword',this)"
                    >
                        👁
                    </button>

                </div>

            </div>


            <!-- TERMS -->

            <label class="terms">

                <input
                    type="checkbox"
                    name="terms"
                    required
                >

                <span>
                    I agree to the EduTrade terms and understand that
                    this platform is intended for student/campus use.
                </span>

            </label>


            <!-- BUTTON -->

            <button
                type="submit"
                name="register"
                class="register-btn"
            >
                Create My EduTrade Account →
            </button>

        </form>


        <!-- LOGIN -->

        <div class="login-link">

            Already have an account?

            <a href="login.php">
                Login here
            </a>

        </div>


        <!-- SECURITY -->

        <div class="security">

            🔒 <span>Secure registration</span>
            • Your account information is protected

        </div>

    </section>

</div>


<script>

/* PASSWORD SHOW / HIDE */

function togglePassword(id,button){

    const input = document.getElementById(id);

    if(input.type === "password"){

        input.type = "text";

        button.textContent = "🙈";

    }else{

        input.type = "password";

        button.textContent = "👁";

    }

}


/* PASSWORD STRENGTH */

const password =
document.getElementById("password");

const strengthBar =
document.getElementById("strengthBar");

const strengthText =
document.getElementById("strengthText");


password.addEventListener("input",function(){

    const value = password.value;

    let score = 0;

    if(value.length >= 6)
        score++;

    if(value.length >= 10)
        score++;

    if(/[A-Z]/.test(value))
        score++;

    if(/[0-9]/.test(value))
        score++;

    if(/[^A-Za-z0-9]/.test(value))
        score++;


    const percentage = score * 20;

    strengthBar.style.width =
        percentage + "%";


    if(score <= 1){

        strengthText.textContent =
            "Weak password";

        strengthBar.style.background =
            "#ef4444";

    }

    else if(score <= 3){

        strengthText.textContent =
            "Medium password";

        strengthBar.style.background =
            "#f59e0b";

    }

    else{

        strengthText.textContent =
            "Strong password";

        strengthBar.style.background =
            "#22c55e";

    }

});


/* CONFIRM PASSWORD */

const form =
document.getElementById("registerForm");

form.addEventListener("submit",function(e){

    const pass =
        document.getElementById("password").value;

    const confirm =
        document.getElementById("confirmPassword").value;


    if(pass !== confirm){

        e.preventDefault();

        alert("Passwords do not match.");

        return false;

    }

});

</script>

</body>
</html>