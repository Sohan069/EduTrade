```php
<?php

session_start();

require_once '../config/db.php';

/*
|--------------------------------------------------------------------------
| EduTrade Authentication Controller
|--------------------------------------------------------------------------
| Handles:
| 1. Student Registration
| 2. Student Login
| 3. Logout
|--------------------------------------------------------------------------
*/


/* =========================================================
   HELPER FUNCTIONS
========================================================= */

function redirectWithMessage($location, $message)
{
    $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

    echo "
    <script>
        alert(" . json_encode($message) . ");
        window.location.href = " . json_encode($location) . ";
    </script>
    ";

    exit();
}


/* =========================================================
   CHECK DATABASE CONNECTION
========================================================= */

if (!isset($conn) || !$conn) {

    redirectWithMessage(
        '../includes/login.php',
        'Database connection failed. Please try again.'
    );
}


/* =========================================================
   REGISTER USER
========================================================= */

if (isset($_POST['register'])) {

    /* -----------------------------------------
       Get form values
    ----------------------------------------- */

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';


    /* -----------------------------------------
       Basic validation
    ----------------------------------------- */

    if ($name === '' || $email === '' || $password === '') {

        redirectWithMessage(
            '../includes/register.php',
            'Please fill in all required fields.'
        );
    }


    /* -----------------------------------------
       Name validation
    ----------------------------------------- */

    if (strlen($name) < 2) {

        redirectWithMessage(
            '../includes/register.php',
            'Please enter a valid full name.'
        );
    }


    /* -----------------------------------------
       Email validation
    ----------------------------------------- */

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        redirectWithMessage(
            '../includes/register.php',
            'Please enter a valid email address.'
        );
    }


    /* -----------------------------------------
       Password confirmation
    ----------------------------------------- */

    if ($confirmPassword !== '' && $password !== $confirmPassword) {

        redirectWithMessage(
            '../includes/register.php',
            'Passwords do not match.'
        );
    }


    /* -----------------------------------------
       Password length
    ----------------------------------------- */

    if (strlen($password) < 6) {

        redirectWithMessage(
            '../includes/register.php',
            'Password must contain at least 6 characters.'
        );
    }


    /* -----------------------------------------
       Check existing email
       Prepared statement
    ----------------------------------------- */

    $check = mysqli_prepare(
        $conn,
        "SELECT id FROM users WHERE email = ? LIMIT 1"
    );

    mysqli_stmt_bind_param(
        $check,
        "s",
        $email
    );

    mysqli_stmt_execute($check);

    $result = mysqli_stmt_get_result($check);

    if (mysqli_num_rows($result) > 0) {

        mysqli_stmt_close($check);

        redirectWithMessage(
            '../includes/register.php',
            'This email is already registered.'
        );
    }

    mysqli_stmt_close($check);


    /* -----------------------------------------
       Hash password
    ----------------------------------------- */

    $hashedPassword = password_hash(
        $password,
        PASSWORD_DEFAULT
    );


    /* -----------------------------------------
       Insert student
    ----------------------------------------- */

    $insert = mysqli_prepare(
        $conn,
        "INSERT INTO users (name, email, password)
         VALUES (?, ?, ?)"
    );

    mysqli_stmt_bind_param(
        $insert,
        "sss",
        $name,
        $email,
        $hashedPassword
    );


    if (mysqli_stmt_execute($insert)) {

        mysqli_stmt_close($insert);

        redirectWithMessage(
            '../includes/login.php',
            'Registration successful! Please login to continue.'
        );

    } else {

        mysqli_stmt_close($insert);

        redirectWithMessage(
            '../includes/register.php',
            'Registration failed. Please try again.'
        );
    }
}


/* =========================================================
   LOGIN USER
========================================================= */

if (isset($_POST['login'])) {

    /* -----------------------------------------
       Get login values
    ----------------------------------------- */

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';


    /* -----------------------------------------
       Validation
    ----------------------------------------- */

    if ($email === '' || $password === '') {

        redirectWithMessage(
            '../includes/login.php',
            'Please enter your email and password.'
        );
    }


    /* -----------------------------------------
       Validate email
    ----------------------------------------- */

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        redirectWithMessage(
            '../includes/login.php',
            'Please enter a valid email address.'
        );
    }


    /* -----------------------------------------
       Find user
    ----------------------------------------- */

    $query = mysqli_prepare(
        $conn,
        "SELECT id, name, email, password
         FROM users
         WHERE email = ?
         LIMIT 1"
    );

    mysqli_stmt_bind_param(
        $query,
        "s",
        $email
    );

    mysqli_stmt_execute($query);

    $result = mysqli_stmt_get_result($query);


    /* -----------------------------------------
       User not found
    ----------------------------------------- */

    if (mysqli_num_rows($result) !== 1) {

        mysqli_stmt_close($query);

        redirectWithMessage(
            '../includes/login.php',
            'Invalid email or password.'
        );
    }


    /* -----------------------------------------
       Get user
    ----------------------------------------- */

    $user = mysqli_fetch_assoc($result);

    mysqli_stmt_close($query);


    /* -----------------------------------------
       Verify password
    ----------------------------------------- */

    if (!password_verify($password, $user['password'])) {

        redirectWithMessage(
            '../includes/login.php',
            'Invalid email or password.'
        );
    }


    /* -----------------------------------------
       Login successful
       Regenerate session ID
    ----------------------------------------- */

    session_regenerate_id(true);


    $_SESSION['logged_in'] = true;

    $_SESSION['user_id'] = $user['id'];

    $_SESSION['name'] = $user['name'];

    $_SESSION['email'] = $user['email'];


    /* -----------------------------------------
       Redirect to dashboard
    ----------------------------------------- */

    header("Location: ../pages/dashboard.php");

    exit();
}


/* =========================================================
   LOGOUT
========================================================= */

if (isset($_GET['logout'])) {

    /* Remove all session data */

    $_SESSION = [];


    /* Destroy session cookie */

    if (ini_get("session.use_cookies")) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }


    /* Destroy session */

    session_destroy();


    /* Redirect */

    redirectWithMessage(
        '../index.php',
        'You have been logged out successfully.'
    );
}


/* =========================================================
   NO VALID ACTION
========================================================= */

if (
    !isset($_POST['register']) &&
    !isset($_POST['login']) &&
    !isset($_GET['logout'])
) {

    header("Location: ../index.php");

    exit();
}

?>
```
