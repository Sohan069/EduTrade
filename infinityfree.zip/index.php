<?php
session_start();
include 'config/db.php';

/*
|--------------------------------------------------------------------------
| EDU TRADE - INDEX PAGE
|--------------------------------------------------------------------------
| Existing database tables used:
| users
| products
| skills
|--------------------------------------------------------------------------
*/

// Fetch live statistics safely
$students = 0;
$products = 0;
$skills   = 0;

$result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users");
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $students = (int)$row['total'];
}

$result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM products");
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $products = (int)$row['total'];
}

$result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM skills");
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $skills = (int)$row['total'];
}

// Login status
$isLoggedIn = isset($_SESSION['user_id']);
$userName = $_SESSION['name'] ?? 'Student';
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>EduTrade | Campus Marketplace & Skill Hub</title>

<meta
    name="description"
    content="EduTrade is a student-focused campus marketplace and skill hub where students can buy, sell, showcase skills and connect."
>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link
    href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@400;500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://unpkg.com/aos@2.3.4/dist/aos.css"
>

<style>

/* =========================================================
   RESET
========================================================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

html{
    scroll-behavior:smooth;
}

body{
    font-family:'Inter',sans-serif;
    background:#050816;
    color:#f8fafc;
    overflow-x:hidden;
}

a{
    text-decoration:none;
    color:inherit;
}

button{
    font-family:inherit;
}


/* =========================================================
   CUSTOM SCROLLBAR
========================================================= */

::-webkit-scrollbar{
    width:8px;
}

::-webkit-scrollbar-track{
    background:#050816;
}

::-webkit-scrollbar-thumb{
    background:linear-gradient(
        180deg,
        #06b6d4,
        #7c3aed
    );
    border-radius:20px;
}


/* =========================================================
   BACKGROUND
========================================================= */

.background{
    position:fixed;
    inset:0;
    z-index:-10;
    overflow:hidden;
    pointer-events:none;
}

.grid{
    position:absolute;
    inset:0;

    background-image:
        linear-gradient(
            rgba(255,255,255,.025) 1px,
            transparent 1px
        ),
        linear-gradient(
            90deg,
            rgba(255,255,255,.025) 1px,
            transparent 1px
        );

    background-size:50px 50px;

    mask-image:linear-gradient(
        to bottom,
        black,
        transparent 90%
    );
}

.orb{
    position:absolute;
    border-radius:50%;
    filter:blur(100px);
    opacity:.35;
    animation:floatOrb 12s ease-in-out infinite;
}

.orb.one{
    width:420px;
    height:420px;
    background:#06b6d4;
    top:-150px;
    left:-120px;
}

.orb.two{
    width:500px;
    height:500px;
    background:#7c3aed;
    top:300px;
    right:-180px;
    animation-delay:2s;
}

.orb.three{
    width:350px;
    height:350px;
    background:#ec4899;
    bottom:0;
    left:25%;
    animation-delay:4s;
}

@keyframes floatOrb{

    0%,100%{
        transform:translate(0,0) scale(1);
    }

    50%{
        transform:translate(40px,-30px) scale(1.1);
    }

}


/* =========================================================
   NAVBAR
========================================================= */

.navbar{
    position:fixed;
    top:0;
    left:0;
    width:100%;
    z-index:1000;

    padding:18px 6%;

    display:flex;
    align-items:center;
    justify-content:space-between;

    background:rgba(5,8,22,.68);
    backdrop-filter:blur(22px);
    -webkit-backdrop-filter:blur(22px);

    border-bottom:1px solid rgba(255,255,255,.07);

    transition:.3s ease;
}

.logo{
    display:flex;
    align-items:center;
    gap:10px;

    font-family:'Poppins',sans-serif;
    font-size:24px;
    font-weight:800;
    letter-spacing:-.7px;
}

.logo-mark{
    width:40px;
    height:40px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:13px;

    background:linear-gradient(
        135deg,
        #06b6d4,
        #6366f1,
        #a855f7
    );

    box-shadow:
        0 10px 35px rgba(99,102,241,.35);

    font-size:20px;
}

.logo span{
    background:linear-gradient(
        90deg,
        #67e8f9,
        #818cf8,
        #c084fc
    );

    -webkit-background-clip:text;
    background-clip:text;
    color:transparent;
}

.nav-links{
    display:flex;
    align-items:center;
    gap:10px;
}

.nav-links a{
    padding:10px 16px;

    color:#94a3b8;

    font-size:14px;
    font-weight:600;

    border-radius:12px;

    transition:.3s ease;
}

.nav-links a:hover{
    color:#fff;
    background:rgba(255,255,255,.06);
}

.nav-login{
    border:1px solid rgba(255,255,255,.1);
}

.nav-register{
    background:linear-gradient(
        135deg,
        #06b6d4,
        #6366f1
    ) !important;

    color:white !important;

    box-shadow:
        0 8px 25px rgba(99,102,241,.25);
}

.nav-register:hover{
    transform:translateY(-2px);
    box-shadow:
        0 12px 35px rgba(99,102,241,.4);
}

.mobile-menu{
    display:none;
    font-size:24px;
    cursor:pointer;
}


/* =========================================================
   HERO
========================================================= */

.hero{
    min-height:100vh;

    padding:
        170px 6%
        100px;

    display:flex;
    align-items:center;
    justify-content:center;

    text-align:center;

    position:relative;
}

.hero-content{
    max-width:950px;
}

.badge{
    display:inline-flex;
    align-items:center;
    gap:9px;

    padding:9px 16px;

    border:1px solid rgba(103,232,249,.2);

    background:rgba(6,182,212,.07);

    border-radius:100px;

    color:#67e8f9;

    font-size:13px;
    font-weight:600;

    margin-bottom:28px;

    box-shadow:
        0 0 30px rgba(6,182,212,.08);

    animation:badgePulse 3s ease-in-out infinite;
}

.badge-dot{
    width:7px;
    height:7px;
    border-radius:50%;
    background:#22d3ee;

    box-shadow:
        0 0 12px #22d3ee;
}

@keyframes badgePulse{

    0%,100%{
        transform:translateY(0);
    }

    50%{
        transform:translateY(-3px);
    }

}

.hero h1{
    font-family:'Poppins',sans-serif;

    font-size:
        clamp(48px,7vw,88px);

    line-height:1.02;

    font-weight:800;

    letter-spacing:-4px;

    margin-bottom:25px;
}

.gradient-text{
    background:linear-gradient(
        90deg,
        #67e8f9,
        #818cf8,
        #c084fc,
        #f0abfc
    );

    background-size:300% auto;

    -webkit-background-clip:text;
    background-clip:text;
    color:transparent;

    animation:gradientMove 6s linear infinite;
}

@keyframes gradientMove{

    0%{
        background-position:0% center;
    }

    100%{
        background-position:300% center;
    }

}

.hero-description{
    max-width:700px;
    margin:0 auto;

    color:#94a3b8;

    font-size:18px;
    line-height:1.8;
}

.hero-actions{
    margin-top:38px;

    display:flex;
    justify-content:center;
    gap:14px;

    flex-wrap:wrap;
}

.primary-btn,
.secondary-btn{

    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:10px;

    min-width:160px;

    padding:15px 25px;

    border-radius:14px;

    font-size:14px;
    font-weight:700;

    transition:.35s ease;
}

.primary-btn{
    color:white;

    background:
        linear-gradient(
            135deg,
            #06b6d4,
            #6366f1,
            #8b5cf6
        );

    box-shadow:
        0 15px 40px rgba(99,102,241,.25);
}

.primary-btn:hover{
    transform:translateY(-4px);
    box-shadow:
        0 20px 50px rgba(99,102,241,.4);
}

.secondary-btn{
    color:#cbd5e1;

    border:1px solid rgba(255,255,255,.12);

    background:rgba(255,255,255,.04);

    backdrop-filter:blur(10px);
}

.secondary-btn:hover{
    color:white;
    border-color:rgba(103,232,249,.35);
    background:rgba(6,182,212,.08);
    transform:translateY(-4px);
}


/* =========================================================
   HERO FLOATING CARDS
========================================================= */

.floating-card{
    position:absolute;

    padding:15px 18px;

    display:flex;
    align-items:center;
    gap:12px;

    border-radius:17px;

    background:rgba(15,23,42,.7);

    border:1px solid rgba(255,255,255,.09);

    backdrop-filter:blur(18px);

    box-shadow:
        0 20px 50px rgba(0,0,0,.25);

    animation:floatCard 5s ease-in-out infinite;
}

.floating-card strong{
    display:block;
    font-size:13px;
}

.floating-card small{
    color:#64748b;
    font-size:11px;
}

.float-icon{
    width:38px;
    height:38px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:11px;

    background:rgba(99,102,241,.15);
}

.float-one{
    left:6%;
    top:38%;
}

.float-two{
    right:6%;
    top:50%;
    animation-delay:1.5s;
}

@keyframes floatCard{

    0%,100%{
        transform:translateY(0);
    }

    50%{
        transform:translateY(-15px);
    }

}


/* =========================================================
   SECTION
========================================================= */

.section{
    padding:110px 6%;
    position:relative;
}

.section-header{
    max-width:720px;
    margin:0 auto 55px;
    text-align:center;
}

.section-label{
    color:#67e8f9;

    font-size:12px;
    font-weight:800;

    letter-spacing:2px;
    text-transform:uppercase;

    margin-bottom:12px;
}

.section-title{
    font-family:'Poppins',sans-serif;

    font-size:
        clamp(32px,4vw,52px);

    letter-spacing:-2px;

    margin-bottom:15px;
}

.section-description{
    color:#64748b;
    line-height:1.8;
}


/* =========================================================
   STATS
========================================================= */

.stats-grid{
    max-width:1100px;
    margin:auto;

    display:grid;
    grid-template-columns:
        repeat(3,1fr);

    gap:20px;
}

.stat-card{
    position:relative;

    padding:35px;

    border-radius:24px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.07),
            rgba(255,255,255,.025)
        );

    border:1px solid rgba(255,255,255,.08);

    overflow:hidden;

    transition:.4s ease;
}

.stat-card::before{
    content:"";

    position:absolute;

    width:160px;
    height:160px;

    border-radius:50%;

    background:#6366f1;

    filter:blur(80px);

    opacity:.08;

    right:-50px;
    top:-50px;
}

.stat-card:hover{
    transform:translateY(-8px);

    border-color:
        rgba(103,232,249,.25);

    box-shadow:
        0 25px 60px rgba(0,0,0,.25);
}

.stat-icon{
    width:45px;
    height:45px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:14px;

    background:rgba(99,102,241,.12);

    margin-bottom:22px;

    font-size:20px;
}

.stat-number{
    font-family:'Poppins',sans-serif;

    font-size:42px;
    font-weight:800;

    background:
        linear-gradient(
            90deg,
            #67e8f9,
            #a78bfa
        );

    -webkit-background-clip:text;
    background-clip:text;
    color:transparent;
}

.stat-title{
    color:#94a3b8;
    margin-top:4px;
    font-size:14px;
}


/* =========================================================
   TWO PILLARS
========================================================= */

.pillars{
    max-width:1200px;
    margin:auto;

    display:grid;
    grid-template-columns:
        repeat(2,1fr);

    gap:25px;
}

.pillar{
    min-height:400px;

    padding:40px;

    position:relative;

    overflow:hidden;

    border-radius:30px;

    border:1px solid rgba(255,255,255,.08);

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.07),
            rgba(255,255,255,.02)
        );

    transition:.5s ease;
}

.pillar:hover{
    transform:translateY(-10px);

    box-shadow:
        0 30px 70px rgba(0,0,0,.3);
}

.pillar::after{
    content:"";

    position:absolute;

    width:280px;
    height:280px;

    border-radius:50%;

    filter:blur(80px);

    opacity:.13;

    right:-80px;
    bottom:-100px;
}

.marketplace-pillar::after{
    background:#06b6d4;
}

.skill-pillar::after{
    background:#a855f7;
}

.pillar-icon{
    width:60px;
    height:60px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:18px;

    font-size:27px;

    margin-bottom:25px;
}

.marketplace-pillar .pillar-icon{
    background:rgba(6,182,212,.12);
}

.skill-pillar .pillar-icon{
    background:rgba(168,85,247,.12);
}

.pillar h3{
    font-family:'Poppins',sans-serif;

    font-size:28px;
    margin-bottom:13px;
}

.pillar p{
    color:#94a3b8;
    line-height:1.8;
}

.feature-list{
    list-style:none;
    margin-top:25px;

    display:grid;
    gap:12px;
}

.feature-list li{
    color:#cbd5e1;
    font-size:14px;

    display:flex;
    align-items:center;
    gap:10px;
}

.feature-list li span{
    color:#22d3ee;
}


/* =========================================================
   FEATURE CARDS
========================================================= */

.feature-grid{
    max-width:1200px;
    margin:auto;

    display:grid;

    grid-template-columns:
        repeat(4,1fr);

    gap:18px;
}

.feature-card{
    padding:28px;

    border-radius:22px;

    background:rgba(255,255,255,.035);

    border:1px solid rgba(255,255,255,.07);

    transition:.4s ease;
}

.feature-card:hover{
    transform:translateY(-7px);

    background:rgba(255,255,255,.06);

    border-color:
        rgba(129,140,248,.3);
}

.feature-card .icon{
    font-size:25px;
    margin-bottom:18px;
}

.feature-card h4{
    font-size:16px;
    margin-bottom:9px;
}

.feature-card p{
    color:#64748b;
    font-size:13px;
    line-height:1.7;
}


/* =========================================================
   CTA
========================================================= */

.cta{
    max-width:1200px;
    margin:80px auto;

    padding:70px 40px;

    text-align:center;

    border-radius:32px;

    position:relative;
    overflow:hidden;

    background:
        linear-gradient(
            135deg,
            rgba(6,182,212,.12),
            rgba(99,102,241,.14),
            rgba(168,85,247,.12)
        );

    border:1px solid rgba(255,255,255,.1);
}

.cta::before{
    content:"";

    position:absolute;

    width:300px;
    height:300px;

    background:#6366f1;

    filter:blur(100px);

    opacity:.12;

    left:-100px;
    top:-150px;
}

.cta h2{
    position:relative;

    font-family:'Poppins',sans-serif;

    font-size:
        clamp(30px,4vw,46px);

    letter-spacing:-2px;

    margin-bottom:14px;
}

.cta p{
    position:relative;

    color:#94a3b8;

    margin-bottom:25px;
}


/* =========================================================
   FOOTER
========================================================= */

footer{
    padding:50px 6% 30px;

    border-top:1px solid rgba(255,255,255,.06);

    color:#64748b;
}

.footer-content{
    max-width:1200px;
    margin:auto;

    display:flex;
    justify-content:space-between;
    align-items:center;

    gap:20px;
}

.footer-logo{
    color:#cbd5e1;
    font-weight:700;
}

.footer-copy{
    font-size:13px;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:1000px){

    .float-one,
    .float-two{
        display:none;
    }

    .feature-grid{
        grid-template-columns:
            repeat(2,1fr);
    }

}

@media(max-width:800px){

    .navbar{
        padding:15px 5%;
    }

    .nav-links{
        display:none;

        position:absolute;

        top:75px;
        left:5%;
        right:5%;

        padding:15px;

        flex-direction:column;
        align-items:stretch;

        background:#0b1020;

        border:1px solid rgba(255,255,255,.08);

        border-radius:18px;
    }

    .nav-links.show{
        display:flex;
    }

    .nav-links a{
        text-align:center;
    }

    .mobile-menu{
        display:block;
    }

    .hero{
        padding-top:140px;
    }

    .hero h1{
        letter-spacing:-2px;
    }

    .stats-grid{
        grid-template-columns:1fr;
    }

    .pillars{
        grid-template-columns:1fr;
    }

}

@media(max-width:600px){

    .hero{
        padding-left:5%;
        padding-right:5%;
    }

    .hero-description{
        font-size:15px;
    }

    .hero-actions{
        flex-direction:column;
        align-items:stretch;
    }

    .primary-btn,
    .secondary-btn{
        width:100%;
    }

    .section{
        padding:80px 5%;
    }

    .feature-grid{
        grid-template-columns:1fr;
    }

    .pillar{
        padding:30px;
    }

    .footer-content{
        flex-direction:column;
        text-align:center;
    }

}


/* =========================================================
   MOUSE GLOW
========================================================= */

.cursor-glow{
    position:fixed;

    width:250px;
    height:250px;

    border-radius:50%;

    pointer-events:none;

    z-index:-1;

    background:
        radial-gradient(
            circle,
            rgba(99,102,241,.08),
            transparent 65%
        );

    transform:translate(-50%,-50%);
}

</style>

</head>

<body>


<!-- =====================================================
     BACKGROUND
====================================================== -->

<div class="background">

    <div class="grid"></div>

    <div class="orb one"></div>
    <div class="orb two"></div>
    <div class="orb three"></div>

</div>

<div class="cursor-glow" id="cursorGlow"></div>


<!-- =====================================================
     NAVBAR
====================================================== -->

<header class="navbar">

    <a href="index.php" class="logo">

        <div class="logo-mark">
            🚀
        </div>

        <span>EduTrade</span>

    </a>


    <nav class="nav-links" id="navLinks">

        <a href="#home">
            Home
        </a>

        <a href="#marketplace">
            Marketplace
        </a>

        <a href="#skills">
            Skill Hub
        </a>

        <?php if($isLoggedIn): ?>

            <a href="pages/dashboard.php">
                Dashboard
            </a>

            <a href="includes/logout.php"
               class="nav-register">
                Logout
            </a>

        <?php else: ?>

            <a
                href="includes/login.php"
                class="nav-login"
            >
                Login
            </a>

            <a
                href="includes/register.php"
                class="nav-register"
            >
                Register
            </a>

        <?php endif; ?>

    </nav>


    <div
        class="mobile-menu"
        id="mobileMenu"
    >
        ☰
    </div>

</header>


<!-- =====================================================
     HERO
====================================================== -->

<section
    class="hero"
    id="home"
>

    <div
        class="hero-content"
        data-aos="fade-up"
        data-aos-duration="1000"
    >

        <div class="badge">

            <span class="badge-dot"></span>

            Built for Students • Powered by Campus

        </div>


        <h1>

            Your Campus.
            <br>

            <span class="gradient-text">
                Your Marketplace.
            </span>

        </h1>


        <p class="hero-description">

            Buy useful campus products, sell what you no longer need,
            showcase your skills and connect with talented students —
            all in one modern student ecosystem.

        </p>


        <div class="hero-actions">

            <?php if($isLoggedIn): ?>

                <a
                    href="pages/dashboard.php"
                    class="primary-btn"
                >
                    Open Dashboard
                    <span>→</span>
                </a>

                <a
                    href="#marketplace"
                    class="secondary-btn"
                >
                    Explore Platform
                    <span>↓</span>
                </a>

            <?php else: ?>

                <a
                    href="includes/register.php"
                    class="primary-btn"
                >
                    Get Started
                    <span>→</span>
                </a>

                <a
                    href="includes/login.php"
                    class="secondary-btn"
                >
                    Already a Student?
                    <span>↗</span>
                </a>

            <?php endif; ?>

        </div>

    </div>


    <!-- FLOATING CARD 1 -->

    <div
        class="floating-card float-one"
        data-aos="fade-right"
        data-aos-delay="600"
    >

        <div class="float-icon">
            📚
        </div>

        <div>
            <strong>
                Campus Marketplace
            </strong>

            <small>
                Buy • Sell • Discover
            </small>
        </div>

    </div>


    <!-- FLOATING CARD 2 -->

    <div
        class="floating-card float-two"
        data-aos="fade-left"
        data-aos-delay="800"
    >

        <div class="float-icon">
            ⭐
        </div>

        <div>
            <strong>
                Student Skill Hub
            </strong>

            <small>
                Learn • Hire • Grow
            </small>
        </div>

    </div>

</section>


<!-- =====================================================
     LIVE STATS
====================================================== -->

<section class="section">

    <div
        class="section-header"
        data-aos="fade-up"
    >

        <div class="section-label">
            Live Platform
        </div>

        <h2 class="section-title">
            Growing with students
        </h2>

        <p class="section-description">
            Real-time numbers from the EduTrade platform.
        </p>

    </div>


    <div class="stats-grid">


        <div
            class="stat-card"
            data-aos="fade-up"
        >

            <div class="stat-icon">
                👨‍🎓
            </div>

            <div
                class="stat-number counter"
                data-target="<?php echo $students; ?>"
            >
                0
            </div>

            <div class="stat-title">
                Registered Students
            </div>

        </div>


        <div
            class="stat-card"
            data-aos="fade-up"
            data-aos-delay="150"
        >

            <div class="stat-icon">
                🛒
            </div>

            <div
                class="stat-number counter"
                data-target="<?php echo $products; ?>"
            >
                0
            </div>

            <div class="stat-title">
                Campus Products
            </div>

        </div>


        <div
            class="stat-card"
            data-aos="fade-up"
            data-aos-delay="300"
        >

            <div class="stat-icon">
                💡
            </div>

            <div
                class="stat-number counter"
                data-target="<?php echo $skills; ?>"
            >
                0
            </div>

            <div class="stat-title">
                Student Skills
            </div>

        </div>


    </div>

</section>


<!-- =====================================================
     TWO MAIN PILLARS
====================================================== -->

<section
    class="section"
    id="marketplace"
>

    <div
        class="section-header"
        data-aos="fade-up"
    >

        <div class="section-label">
            One Platform
        </div>

        <h2 class="section-title">
            Built around two powerful ideas
        </h2>

        <p class="section-description">
            EduTrade combines a campus marketplace with a student
            talent ecosystem.
        </p>

    </div>


    <div class="pillars">


        <!-- MARKETPLACE -->

        <div
            class="pillar marketplace-pillar"
            data-aos="fade-right"
        >

            <div class="pillar-icon">
                🛒
            </div>

            <h3>
                Marketplace
            </h3>

            <p>
                Find affordable products from fellow students
                instead of buying everything new.
            </p>


            <ul class="feature-list">

                <li>
                    <span>✓</span>
                    Books & study material
                </li>

                <li>
                    <span>✓</span>
                    Lab equipment
                </li>

                <li>
                    <span>✓</span>
                    Electronics
                </li>

                <li>
                    <span>✓</span>
                    Bags & stationery
                </li>

                <li>
                    <span>✓</span>
                    New & used products
                </li>

            </ul>

        </div>


        <!-- SKILL HUB -->

        <div
            class="pillar skill-pillar"
            id="skills"
            data-aos="fade-left"
        >

            <div class="pillar-icon">
                🎯
            </div>

            <h3>
                Skill Hub
            </h3>

            <p>
                Turn your skills into opportunities and help
                other students find the talent they need.
            </p>


            <ul class="feature-list">

                <li>
                    <span>✓</span>
                    Coding & development
                </li>

                <li>
                    <span>✓</span>
                    Graphic designing
                </li>

                <li>
                    <span>✓</span>
                    Photography
                </li>

                <li>
                    <span>✓</span>
                    Video editing
                </li>

                <li>
                    <span>✓</span>
                    Presentation & content design
                </li>

            </ul>

        </div>


    </div>

</section>


<!-- =====================================================
     FEATURES
====================================================== -->

<section class="section">

    <div
        class="section-header"
        data-aos="fade-up"
    >

        <div class="section-label">
            Why EduTrade
        </div>

        <h2 class="section-title">
            More than a marketplace
        </h2>

        <p class="section-description">
            Designed to make student-to-student interaction
            easier, safer and more useful.
        </p>

    </div>


    <div class="feature-grid">


        <div
            class="feature-card"
            data-aos="fade-up"
        >

            <div class="icon">
                🔐
            </div>

            <h4>
                Student Focused
            </h4>

            <p>
                Designed around the real needs of campus students.
            </p>

        </div>


        <div
            class="feature-card"
            data-aos="fade-up"
            data-aos-delay="100"
        >

            <div class="icon">
                🔎
            </div>

            <h4>
                Easy Discovery
            </h4>

            <p>
                Search and discover products and skills quickly.
            </p>

        </div>


        <div
            class="feature-card"
            data-aos="fade-up"
            data-aos-delay="200"
        >

            <div class="icon">
                ⭐
            </div>

            <h4>
                Trust & Reviews
            </h4>

            <p>
                Build reputation through ratings and reviews.
            </p>

        </div>


        <div
            class="feature-card"
            data-aos="fade-up"
            data-aos-delay="300"
        >

            <div class="icon">
                🤝
            </div>

            <h4>
                Student Connections
            </h4>

            <p>
                Connect buyers, sellers, clients and student talent.
            </p>

        </div>


    </div>

</section>


<!-- =====================================================
     CTA
====================================================== -->

<section class="section">

    <div
        class="cta"
        data-aos="zoom-in"
    >

        <h2>
            Ready to build your campus network?
        </h2>

        <p>
            Join EduTrade and turn your campus into a connected
            marketplace of products, skills and opportunities.
        </p>


        <?php if($isLoggedIn): ?>

            <a
                href="pages/dashboard.php"
                class="primary-btn"
            >
                Go to Dashboard →
            </a>

        <?php else: ?>

            <a
                href="includes/register.php"
                class="primary-btn"
            >
                Create Student Account →
            </a>

        <?php endif; ?>

    </div>

</section>


<!-- =====================================================
     FOOTER
====================================================== -->

<footer>

    <div class="footer-content">

        <div class="footer-logo">
            🚀 EduTrade
        </div>

        <div class="footer-copy">
            © 2026 EduTrade • Built for students
        </div>

    </div>

</footer>


<!-- =====================================================
     AOS
====================================================== -->

<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>


<script>

/* =========================================================
   AOS
========================================================= */

AOS.init({

    duration:900,

    easing:'ease-out-cubic',

    once:true,

    offset:80

});


/* =========================================================
   MOBILE NAVIGATION
========================================================= */

const mobileMenu =
    document.getElementById('mobileMenu');

const navLinks =
    document.getElementById('navLinks');

mobileMenu.addEventListener(
    'click',
    () => {

        navLinks.classList.toggle('show');

    }
);


/* Close mobile menu */

document
    .querySelectorAll('.nav-links a')
    .forEach(link => {

        link.addEventListener(
            'click',
            () => {

                navLinks.classList.remove('show');

            }
        );

    });


/* =========================================================
   ANIMATED COUNTERS
========================================================= */

const counters =
    document.querySelectorAll('.counter');

const observer =
    new IntersectionObserver(
        entries => {

            entries.forEach(entry => {

                if(!entry.isIntersecting)
                    return;

                const counter =
                    entry.target;

                const target =
                    Number(
                        counter.dataset.target
                    );

                let current = 0;

                const duration = 1500;

                const start =
                    performance.now();


                function animate(time){

                    const progress =
                        Math.min(
                            (time - start) / duration,
                            1
                        );

                    const eased =
                        1 -
                        Math.pow(
                            1 - progress,
                            3
                        );

                    current =
                        Math.floor(
                            eased * target
                        );

                    counter.textContent =
                        current.toLocaleString();

                    if(progress < 1){

                        requestAnimationFrame(
                            animate
                        );

                    }else{

                        counter.textContent =
                            target.toLocaleString() + '+';

                    }

                }

                requestAnimationFrame(animate);

                observer.unobserve(counter);

            });

        },

        {
            threshold:.5
        }
    );


counters.forEach(counter => {

    observer.observe(counter);

});


/* =========================================================
   MOUSE GLOW
========================================================= */

const cursorGlow =
    document.getElementById('cursorGlow');

document.addEventListener(
    'mousemove',
    event => {

        cursorGlow.style.left =
            event.clientX + 'px';

        cursorGlow.style.top =
            event.clientY + 'px';

    }
);


/* =========================================================
   NAVBAR SCROLL EFFECT
========================================================= */

const navbar =
    document.querySelector('.navbar');

window.addEventListener(
    'scroll',
    () => {

        if(window.scrollY > 50){

            navbar.style.background =
                'rgba(5,8,22,.88)';

            navbar.style.boxShadow =
                '0 10px 40px rgba(0,0,0,.2)';

        }else{

            navbar.style.background =
                'rgba(5,8,22,.68)';

            navbar.style.boxShadow =
                'none';

        }

    }
);

</script>

</body>
</html>